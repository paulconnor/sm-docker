#!/bin/sh
#
# CA Technologies DXserver/samples/ssl
#
# Description:
#   This script configures and runs the SSL tests.
#

THISHOST=`hostname`

usage()
{
    echo
    echo "Usage:"
    echo "    setup.sh SHA1|SHA2 [-q]"
    echo

    exit 1
}


# Command Failed
fail()
{
    echo
    echo " Error running '$1', SSL tests failed."
    echo
    exit 1
}

if [ -z $1 -o "$1" = "-q" ]; then
    usage
elif [ "$1" = "SHA1" ]; then
    SHA=""
elif [ "$1" = "SHA2" ]; then
    SHA="-Z SHA224 "
else
    usage
fi

if [ -z "$DXHOME" ]; then
    echo "  You must be the DXserver Administrator to run this script"
    exit 1
fi

echo
dxserver status | grep -i democorp >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "The DemoCorp and UNSPSC samples must be set up before running the "
    echo "SSL sample"
    exit 1
fi
dxserver status | grep -i unspsc >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "The DemoCorp and UNSPSC samples must be set up before running the "
    echo "SSL sample"
    exit 1
fi

#
# Output a summary of the setup.
#
clear
echo
echo " SSL sample CA Directory Tests"
echo " -----------------------------"
echo
echo " This script will perform the following steps:"
echo
echo "   1. Generate DSA and user certificates."
echo "   2. Start the DemoCorp & UNSPSC DSAs."
echo "   3. Run the DUA SSL encryption test (test1.dxs)."
echo "   4. Run the DUA SSL authentication test (test2.dxs)."
echo "   5. Run the DUA SSL authentication test (test3.dxs)."
echo "   6. Run the DUA SSL distributed authentication test (test4.dxs)."
echo "   7. Run the LDUA SSL encryption test (test1.dxs)."
echo "   8. Run the LDUA SSL authentication test (test2.dxs)."
echo "   9. Run the LDUA SSL authentication test (test3.dxs)."
echo "  10. Run the LDUA SSL distributed authentication test (test4.dxs)."
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Generate the 4 bind scripts containing the hostname.
#
rm -f bind1.dxs
cat << EOF > bind1.dxs
# CA Technologies DXserver/samples/ssl
#
# bind1.dxs written by samples/ssl/setup.sh
#
# This script contains the bind command for test1.dxs.
#

source "client.dxc";

bind-req
    ssl-encryption
    remote-addr = { nsap = ip "$THISHOST" port 19389};
EOF

rm -f bind2.dxs
cat << EOF > bind2.dxs
# CA Technologies DXserver/samples/ssl
#
# bind2.dxs written by samples/ssl/setup.sh
#
# This script contains the bind command for test2.dxs.
#

source "client.dxc";

bind-req
    ssl-auth personality = "marco_drew"
    remote-addr = { nsap = ip "$THISHOST" port 19389};
EOF

rm -f bind3.dxs
cat << EOF > bind3.dxs
# CA Technologies DXserver/samples/ssl
#
# bind3.dxs written by samples/ssl/setup.sh
#
# This script contains the bind command for test3.dxs.
#

source "client.dxc";

bind-req
    ssl-auth personality = "marco_drew"
    remote-addr = { nsap = ip "$THISHOST" port 19389 };
EOF

rm -f bind4.dxs
cat << EOF > bind4.dxs
# CA Technologies DXserver/samples/ssl
#
# bind4.dxs written by samples/ssl/setup.sh
#
# This script contains the bind command for test4.dxs.
#

source "client.dxc";

bind-req
    ssl-auth personality = "marco_drew"
    remote-addr = { nsap = ip "$THISHOST" port 19489 };
EOF

#
# Generate the client SSL configuration.
#
rm -f client.dxc
cat << EOF > client.dxc
# client.dxc
#
# client.dxc written by samples/ssl/setup.sh
#
# This file contains the client ssl configuration.
#

set ssl = {
    cert-dir = "."
    ca-file = "../../config/ssld/trusted.pem"
    protocol = tls
};

EOF

#
# Step 1.
#
clear
echo
echo " Step 1 - Generating the DSA and user certificates"
echo " -------------------------------------------------"
echo
echo "   The command 'dxcertgen ...' is used to create the DSA and User certificates"
echo
echo
echo "   Creating the DSA and User certificates..."
dxcertgen $SHA -u $DXHOME/samples/ssl/user.ldif \
               -p $DXHOME/config/ssld/personalities certs
if [ $? -ne 0 ]; then
    fail dxcertgen
fi

cp $DXHOME/config/ssld/personalities/marco_drew.pem .
cp $DXHOME/config/ssld/personalities/gary_michael.pem .

echo
echo " Step 1 completed - DSA and User certificates created"
echo

if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 2.
#
clear
echo
echo " Step 2 - Starting the DemoCorp & UNSPSC DSAs"
echo " --------------------------------------------"
echo
echo "   The command 'dxserver start democorp' is used to start the DemoCorp DSA"
echo
echo "   The command 'dxserver start unspsc' is used to start the UNSPSC DSA"
echo
echo
dxserver stop democorp >/dev/null 2>&1
dxserver stop unspsc >/dev/null 2>&1
echo "   Starting the DemoCorp DSA..."
dxserver start democorp
echo
echo "   Starting the UNSPSC DSA..."
dxserver start unspsc
echo
echo " Step 2 completed - DemoCorp & UNSPSC DSAs started"
echo

if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 3.
#
clear
echo
echo " Step 3 - Run the DAP DUA SSL encryption test (test1.dxs)"
echo " --------------------------------------------------------"
echo
echo "   The command '../dua/dua test1.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

echo " Executing the SSL test script test1.dxs using the DAP DUA..."
../dua/dua test1.dxs
if [ $? -ne 0 ]; then
    fail "../dua/dua test1.dxs"
fi

echo
echo " Step 3 completed - Execution of test1.dxs using the DAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 4.
#
clear
echo
echo " Step 4 - Run the DAP DUA SSL authentication test (test2.dxs)"
echo " ------------------------------------------------------------"
echo
echo  "   The command '../dua/dua test2.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the SSL test script test2.dxs using the DAP DUA..."
../dua/dua test2.dxs
if [ $? -ne 0 ]; then
    fail "../dua/dua test2.dxs"
fi

echo
echo " Step 4 completed - Execution of test2.dxs using the DAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 5
#
clear
echo
echo " Step 5 - Run the DAP DUA SSL authentication test (test3.dxs)"
echo " ------------------------------------------------------------"
echo
echo  "   The command '../dua/dua test3.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

echo " Executing the SSL test script test3.dxs using the DAP DUA..."
../dua/dua test3.dxs
if [ $? -ne 0 ]; then
    fail "../dua/dua test3.dxs"
fi

echo
echo " Step 5 completed - Execution of test3.dxs using the DAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 6.
#
clear
echo
echo " Step 6 - Run the DAP DUA SSL distributed authentication test (test4.dxs)"
echo " ------------------------------------------------------------------------"
echo
echo  "   The command '../dua/dua test4.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the SSL test scripts test4.dxs using the DAP DUA..."
../dua/dua test4.dxs
if [ $? -ne 0 ]; then
    fail "../dua/dua test4.dxs"
fi
echo
echo " Step 6 completed - Execution of test4.dxs using the DAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 7.
#
clear
echo
echo " Step 7 - Run the LDAP DUA SSL encryption test (test1.dxs)"
echo " ---------------------------------------------------------"
echo
echo  "   The command '../ldua/ldua test1.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the SSL test script test1.dxs using the LDAP DUA..."
../ldua/ldua test1.dxs
if [ $? -ne 0 ]; then
    fail "../ldua/ldua test1.dxs"
fi
echo
echo " Step 7 completed - Execution of test1.dxs using the LDAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 8.
#
clear
echo
echo " Step 8 - Run the LDAP DUA SSL authentication test (test2.dxs)"
echo " -------------------------------------------------------------"
echo
echo  "   The command '../ldua/ldua test2.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the SSL test script test2.dxs using the LDAP DUA..."
../ldua/ldua test2.dxs
if [ $? -ne 0 ]; then
    fail "../ldua/ldua test2.dxs"
fi
echo
echo " Step 8 completed - Execution of test2.dxs using the LDAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 9.
#
clear
echo
echo " Step 9 - Run the LDAP DUA SSL authentication test (test3.dxs)"
echo " -------------------------------------------------------------"
echo
echo  "   The command '../ldua/ldua test3.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the SSL test script test3.dxs using the DAP DUA..."
../ldua/ldua test3.dxs
if [ $? -ne 0 ]; then
    fail "../ldua/ldua test3.dxs"
fi

echo
echo " Step 9 completed - Execution of test3.dxs using the LDAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 10.
#
clear
echo
echo " Step 10 - Run the LDAP DUA SSL distributed authentication test (test4.dxs)"
echo " --------------------------------------------------------------------------"
echo
echo  "   The command '../dua/dua test4.dxs' is used to run this test"
echo
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the SSL test scripts test4.dxs using the LDAP DUA..."
../ldua/ldua test4.dxs
if [ $? -ne 0 ]; then
    fail "[ldua]test4.dxs"
fi
echo
echo " Step 10 completed - Execution of test4.dxs using the LDAP DUA complete"
echo
if [ "$2" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

echo
echo " SSL sample CA Directory tests complete."
echo

exit 0
