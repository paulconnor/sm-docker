CA

Readme for the DXsoak Tool

______________________________________________________________________

1.0  Syntax of the DXsoak Tool

2.0  How the DXsoak Took Works

3.0  How to Use the DXsoak Tool

4.0  Recommendations for the Number of Threads

5.0  DXsoak is Different from soak

6.0  Format of the ELDF File
6.1  Search Operations in ELDF
6.2  Add Operations in ELDF
6.3  Modify Operations in ELDF
6.4  Delete Operations in ELDF

7.0  Contact Technical Support

______________________________________________________________________
1.0  Syntax of the DXsoak Tool

The DXsoak tool lets you send a large number of operations
to a directory.

This can be useful in the following situations:

 *   You want to test the performance of your current directory
     setup.

 *   You are planning to make a change to your environment, and
     you want to gauge the effect of the change on your
     directory's performance.

     Important! Do not use DXsoak in a production directory.
     DXsoak can generate a very large number of LDAP searches,
     modifies and deletes. It could be used (intentionally or
     unintentionally) to perform a denial-of-service attack on a
     DSA or to delete important data.

This command has the following format:

 dxsoak -h <hostname>:<port> -f <filename> [-t <number-threads>] [-q <queue-size>] [-l <time-limit>] [-c] [-s] [-d bind-dn] [-w bind-password]

 *   -h <hostname>:<port>

     Specifies the host and port on which the DSA you want to challenge
     is running.

 *   -f <filename>

     Specifies the name of the ELDF file that contains the
     operations that DXsoak will carry out.

 *   -t <number-threads>

     (Optional) Specifies the number of associations that the
     DXsoak tool will make to the DSA. This lets you simulate
     the number of clients that usually connect to the directory.

     Default: 1

 *   -q <queue-size>

     (Optional) Specifies the number of operations that the
     DXsoak tool will attempt to keep outstanding.

     Default: 1. This may not be high enough to stress your
     directory.

 *   -l <time-limit>

     (Optional) The DXsoak tool will run in continuous mode
     for <time-limit> seconds. This is useful for comparative
     testing.

 *   -c

     (Optional) Indicates that DXsoak will run in continuous
     mode. When the tool reaches the end of the ELDF file, it
     will immediately start again at the beginning.

 *   -s

     (Optional) Specifies that the tool will stop if an error
     occurs. 
     
 *   -D <bind-dn>
 
     (Optional) Specifies the bind DN to be used, by default dxsoak uses anonymous bind if -D option is absent.
     
 *   -w <bind-password>
 
     (Optional) Specifies the bind password for simple authentication.


     The DXsoak tool does not check for correctness (for
     example, that the right number of entries are returned for
     a search). Instead, the tool only checks for errors (for
     example, "Service unavailable").

______________________________________________________________________
2.0  How the DXsoak Took Works

The DXsoak tool uses a text file (in ELDF format) which
contains a list of the operations that are to be sent to
the directory.

When you run DXsoak, it reads the operations listed in the
ELDF file, and sends those operations to the directory you
specify.

DXsoak attempts to run the operations in the order that it
reads them. However, because the tool sends the operations
through different threads, and some operations take longer
than others, some operations listed later in the ELDF file
might actually be performed before operations listed
earlier.

The following diagram shows the DXsoak tool sending
operations to a directory that consists of one router and
three data DSAs:

______________________________________________________________________
3.0  How to Use the DXsoak Tool

The parameters for the DXsoak tool let you set the tool up
to emulate your actual production environment. 

Important! Do not use DXsoak in a production directory.
DXsoak can generate a very large number of LDAP searches,
modifies and deletes. It could be used (intentionally or
unintentionally) to perform a denial-of-service attack on a
DSA or to delete important data. 

Before you run DXsoak, you should do the following:

 1.  Research the production environment:

      a.  In your production environment, find the current load
          statistics.

      b.  If possible, use full tracing to capture the actual queries
          being sent you your directory.

 2.  Set up a test environment that closely mimics the
     production environment, including hardware and directory
     configuration.

 3.  Prepare the DXsoak parameters:

      a.  Create an ELDF file that contains operations similar to
          those sent to the production system. If you have a trace of
          the operations, convert the trace into the ELDF format.

      b.  Run the DXsoak tool, using values of <t> and <q> that closely
          mimic the production environment.

      c.  While DXsoak is running, measure the load statistics on the
          test environment. If the test environment's statistics are
          different to those of the production environment, adjust
          the values of <t> and <q>, and run DXsoak again.

     When the test environment's load statistics closely mimic
     those of the production system, you are ready to use DXsoak
     to gauge the effect of any changes you plan to make.

 4.  Use DXsoak to gauge the effect of any changes you plan to
     make:

      a.  In the test environment, change an aspect of your
          directory. For example, you could add more replicas,
          distribute the Namespace, or change the hardware.

      b.  Run DXsoak, using the parameters you found in the previous
          steps.

      c.  Review the statistics to see the effect of the change you
          made.

______________________________________________________________________
4.0  Recommendations for the Number of Threads

The number of threads that DXsoak should use is related to
the number of CPUs in the directory hosts. The more CPUs
there are, the more threads that can be running
simultaneously.

We recommend that for maximum performance you use the
following thread settings for the following numbers of CPUs:

======================================================================
Number of CPUs              Recommended Number of Threads
======================================================================
1                           2
--------------------------- ------------------------------------------
8                           9 - 16
--------------------------- ------------------------------------------
24                          25 - 45
======================================================================

______________________________________________________________________
5.0  DXsoak is Different from soak

The DXsoak tool is intended to replace the tool named <soak>.
While both tools are still supplied with CA Directory,
eventually DXsoak will fully replace soak.

The following list describes some of the difference between
the tools:

 *   DXsoak is faster

     It is about fifty times faster than the soak tool. DXsoak
     is also about ten times faster than a cache DSA.

 *   DXsoak allows mixed operations

     The soak tool does not let you run mixtures of operations
     (for example, search and modify operations).

 *   DXsoak allows more operation types

     The soak tool cannot send bind requests.

 *   DXsoak cannot generate its own operations

     The new DXsoak tool requires an ELDF file which lists all
     of the operations that are to be carried out. We recommend
     that you automate the procedure of creating this file.

     The soak tool can generate its own data.

 *   DXsoak cannot use DAP

     The soak tool can use both DAP and LDAP modes. DXsoak tool
     can use only LDAP.


______________________________________________________________________
6.0  Format of the ELDF File

DXsoak requires a file in ELDF format that describes the
operations to be performed on the directory. The ELDF file
contains one or more entries.

Any line beginning with the character # is ignored.

An ELDF file can contain the following operations:

 *   Search

 *   Add

 *   Modify

 *   Delete

6.1  Search Operations in ELDF

The <search> operation has the following format: 

 dn: DN
 changetype: search
 scope: singleLevel | baseObject | wholeSubtree
 filter: <search-filter>
 [attribute: <attribute-list>]

 *   dn

     Specifies the base DN of the search.

 *   changetype: search

     Specifies that this is a search operation.

 *   scope: singleLevel | baseObject | wholeSubtree

     Specifies the scope of the search operation.

 *   filter: <search-filter>

     Specifies the search filter for this operation.

 *   attribute: <attribute-list> | 1.1

     (Optional) Specifies the attributes to be returned. If this
     is empty, all attributes will be returned.

      *   attribute-list

          Specifies a comma-separated list of any attributes to be
          returned.

      *   1.1

          No attributes will be returned.

Example: A Single-level Search at a Defined DN

 dn: cn=Craig Link,ou=people,dc=example,dc=com 
 changetype: search
 scope: singleLevel
 filter: (cn=*)

Example: A Non-recursive Search with a Filter Under a Given
DN, Returning No Attributes

 dn: cn=Craig Link,ou=people,dc=example,dc=com 
 changetype: search
 scope: baseObject
 filter: (cstVTN=3178870918)
 attribute: 1.1

Example: A Search with a Filter Under a Given DN, Returning
the Attribute <uid>

 dn: ou=people,dc=example,dc=com
 changetype: search
 scope: wholeSubtree
 filter: (&(st=Flint)(cstSVT=cstCBL))
 attribute: uid

6.2  Add Operations in ELDF

In the ELDF file, the add operation adds a new entry. You
can also specify one or more attribute values for the entry.

The <add> operation has the following format:

 dn: DN
 changetype: add
 objectclass: <object-class>
 <attribute-name>: <attribute-value>

 *   dn: DN

     Specifies the DN of the new entry.

 *   changetype: add

     Specifies that this is an add operation.

 *   objectclass: <object-class>

     Specifies the object class of the new entry.

 *   <attribute-name>: <attribute-value>

     Specifies the name and value of an attribute for the new
     entry. Add as many attribute values as required.

Example: Add a New Entry with a Multivalued Attribute

 # Add entry for Craig Link, plus two telephoneNumber values
 dn: cn=Craig Link,ou=people,dc=example,dc=com
 changetype: add
 objectclass: inetorgperson
 cn: Craig D Link
 telephonenumber: 123-456
 telephonenumber: 789-012

6.3  Modify Operations in ELDF

In the ELDF file, <modify> operations can add, delete, or
replace attribute values in the specified entry.

For each of these types of change, you need to specify the
attribute that you want to change. For example, if you want
to add an attribute, you must specify the attribute name
and value.

The <modify> operation has the following format: 

 dn: DN
 changetype: modify
 [add: attribute-name
    attribute-name: attribute-value]
 [delete: attribute-name
    attribute-name: attribute-value]
 [replace: attribute-name
    attribute-name: attribute-value]

 *   dn: <DN>

     Specifies the entry to be modified.

 *   changetype: modify

     Specifies that this is a modify operation.

 *   add: <attribute-name>

     (Optional) Adds an attribute with the specified type.
     Ensure that you then specify the attribute name and value.

      *   <attribute-name>: <attribute-value>

          Specifies the name and value of the attribute to be added.

 *   delete: <attribute-name>

     (Optional) Deletes the specified attribute. If you do not
     then specify a particular value, all attributes of that
     value will be deleted.

      *   <attribute-name>: <attribute-value>

          (Optional) Specifies the name and value of the attribute to
          be deleted.

 *   replace: <attribute-name>

     (Optional) Replaces the value for the specified attribute.

      *   <attribute-name>: <attribute-value>

          Specifies the name and the new value of the attribute to be
          replaced.

Example: Add the Attribute <telephonenumber> and Give It the
Value <555 55555>

 dn: cn=Craig Link,ou=people,dc=example,dc=com
 changetype: modify
 # single operation
 add: telephonenumber
 telephonenumber: 555 55555

Example: Delete All Attributes with the Type <telephonenumber>

 dn: cn=Craig Link,ou=people,dc=example,dc=com
 changetype: modify
 delete: telephonenumber

Example: Delete One Instance of the <telephonenumber>
Attribute and Add the Value <28378> to the Attribute <pin>

 dn: cn=Craig Link,ou=people,dc=example,dc=com
 changetype: modify
 # Delete a phone number
 delete: telephonenumber
 telephonenumber: 123-456
 # Add a PIN
 add: attributename
 pin: 28378

6.4  Delete Operations in ELDF

In ELDF, the delete operation deletes an entire entry.

The <delete> operation has the following format: 

 dn: DN
 changetype: delete

 *   dn

     Specifies the entry to be deleted.

 *   changetype: delete

     Specifies that this is a delete operation.

Example: Delete the Craig Link Entry

 dn: cn=Craig Link,ou=people,dc=example,dc=com
 changetype: delete

______________________________________________________________________
7.0  Contact Technical Support

For online technical assistance and a complete list of
locations, primary service hours, and telephone numbers,
contact Technical Support at http://ca.com/support.



______________________________________________________________________
Copyright � 2010 CA.
All rights reserved.

