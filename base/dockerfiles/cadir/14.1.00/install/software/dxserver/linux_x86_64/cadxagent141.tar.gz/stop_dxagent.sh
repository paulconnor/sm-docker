#!/bin/sh

${DXHOME}/bin/dxagent stop
