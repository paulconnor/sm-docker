INTRODUCTION..

CA Directory Language Certification Sample Files.

These language files have been provided so that the user can test CA Directory
operating systems other than English.

Please only use the language files that relate to your operating system.

EXECUTION STEPS
To Run:

You must setup an environment variable that matches the folder that you will be using. 

E.g. set LANGUAGE=Italian

You can then just execute - run.bat

To connect to the dsa and view the data, connect to port 7777
