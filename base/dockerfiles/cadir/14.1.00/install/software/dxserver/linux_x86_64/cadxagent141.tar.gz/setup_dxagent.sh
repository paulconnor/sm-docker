#!/bin/bash

which python3 >& /dev/null
HAVE_PYTHON3=$?
which python >& /dev/null
HAVE_PYTHON=$?

if [ $HAVE_PYTHON3 -eq 0 ]
then
    PYTHON=python3
elif [ $HAVE_PYTHON -eq 0 ]
then
    PYTHON=python
else
    echo "Dxagent requires Python"
    exit 1
fi

PYTHONPATH=lib $PYTHON setup_dxagent.py "$@"
