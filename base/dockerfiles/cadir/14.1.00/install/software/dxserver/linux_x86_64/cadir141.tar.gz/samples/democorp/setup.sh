#!/bin/sh
#
# CA Technologies DXserver/samples/democorp
#
# Description:
#   This script configures the DemoCorp example.
#

THISHOST=`hostname`

usage()
{
    echo
    echo "Usage:"
    echo "    setup.sh [DXmanager Democorp DSA name] [-q]"
    echo
    exit 1
}

# Command Failed
fail()
{
    echo
    echo " Error running '$1', DemoCorp Sample Setup Failed."  | tee /tmp/status 
    echo
    exit 1
}

if [ -z "$DXHOME" ]; then
    echo "  You must be the DXserver Administrator to run this script"
    exit 1
fi

QUIET=n
DXMANAGER=n
DEMOCORP=democorp
if [ "$1" = "-q" -o "$2" = "-q" ]; then
    QUIET=y
fi
if [ ! -z "$2" ]; then
    if [ "$2" = "-q" ]; then
        DEMOCORP=$1
        DXMANAGER=y
        if [ ! -f $DXHOME/config/servers/$DEMOCORP.dxi ]; then
            echo "DXmanager configured DSA $DEMOCORP doesn't exist"
            echo
            fail
        fi
    else
        usage
    fi
fi

clear
echo
echo " DemoCorp sample CA Directory configuration"
echo " ------------------------------------------"
echo
echo " This script will perform the following steps:"
echo

# for DXmanager configured DSA then just load back-end
if [ $DXMANAGER = "n" ]; then
    echo "   * Configure the DemoCorp initialization file (democorp.dxi)"
    echo "   * Configure the DemoCorp knowledge file (democorp.dxc)"
    echo "   * Configure the knowledge group file (sample.dxg)"
fi
echo "   * Convert the CSV DemoCorp data into LDIF format."
echo "   * Load the LDIF data into the DemoCorp directory."
echo

if [ "$QUIET" = "n" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Stop and remove democorp
#
clear
dxserver stop $DEMOCORP >/dev/null 2>&1

if [ "$DXMANAGER" = "n" ]; then

    dxserver remove $DEMOCORP >/dev/null 2>&1

    clear
    echo
    echo " Configuring the DemoCorp initialization file"
    echo " --------------------------------------------"
    echo
    echo "   The DemoCorp initialization file democorp.dxi resides in the directory:"
    echo
    echo "     $DXHOME/config/servers/"
    echo
    echo "   Writing the DemoCorp initialization file..."

    rm -f democorp.dxi
    cat << EOF > democorp.dxi
# CA Technologies DXserver/config/servers
#
# democorp.dxi written by samples/democorp/setup.sh
#
# Sample DXserver initialization file.
#

# logging and tracing
source "../logging/default.dxc";

# schema
source "../schema/samples.dxg";

# knowledge
clear dsas;
source "../knowledge/sample.dxg";

# operational settings
source "../settings/default.dxc";

# service limits
source "../limits/default.dxc";

# access controls
clear access;
source "../access/default.dxc";

# ssl
source "../ssld/default.dxc";

# replication agreements (rarely used)
# source "../replication/";

# multiwrite DISP recovery
set multi-write-disp-recovery = false;

# grid configuration
set dxgrid-db-location = "data";
set dxgrid-db-size = 1;
set cache-index = all-attributes;
set lookup-cache = true;

EOF

    echo "   DemoCorp initialization file written"
    echo "   Moving the DemoCorp initialization file to the servers directory..."
    mv democorp.dxi $DXHOME/config/servers/
    echo
    echo " Completed - DemoCorp initialization file configured"
    echo
    if [ "$QUIET" = "n" ]; then
        echo Press RETURN to continue . . .
        read TMP 
    fi

    clear
    echo
    echo " Configuring the DemoCorp knowledge file"
    echo " ---------------------------------------"
    echo
    echo "   The DemoCorp knowledge file democorp.dxc resides in the directory:"
    echo
    echo "     $DXHOME/config/knowledge/"
    echo
    echo "   This will be edited to contain this machine's hostname."
    echo
    echo "   Writing the DemoCorp knowledge file..."

    rm -f router.dxc
    cat << EOF > router.dxc
# CA Technologies DXserver/config/knowledge
#
# router.dxc written by samples/democorp/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command.

set dsa ROUTER =
{
    prefix        = <c AU>
    dsa-name      = <c AU><cn DXserver>
    dsa-password  = "secret"
    address       = tcp "$THISHOST" port 19289
    disp-psap     = DISP
    snmp-port     = 19289
    console-port  = 19290
    auth-levels   = anonymous, clear-password, ssl-auth
    trust-flags   = trust-conveyed-originator
};

EOF

    rm -f democorp.dxc
    cat << EOF > democorp.dxc
# CA Technologies DXserver/config/knowledge
#
# $DEMOCORP.dxc written by samples/democorp/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command.

set dsa DEMOCORP = 
{
     prefix        = <c AU><o DEMOCORP>
     dsa-name      = <c AU><o DEMOCORP><cn DXserver>
     dsa-password  = "secret"
     address       = tcp "$THISHOST" port 19389
     disp-psap     = DISP
     snmp-port     = 19389
     console-port  = 19390
     auth-levels   = anonymous, clear-password, ssl-auth
     trust-flags   = allow-check-password, trust-conveyed-originator
};

EOF

    rm -f unspsc.dxc
    cat << EOF > unspsc.dxc
# CA Technologies DXserver/config/knowledge
#
# unspsc.dxc written by samples/democorp/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command.

set dsa UNSPSC =
{
     prefix        = <c AU><o UNSPSC>
     dsa-name      = <c AU><o UNSPSC><cn DXserver>
     dsa-password  = "secret"
     address       = tcp "$THISHOST" port 19489
     disp-psap     = DISP
     snmp-port     = 19489
     console-port  = 19490
     auth-levels   = anonymous, clear-password, ssl-auth
     trust-flags   = trust-conveyed-originator
};

EOF

    echo "   DemoCorp knowledge file written"
    echo "   Moving the DemoCorp knowledge file to the knowledge directory..."
    mv router.dxc $DXHOME/config/knowledge
    mv democorp.dxc $DXHOME/config/knowledge
    mv unspsc.dxc $DXHOME/config/knowledge
    echo
    echo " Completed - DemoCorp knowledge file configured"
    echo
    if [ "$QUIET" = "n" ]; then
        echo Press RETURN to continue . . .
        read TMP 
    fi

    clear
    echo
    echo " Configuring the knowledge group file to include Democorp"
    echo " --------------------------------------------------------"
    echo
    echo "   The samples knowledge group file, sample.dxg, resides in the directory:"
    echo
    echo "     $DXHOME/config/knowledge/"
    echo
    echo "   It sources knowledge for the Router, DemoCorp and UNSPSC DSAs."
    echo
    echo "   Writing the samples knowledge group file..."

    rm -f sample.dxg
    cat << EOF > sample.dxg
# CA Technologies DXserver/config/knowledge/sample.dxg
#
# sample.dxg written by samples/democorp/setup.sh
#
# Description:
#   This file shows how DSA knowledge can be grouped and shared.
# Each of the Router, DemoCorp and UNSPSC DSAs source this file
# from their initialization file.
#

#
# Source the knowledge file of the Router, Democorp and UNSPSC DSAs.
#
source "router.dxc";
source "democorp.dxc";
source "unspsc.dxc";
EOF

    echo "   DemoCorp knowledge group file written"
    echo "   Moving the knowledge group file to the knowledge directory..."
    mv sample.dxg $DXHOME/config/knowledge
    echo
    echo " Completed - knowledge group file sample.dxg configured"
    echo
    if [ "$QUIET" = "n" ]; then
        echo Press RETURN to continue . . .
        read TMP 
    fi

    clear
    echo
    echo " Creating/clearing the DemoCorp database file 'democorp' using dxemptydb"
    echo " -----------------------------------------------------------------------"
    echo
    dxemptydb democorp
    if [ $? -ne 0 ]; then
        fail dxemptydb
    fi
    echo
    echo " Completed - Database file creation "
    echo

    if [ "$QUIET" = "n" ]; then
        echo Press RETURN to continue . . .
        read TMP 
    fi

fi

clear
echo
echo " Convert the CSV sample data into LDIF format"
echo " --------------------------------------------"
echo
echo "   The tool csv2ldif is used to convert CSV data into LDIF"
echo
echo "   The full command is:"
echo
echo "     csv2ldif -i1 15 democorp.ldt democorp.csv "
echo
echo "   Converting CSV data to LDIF..."
rm -f demo.raw
rm -f demo.ldt
rm -f demo.ldi
rm -f democorp.ldi
csv2ldif -i1 15 democorp.ldt democorp.csv > democorp.ldi
if [ $? -ne 0 ]; then
    fail csv2ldif
fi

echo
echo " Completed - CSV sample data converted to LDIF"
echo
if [ "$QUIET" = "n" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

clear
echo
echo " Bulk load the DemoCorp LDIF data into the Directory"
echo " ---------------------------------------------------"
echo
echo "   The dxloaddb tool is used to bulk load the LDIF data into the Directory"
echo "   The LDIF data is first sorted using the ldifsort tool."
echo
echo "   Note: "
echo
echo "     1. Over 10,000 entries are bulk loaded into the '$DEMOCORP' back-end."
echo
echo "   Sorting DemoCorp LDIF data..."
ldifsort -u democorp.ldi democorp_sorted.ldi
if [ $? -ne 0 ]; then
    fail ldifsort
fi

echo
echo "   Bulk loading the LDIF file direct into democorp sample"
dxloaddb $DEMOCORP democorp_sorted.ldi
if [ $? -ne 0 ]; then
    fail dxloaddb
fi

echo
echo " Completed - DemoCorp Data Loaded"
echo
if [ "$QUIET" = "n" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

rm -f democorp.ldi
rm -f democorp_sorted.ldi

clear
echo
echo " Loading the DemoCorp LDIF sample image data into the Directory"
echo " --------------------------------------------------------------"
echo
echo "   The dxmodify tool is used to apply LDIF changes to the Directory"
echo

if [ "$DXMANAGER" = "n" ]; then
    dxserver install $DEMOCORP >/dev/null 2>&1
fi
dxserver start $DEMOCORP

dxmodify -h$THISHOST -p 19389 -f berndstark.ldi
if [ $? -ne 0 ]; then
    fail dxmodify
fi
echo " Completed - DemoCorp image sample loaded"
echo
if [ "$QUIET" = "n" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

echo
echo "  DemoCorp sample CA Directory configuration complete." | tee /tmp/status 
echo

exit 0
