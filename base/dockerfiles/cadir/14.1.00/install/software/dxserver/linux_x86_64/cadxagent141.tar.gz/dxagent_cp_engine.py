#
# Copyright (C) 2016 CA Technologies. All Rights Reserved.
#

from dxagent import *

import cherrypy
import requestlogger
import ssl
from cherrypy.process.servers import ServerAdapter
from cherrypy.process.plugins import Daemonizer
from cherrypy.process.plugins import PIDFile
from cheroot import wsgi
from cheroot.ssl.builtin import BuiltinSSLAdapter
    
#import pydevd # -- uncomment to debug
#pydevd.settrace("localhost", 5678, suspend=False) # -- uncomment to debug

DXAGENT_CA_FILE = os.path.join(DXAGENTHOME, DXAGENT_CA_FILE_PATH.replace('/', os.sep))
DXAGENT_SERVER_CERT = os.path.join(DXAGENTHOME, DXAGENT_SERVER_CERT_PATH.replace('/', os.sep))
DXAGENT_SERVER_KEY = os.path.join(DXAGENTHOME, DXAGENT_SERVER_KEY_PATH.replace('/', os.sep))

IS_WINDOWS = 'Windows' in platform.system()
if IS_WINDOWS:
	DXAGENT_PID_FILE = os.path.join(DXHOME, "pid/dxagent.pid".replace('/', os.sep))


def start_cherrypy():
    
    dxagent_init()
    
    # Load logging config and wrap app to log access requests
    logging.config.fileConfig(DXAGENT_LOGGING_CONF_FILE, defaults=None, disable_existing_loggers=True)
    
    for file_name in [DXAGENT_CA_FILE, DXAGENT_SERVER_CERT, DXAGENT_SERVER_KEY]:
        if not os.path.isfile(file_name):
            logger.error(file_name + " not found, check configuration or run setup_dxagent" + (".bat" if IS_WINDOWS else ".sh"))
            exit()
    
    logger.info("Python Version: " + sys.version[:5])
    access_logger = logging.getLogger("dxagent.access")
    wrapped_app = requestlogger.WSGILogger(app, access_logger.handlers, requestlogger.ApacheFormatter())
    
    cherrypy.server.unsubscribe()
    bind_addr = (DXAGENT_HOST, DXAGENT_PORT)    
    server = wsgi.WSGIServer(bind_addr, wrapped_app)
    
    if hasattr(ssl, 'SSLContext'):
        server.ssl_adapter = BuiltinSSLAdapter(DXAGENT_SERVER_CERT, DXAGENT_SERVER_KEY)
        
        # Construct our own context so we can restrict the protocol and configure two-way ssl
        server.ssl_adapter.context = ssl.SSLContext(DXAGENT_SSL_PROTOCOL)
        server.ssl_adapter.context.verify_mode = DXAGENT_SSL_VERIFY_MODE
        server.ssl_adapter.context.load_verify_locations(DXAGENT_CA_FILE)
        server.ssl_adapter.context.load_cert_chain(DXAGENT_SERVER_CERT, DXAGENT_SERVER_KEY)
    else:
        try:
            from OpenSSL import SSL
        except ImportError:
            logger.error("You must either install the pyOpenSSL module or upgrade to at least Python 2.7.9 or Python 3.4.")
            exit()
            
        from cherrypy.wsgiserver.ssl_pyopenssl import pyOpenSSLAdapter  
              
        logger.warning("ssl.SSLContext not available in this Python version falling back to TLSv1.")
        logger.warning("Recommend upgrading to at least 2.7.9 or 3.4.")
        
        server.ssl_adapter = pyOpenSSLAdapter(DXAGENT_SERVER_CERT, DXAGENT_SERVER_KEY, DXAGENT_CA_FILE)
        server.ssl_adapter.context = SSL.Context(DXAGENT_SSL_PROTOCOL)
        server.ssl_adapter.context.load_verify_locations(DXAGENT_CA_FILE)
        server.ssl_adapter.context.use_certificate_file(DXAGENT_SERVER_CERT)
        server.ssl_adapter.context.use_privatekey_file(DXAGENT_SERVER_KEY)
        
        def verify_callback(connection, x509, err_num, err_depth, ret_code):
            if not ret_code:
                logger.error("Certificate verification failed. Error No: " + str(err_num))
            return ret_code
        
        server.ssl_adapter.context.set_verify(DXAGENT_SSL_VERIFY_MODE, verify_callback)
    
    cherrypy.server = ServerAdapter(cherrypy.engine, server, bind_addr).subscribe()
    # Disable cherrypy logging config, loaded from DXAGENT_LOGGING_CONF
    cherrypy.config.update({'log.screen': False,
                            'log.access_file': '',
                            'log.error_file': ''})
    cherrypy.engine.unsubscribe('graceful', cherrypy.log.reopen_files)
    cherrypy.engine.signals.subscribe()
    if IS_WINDOWS:
        PIDFile(cherrypy.engine, DXAGENT_PID_FILE).subscribe()
    else:
        Daemonizer(cherrypy.engine).subscribe()
        
    cherrypy.engine.start()
    cherrypy.engine.block()
    
                
if __name__ == "__main__":
    start_cherrypy()