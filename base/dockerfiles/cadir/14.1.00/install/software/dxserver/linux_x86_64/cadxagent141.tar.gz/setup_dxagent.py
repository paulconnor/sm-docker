#
# Copyright (C) 2016 CA Technologies. All Rights Reserved.
#

import sys

PYTHON_VERSION = float(sys.version[:3])    
if PYTHON_VERSION < 2.6:
    logger.error("Dxagent requires Python 2.6 or higher")
    exit()
    
import argparse
import getpass
import os
import platform
import random
import socket
import string
import subprocess
from future.builtins import input
from shutil import rmtree
    
#import pydevd # -- uncomment to debug
#pydevd.settrace("localhost", 5678, suspend=False) # -- uncomment to debug
    
getpass_func = getpass.win_getpass if 'Windows' in platform.system() else getpass.getpass

CURRENT_DIR = os.path.abspath('openssl-ca')
OPENSSL_BINARY = os.path.abspath(os.path.join('bin', 'openssl'))
BASE_DIR = os.path.join(CURRENT_DIR, 'CA')
OUT_DIR = os.path.join(CURRENT_DIR, 'out')
SERIAL_FILE = os.path.join(BASE_DIR, 'serial')
INDEX_FILE = os.path.join(BASE_DIR, 'index.txt')
CERTS_DIRECTORY = os.path.join(BASE_DIR, 'certs')
CA_CERT = os.path.join(BASE_DIR, 'certs', 'ca.pem')
PRIVATE_KEY_DIRECTORY = os.path.join(BASE_DIR, 'private')
CA_KEY = os.path.join(PRIVATE_KEY_DIRECTORY, 'ca.key')
CRL_DIRECTORY = os.path.join(BASE_DIR, 'crl')
CA_CONFIG = os.path.join(CURRENT_DIR, 'openssl-ca.cnf')
REQ_CONFIG = os.path.join(CURRENT_DIR, 'openssl-req.cnf')
OPENSSL_RESPONSES = ['AU', 'Victoria', 'CA Technologies', 'Directory']

def run_openssl(args, responses=list()):
    args = [OPENSSL_BINARY] + args
    popen = subprocess.Popen(args, stdout=subprocess.PIPE, stdin=subprocess.PIPE, cwd=CURRENT_DIR)
    for response in responses:
        popen.stdin.write((response + os.linesep).encode('ascii'))
        popen.stdin.flush()
    popen.wait()
    if popen.returncode:
        sys.exit("Openssl command failed: " + ' '.join(args))
    
def generate_ca():
    
    print("Certificate Authority will be running in directory " + BASE_DIR)
    if os.path.isfile(CA_KEY):
         print("Certificate Authority already exists in " + BASE_DIR)
         return
    
    print("Creating directories and files for the Certificate Authority ... ")
    os.makedirs(BASE_DIR)
    os.makedirs(CERTS_DIRECTORY)
    os.makedirs(PRIVATE_KEY_DIRECTORY)
    os.makedirs(CRL_DIRECTORY)
    with open(SERIAL_FILE, 'w') as serial_file:
        serial_file.write('01')
    open(INDEX_FILE, 'w').close()
    try:
        rmtree(OUT_DIR)
    except Exception:
        pass
    os.makedirs(OUT_DIR)
    responses = list(OPENSSL_RESPONSES)
    responses.append('Root CA for CA Dxagent')
    responses.append(socket.gethostname())
    run_openssl(['req', '-config', CA_CONFIG, '-x509', '-nodes', '-days', '3650', '-newkey', 'rsa:2048', '-out', CA_CERT, '-outform', 'PEM', '-keyout', CA_KEY], responses)
    
    print("Certificate Authority generation complete")
    
def generate_cert(server, file_base_name=socket.gethostname(), password=''):
    confirm_password = password if len(password) > 0 else None
    if server:
        extensions = 'openssl_server_extensions'
    else:
        while len(file_base_name) == 0 or file_base_name.upper() == socket.gethostname().upper():
            file_base_name = input("Enter name for client certificate - this should be different to this machine's name (" + socket.gethostname() + "): ")
        
        while len(password) == 0 or password != confirm_password:
            password = getpass_func("Enter password for client certificate: ")
            confirm_password = getpass_func("Confirm password: ")
            
        extensions = 'openssl_client_extensions'
    
    key_file_name = os.path.join(OUT_DIR, file_base_name + '.key')
    csr_file_name = os.path.join(OUT_DIR, file_base_name + '.csr')
    pem_file_name = os.path.join(OUT_DIR, file_base_name + '.pem')
    p12_file_name = os.path.join(OUT_DIR, file_base_name + '.p12')
    if os.path.isfile(key_file_name):
        print("Certificate already generated for " + file_base_name)
        return
    
    responses = list(OPENSSL_RESPONSES)
    responses.append(file_base_name)
    run_openssl(['req', '-config', REQ_CONFIG, '-extensions', extensions, '-newkey', 'rsa', '-nodes', '-keyout', key_file_name, '-out', csr_file_name, '-outform', 'PEM'], responses)    
    run_openssl(['ca', '-config', CA_CONFIG, '-days', '3650', '-extensions', extensions, '-batch', '-notext', '-in', csr_file_name, '-out', pem_file_name])
    
    print("Your certificate is stored in file - " + pem_file_name)
    print("Your private key is stored in file - " + key_file_name)
    
    if not server:
        run_openssl(['pkcs12', '-export', '-inkey', key_file_name, '-in', pem_file_name, '-out', p12_file_name, '-password', 'pass:' + password])
        print("Your certificate and key are stored in the PKCS12 file - " + p12_file_name)

def get_password(file_name):
    if not os.path.isfile(file_name):
        print("Error: " + file_name + " does not exist")
        exit()
        
    with open(file_name, 'r') as password_file:
        password = password_file.readline()
    
    if len(password) == 0:
        print("Error: " + file_name + " does not contain password text")
        exit()    
        
    for multiplier in range(1, 10):
        for _ in range(10):
            with open(file_name, 'w') as password_file:
                garbage = ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits + string.punctuation) for _ in range(len(password) * multiplier))
                password_file.write(garbage)
            
    os.unlink(file_name)
    return password

parser = argparse.ArgumentParser(description="Setup DXagent")
parser.add_argument('-n', '--name', help='Client certificate name', required=False)
parser.add_argument('-p', '--password-file', help='Client certificate password file', required=False)
args = parser.parse_args()
if args.name and args.name.upper() == socket.gethostname().upper():
    print("Error: Client Certificate name cannot be hostname")
    exit()

password = get_password(args.password_file) if args.password_file else ''
generate_ca()
generate_cert(True)
generate_cert(False, args.name if args.name else '', password)
