#!/bin/sh
THISHOST=`hostname`
#
# CA Technologies DXserver/samples/router
#
# Description:
#   This script configures the Router example.
#

if [ -z "$DXHOME" ]; then
    echo "  You must be the DXserver Administrator to run this script"
    exit 1
fi

#
# Output a summary of the setup.
#
clear
echo
echo " Router sample CA Directory configuration"
echo " ----------------------------------------"
echo
echo " This script will perform the following steps:"
echo
echo "   1. Configure the Router initialization file (router.dxi)."
echo "   2. Configure the Router knowledge file (router.dxc)."
echo "   3. Configure the knowledge group file (sample.dxg)."
echo "   4. Start the Router DXserver DSA."
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 1.
#
clear
echo
echo " Step 1 - Configuring the Router initialization file"
echo " ---------------------------------------------------"
echo
echo "   The Router initialization file router.dxi resides in the directory:"
echo
echo "     $DXHOME/config/servers/"
echo
echo
echo "   Writing the Router initialization file..."
dxserver stop router >/dev/null 2>&1

rm -f router.dxi
cat << EOF > router.dxi
# CA Technologies DXserver/config/servers/router.dxi
#
# Written by samples/router/setup
#
# Sample DXserver initialisation file.

# logging and tracing
source "../logging/default.dxc";

# schema
source "../schema/samples.dxg";

# knowledge
clear dsas;
source "../knowledge/sample.dxg";

# operational settings
source "../settings/default.dxc";

# service limits
source "../limits/default.dxc";

# access controls
clear access;
source "../access/default.dxc";

# ssl
source "../ssld/default.dxc";

EOF

echo "   Router initialization file written"
echo "   Moving the Router initialization file to the servers directory..."
mv router.dxi $DXHOME/config/servers/

echo 
echo " Step 1 completed - Router initialization file configured"
echo 

if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 2.
#
clear
echo
echo " Step 2 - Configuring the Router knowledge file"
echo " ----------------------------------------------"
echo
echo "   The Router knowledge file router.dxc resides in the directory:"
echo
echo "     $DXHOME/config/knowledge/"
echo
echo "   This will be edited to contain this machine's hostname."
echo
echo
echo "   Writing the Router knowledge file..."

rm -f router.dxc
cat << EOF > router.dxc
# CA Technologies DXserver/config/knowledge/router.dxc
#
# Written by samples/router/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command.

set dsa ROUTER =
{
    prefix        = <c AU>
    dsa-name      = <c AU><cn DXserver>
    dsa-password  = "secret"
    address       = tcp "$THISHOST" port 19289
    disp-psap     = DISP
    snmp-port     = 19289
    console-port  = 19290
    auth-levels   = anonymous, clear-password, ssl-auth
    trust-flags   = trust-conveyed-originator
};

EOF

rm -f democorp.dxc
cat << EOF > democorp.dxc
# CA Technologies DXserver/config/knowledge/democorp.dxc
#
# Written by samples/router/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command.

set dsa DEMOCORP =
{
    prefix        = <c AU><o DEMOCORP>
    dsa-name      = <c AU><o DEMOCORP><cn DXserver>
    dsa-password  = "secret"
    address       = tcp "$THISHOST" port 19389
    disp-psap     = DISP
    snmp-port     = 19389
    console-port  = 19390
    auth-levels   = anonymous, clear-password, ssl-auth
    trust-flags   = allow-check-password, trust-conveyed-originator
};

EOF

rm -f unspsc.dxc
cat << EOF > unspsc.dxc
# CA Technologies DXserver/config/knowledge/unspsc.dxc
#
# Written by samples/router/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command

set dsa UNSPSC =
{
     prefix        = <c AU><o UNSPSC>
     dsa-name      = <c AU><o UNSPSC><cn DXserver>
     dsa-password  = "secret"
     address       = tcp "$THISHOST" port 19489
     disp-psap     = DISP
     snmp-port     = 19489
     console-port  = 19490
     auth-levels   = anonymous, clear-password, ssl-auth
     trust-flags   = trust-conveyed-originator
};

EOF

echo "   Router knowledge file written"
echo "   Moving the Router knowledge file to the knowledge directory..."
mv router.dxc $DXHOME/config/knowledge
mv democorp.dxc $DXHOME/config/knowledge
mv unspsc.dxc $DXHOME/config/knowledge

echo
echo " Step 2 completed - Router knowledge file configured"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

clear
echo
echo " Step 3 - Configuring the Router knowledge group file"
echo " ----------------------------------------------------"
echo
echo "   The Router knowledge group file, sample.dxg, resides in the directory:"
echo
echo "     $DXHOME/config/knowledge/"
echo
echo "   It sources knowledge for the Router, DemoCorp and UNSPSC DSAs."
echo
echo
echo "   Writing the Router knowledge group file..."

cat << EOF > sample.dxg
# CA Technologies DXserver/config/knowledge/sample.dxg
#
# sample.dxg written by samples/router/setup.sh
#
# Description:
#   This file shows how DSA knowledge can be grouped and shared.
#   Each of the Router, DemoCorp and UNSPSC DSAs source this file
#   from their initialization file.
#

#
# Source the knowledge file of the Router, Democorp and UNSPSC DSAs.
#
source "router.dxc";
source "democorp.dxc";
source "unspsc.dxc";

EOF

echo "   Router knowledge group file written"
echo "   Moving the knowledge group file to the knowledge directory..."
mv sample.dxg $DXHOME/config/knowledge

echo
echo " Step 3 completed - knowledge group file sample.dxg configured"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 4.
#
clear
echo
echo " Step 4 - Starting the Router DXserver DSA"
echo " -----------------------------------------"
echo
echo "   The command 'dxserver start router' is used to start each DXserver DSA"
echo
echo
echo "   Starting the Router DXserver..."
dxserver stop router >/dev/null 2>&1
sleep 2
dxserver remove router >/dev/null 2>&1
sleep 2
dxserver install router >/dev/null 2>&1
dxserver start router
echo 
echo " Step 4 completed - Router DXserver DSA started"
echo 
if [ "$1" != "-q" ];  then
    echo Press RETURN to continue . . .
    read TMP
fi

echo
echo "  Router sample CA Directory configuration complete." | tee /tmp/status 
echo 
