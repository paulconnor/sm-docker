#!/bin/sh
#
# CA Technologies DXserver/samples/samples.sh
#
# Description:
#   This script runs through a selection of the CA Directory samples.
#
#   If Democorp and UNSPSC have been configured via DXmanager, then the samples
#   load data into Democorp and UNSPSC, otherwise, the text-based sample DSAs
#   Router, Democorp and UNSPSC will be created and loaded.
#
# Usage:
#   samples.sh [Democorp DSA name] [UNSPSC DSA name] [-q|a]
#
# Parameter            Description
# =========            ===========
#
#   Democorp DSA name  Optional: Name of Democorp DSA created via DXmanager
#
#   UNSPSC DSA name    Optional: Name of UNSPSC DSA created via DXmanager
#
#   -q                 Configure the DSA samples automatically
#
#   -a                 Configure all the directory samples prompting between
#                      each
#
#   -aq | -qa          Configure all the directory samples automatically
#
#  Output is logged to the file: /tmp/cadir_<sample>_sample.log
#

#
# checkpoint
#
checkpoint()
{
    echo
    echo "  Samples Setup Terminated."
    exit 1
}

usage()
{
    echo
    echo "Usage:"
    echo "  samples.sh [Democorp DSA name] [UNSPSC DSA name] [-q|a]"
    echo
    exit 1
}

# get_response
# print a prompt message and show the user the default value.
# return the value enter, or a yes/no answer.
#
get_response()
{
    qtype=$1
    while [ 1 ] ; do
        RETURN=""
        echo
        if [ "${qtype}" = "cont" ]; then
            printf "%s" "Press <Return> to Continue"
            read response
            return
        else
            printf "%s" "$QUESTION [${DEFAULT}] "
            read response
            if [ $? != 0 ];  then
                checkpoint
            fi
            if [ "${qtype}" = "ynq" ]; then
                case "${response}" in
                    [Yy]*) RETURN="y"
                           return
                           ;;
                    [Nn]*) RETURN="n"
                           return
                           ;;
                    [Qq]*) checkpoint
                           ;;
                       \?) help_text
                           ;;
                       "") RETURN="${DEFAULT}"
                           return
                           ;;
                esac
            else
                case "${response}" in
                    \?) help_text
                       ;;
                    "") RETURN="${DEFAULT}"
                        return
                        ;;
                     *) RETURN="$response"
                        return
                        ;;
                esac
            fi
        fi
    done
}

if [ -z "$DXHOME" ]; then
    echo "  You must be the DXserver Administrator to run this script"
    exit 1
fi

ROUTER=0
DEMOCORP=1
UNSPSC=1
DXMANAGER=0
QUIET=0
ALL=0

if [ -z "$1" ]; then
    ROUTER=1
elif [ "$1" = "-q"  -o "$1" = "-qa" -o "$1" = "-aq" ]; then
    QUIET=1
    ROUTER=1
elif [ "$3" = "-q"  -o "$3" = "-qa" -o "$3" = "-aq" ]; then
    QUIET=1
    DXMANAGER=1
fi
 
if [ "$1" = "-a"  -o "$1" = "-qa" -o "$1" = "-aq" ]; then
    ALL=1
    ROUTER=1
elif [ "$3" = "-a" -o "$3" = "-qa" -o "$3" = "-aq" ]; then
    ALL=1
    DXMANAGER=1
elif [ ! -z "$1" -a ! -z "$2" -a -z "$3" -a "$2" != "-q" -a "$2" != "-a" \
    -a "$2" != "-qa" -a "$2" != "-aq" ]; then
    DXMANAGER=1
fi

if [ $ROUTER -eq 1 -a $DXMANAGER -eq 1 ]; then
    usage
elif [ $ROUTER -eq 0 -a $DXMANAGER -eq 0 ]; then
    usage
fi

if [ $DXMANAGER -eq 1 ]; then
    DEMOCORPDSA=$1
    UNSPSCDSA=$2
fi

echo ""
echo "  Sample CA Directory configuration"
echo "  ---------------------------------"
echo ""
echo "  This script will configure, install and run the following samples:"
if [ $DXMANAGER -eq 0 ]; then
    echo "    - Router Directory Sample"
fi
echo "    - DemoCorp Directory Sample"
echo "    - UNSPSC Directory Sample"
if [ $ALL -eq 1 ]; then
    echo "    - Test Directory Sample"
if [ $DXMANAGER -eq 0 ]; then # assumes text-based Democorp & UNSPSC samples
    echo "    - SSL Directory Sample"
fi
    echo "    - SNMP Directory Sample"
fi

TEXTSTR=''  # samples run

# file used to record output from samples during execution
rm -f /tmp/status

#
# Router
#
if [ $ROUTER -eq 1 ]; then
    RETURN="y"
    if [ $QUIET -eq 0 ]; then
        QUESTION="  Do you want to setup the Router sample? (y/n/q)"
        DEFAULT="y"
        get_response ynq
        if [ "$RETURN" = "q" ] ; then
            checkpoint
        fi
    fi
    if [ "$RETURN" = "y" ] ; then
        echo
        echo "  Running the Router Sample Setup..."
        cd $DXHOME/samples/router
        date >> /tmp/cadir_router_sample.log 2>&1
        ./setup.sh -q >> /tmp/cadir_router_sample.log 2>&1
        if [ -f /tmp/status ]; then
            cat /tmp/status
        fi
        TEXTSTR="$TEXTSTR Router"
    fi
fi

#
# Democorp
#
if [ $DEMOCORP -eq 1 ]; then
    RETURN="y"
    if [ $QUIET -eq 0 ]; then
        QUESTION="  Do you want to setup the Democorp sample? (y/n/q)"
        DEFAULT="y"
        get_response ynq
        if [ "$RETURN" = "q" ] ; then
            checkpoint
        fi
    fi
    if [ "$RETURN" = "y" ] ; then
        echo
        echo "  Running the DemoCorp Sample Setup..."
        cd $DXHOME/samples/democorp
        echo `date` >> /tmp/cadir_democorp_sample.log 2>&1
        ./setup.sh $DEMOCORPDSA -q >> /tmp/cadir_democorp_sample.log 2>&1
        if [ -f /tmp/status ]; then
            cat /tmp/status
        fi
        TEXTSTR="$TEXTSTR Democorp"
    fi
fi

#
# Unspsc
#
if [ $UNSPSC -eq 1 ]; then
    RETURN="y"
    if [ $QUIET -eq 0 ]; then
        QUESTION="  Do you want to setup the UNSPSC sample? (y/n/q)"
        DEFAULT="y"
        get_response ynq
        if [ "$RETURN" = "q" ] ; then
            checkpoint
        fi
    fi
    if [ "$RETURN" = "y" ] ; then
        echo
        echo "  Running the UNSPSC Sample Setup..."
        cd $DXHOME/samples/unspsc
        echo `date` >> /tmp/cadir_unspsc_sample.log 2>&1
        ./setup.sh $UNSPSCDSA -q >> /tmp/cadir_unspsc_sample.log 2>&1
        if [ -f /tmp/status ]; then
            cat /tmp/status
        fi
        TEXTSTR="$TEXTSTR UNSPSC"
    fi
fi

#
# Test
#
if [ $ALL -eq 1 ]; then
    RETURN="y"
    if [ $QUIET -eq 0 ]; then
        QUESTION="  Do you want to setup the TEST sample? (y/n/q)"
        DEFAULT="y"
        get_response ynq
        if [ "$RETURN" = "q" ] ; then
            checkpoint
        fi
    fi
    if [ "$RETURN" = "y" ] ; then
        echo
        echo "  Running the TEST Sample Setup..."
        cd $DXHOME/samples/test
        echo `date` >> /tmp/cadir_test_sample.log 2>&1
        ./setup.sh -q >> /tmp/cadir_test_sample.log 2>&1
        TEXTSTR="$TEXTSTR Test"
    fi
fi

#
# SSL
#
if [ $ALL -eq 1 -a $DXMANAGER -eq 0 ]; then
    RETURN="y"
    if [ $QUIET -eq 0 ]; then
        QUESTION="  Do you want to setup the SSL sample? (y/n/q)"
        DEFAULT="y"
        get_response ynq
        if [ "$RETURN" = "q" ] ; then
            checkpoint
        fi
    fi
    if [ "$RETURN" = "y" ] ; then
        echo
        echo "  Running the SSL Sample Setup (SHA-2)..."
        cd $DXHOME/samples/ssl
        echo `date` >> /tmp/cadir_ssl_sample.log 2>&1
        ./setup.sh SHA2 -q >> /tmp/cadir_ssl_sample.log 2>&1
        TEXTSTR="$TEXTSTR SSL"
    fi
fi

#
# SNMP
#
if [ $ALL -eq 1 ]; then
    RETURN="y"
    if [ $QUIET -eq 0 ]; then
        QUESTION="  Do you want to setup the SNMP sample? (y/n/q)"
        DEFAULT="y"
        get_response ynq
        if [ "$RETURN" = "q" ] ; then
            checkpoint
        fi
    fi
    if [ "$RETURN" = "y" ] ; then
        echo
        echo "  Running the SNMP Sample Setup..."
        cd $DXHOME/samples/snmp
        echo `date` >> /tmp/cadir_snmp_sample.log 2>&1
        ./dxsnmp localhost/19389 >> /tmp/cadir_snmp_sample.log 2>&1
        TEXTSTR="$TEXTSTR SNMP"
    fi
fi

if [ -n "$TEXTSTR" ]; then 
    echo ""
    echo " $TEXTSTR Sample(s) Configured."
    echo "  Output has been placed in /tmp/cadir_<sample>_sample.log"
    echo ""
    chmod a+w /tmp/cadir_*_sample.log
else
    echo ""
    echo "  No Samples Configured"
fi

exit 0
