#!/bin/sh

###########################################
# Set a variable to use backslashes with  #
# linux                                   #
###########################################

if [ `uname` = "Linux" ]; then          
	LINUX_BS=-e            
fi

if [ -z "$DXHOME" ]; then
    echo "You must be the DXserver Administrator to run this script"
    exit 1
fi

#Check the LANGUAGE if has been set
if [ -z "$LANGUAGE" ]; then
    echo "Error: LANGUAGE variable is not set"
    exit 1
fi

DIR=$DXHOME/samples/languages/$LANGUAGE

echo "Cleaning up the previous dsa..."
cd $DXHOME
if [ -f config/knowledge/$LANGUAGE.dxc ]; then
    rm config/knowledge/$LANGUAGE.dxc
fi
if [ -f config/servers/$LANGUAGE.dxi ]; then
    rm config/servers/$LANGUAGE.dxi
fi

echo "-----------------------------------------------------------------"
echo "Creating a new DSA on port 7777 c=AU o=$LANGUAGE"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
dxnewdsa $LANGUAGE 7777 o=local,c=AU
#check it whether failed
if [ $? != 0 ]; then
    echo "The test of $LANGUAGE language certification failed."
    exit 1
fi

dxserver stop $LANGUAGE

echo "-----------------------------------------------------------------"
echo "Create the custom knowledge file"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
cd $DXHOME/config/knowledge
if [ -f $LANGUAGE.dxc ]; then
    rm $LANGUAGE.dxc;
fi

cat << ! >> $LANGUAGE.dxc
set dsa $LANGUAGE =
{
     prefix        = <c AU><o local>
     dsa-name      = <c AU><o local><cn language>
     dsa-password  = "secret"
     address       = tcp "localhost" port 7777
     disp-psap     = DISP
     cmip-psap     = CMIP
     snmp-port     = 7777
     console-port  = 7778
     ssld-port     = 1112
     auth-levels   = anonymous, clear-password, ssl-auth
     max-idle-time = 60
     trust-flags   = trust-conveyed-originator
};
!


echo "-----------------------------------------------------------------"
echo "Sorting the ldif for load"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
cd "$DIR"
ldifsort $LANGUAGE.ldif $LANGUAGE.ldif.sorted

echo "-----------------------------------------------------------------"
echo "Loading the dsa with ldif data via dxload to check for differences"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
dxloaddb $LANGUAGE $LANGUAGE.ldif.sorted 
#check it whether failed
if [ $? != 0 ]; then
    echo "The test of $LANGUAGE language certification failed."
    exit 1
fi

echo "-----------------------------------------------------------------"
echo "Starting the dsa $LANGUAGE"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
dxserver start $LANGUAGE

echo "-----------------------------------------------------------------"
echo "Running a dxmodify to add entry"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
dxmodify -a -c -hlocalhost -p 7777 -f $LANGUAGE.ldif.modify
#check it whether failed
if [ $? != 0 ]; then
    echo "The test of $LANGUAGE language certification failed."
    exit 1
fi


echo "-----------------------------------------------------------------"
echo "Perform a range of searches and pipe to text file"
echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx
dxsearch -h localhost:7777 -f $LANGUAGE.ldif.ser
#check it whether failed
if [ $? != 0 ]; then
    echo "The test of $LANGUAGE language certification failed."
    exit 1
fi

echo "-----------------------------------------------------------------"
echo "$LANGUAGE sample has been successful"
echo "-----------------------------------------------------------------"

echo "-----------------------------------------------------------------"
echo "To connect, open your ldap/dap browser (jxplorer/jxweb) and "
echo "connect to $LANGUAGE on port 7777"
echo "-----------------------------------------------------------------"

echo "-----------------------------------------------------------------"
echo $LINUX_BS "press return key to continue...\c"
read xx

echo
echo "-----------------------------------------------------------------"
echo "$LANGUAGE sample has completed"
echo "-----------------------------------------------------------------"
echo

