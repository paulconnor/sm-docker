#!/bin/sh

${DXHOME}/bin/dxagent start
VERSION_STRING='CA Directory DXagent 14.1.02.16555'
