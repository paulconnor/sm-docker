#!/bin/sh
#
# CA Technologies DXserver/samples/test
#
# Description:
#   This script configures the Test example.
#

THISHOST=`hostname`

# Command Failed
fail()
{
    echo
    echo " Error running '$1', Test Sample Setup Failed."  | tee /tmp/status
    echo
    exit 1
}

if [ -z "$DXHOME" ]; then
    echo "  You must be the DXserver Administrator to run this script"
    exit 1
fi

#
# Output a summary of the setup.
#
clear
echo
echo " Test sample CA Directory configuration"
echo " --------------------------------------"
echo
echo " This script will perform the following steps:"
echo
echo "   1. Configure the Test initialization file (test.dxi)."
echo "   2. Configure the Test knowledge file (test.dxc)."
echo "   3. Create the Test database."
echo "   4. Start the Test DXserver DSA."
echo "   5. Run the test scripts (1-6) using the DAP DUA."
echo "      The DAP DUA resides in the samples/dua directory."
echo "   6. Run the test scripts (1-6) using the LDAP DUA."
echo "      The LDAP DUA resides in the samples/ldua directory."
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 1.
#
clear
echo
echo " Step 1 - Configuring the Test initialization file"
echo " -------------------------------------------------"
echo
echo "   The Test initialization file test.dxi resides in the directory:"
echo
echo "     $DXHOME/config/servers/"
echo
echo
echo "   Writing the Test initialization file..."
rm -f test.dxi
cat << EOF > test.dxi
# CA Technologies DXserver/config/servers
#
# test.dxi written by samples/test/setup.sh
#
# Sample DXserver initialisation file.
#
# Normally, this file sources one file from each component directory.

# logging and tracing
close summary-log;
close trace-log;
source "../logging/default.dxc";

# schema
clear schema;
source "../schema/samples.dxg";
source "../schema/mhs.dxc";

# knowledge
clear dsas;
source "../knowledge/test.dxc";

# operational settings
source "../settings/default.dxc";

# service limits
source "../limits/default.dxc";

# access controls
clear access;
source "../access/default.dxc";

# replication agreements (rarely used)
# source "../replication/";

# multiwrite DISP recovery
set multi-write-disp-recovery = false;

# cache configuration
set dxgrid-db-location = "data";
set dxgrid-db-size = 100;
set max-cache-size = 100;
set cache-index = all-attributes;
set lookup-cache = true;

EOF

echo "   Test initialization file written"
echo "   Moving the Test initialization file to the servers directory..."
mv test.dxi $DXHOME/config/servers/
echo
echo " Step 1 completed - Test initialization file configured"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 2.
#
clear
echo
echo " Step 2 - Configuring the Test knowledge file"
echo " --------------------------------------------"
echo
echo "   The Test knowledge file test.dxc resides in the directory:"
echo
echo "     $DXHOME/config/knowledge/"
echo
echo "   This will be edited to contain this machine's hostname."
echo
echo
echo "   Writing the Test knowledge file..."
rm -f test.dxc
cat << EOF > test.dxc
# CA Technologies DXserver/config/knowledge
#
# test.dxc written by samples/test/setup.sh
#
# Refer to the Admin Guide for the format of the set dsa command.

set dsa TEST =
{
     prefix        = <>
     dsa-name      = <cn DXserver>
     dsa-password  = "secret"
     address       = tcp "$THISHOST" port 19689,
                     ipv4 localhost port 19689
     disp-psap     = DISP
     snmp-port     = 19689
     console-port  = 19690
     auth-levels   = anonymous, clear-password, ssl-auth
     trust-flags   = trust-conveyed-originator
};

EOF

echo "   Test knowledge file written"
echo "   Moving the Test knowledge file to the knowledge directory..."
mv test.dxc $DXHOME/config/knowledge/
echo
echo " Step 2 completed - Test knowledge file configured"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 3.
#
clear
echo
echo " Step 3 - creating the Test database"
echo " -----------------------------------"
echo
echo "   The command 'dxnewdb test' is used to create each DXserver DSA database"
echo
echo
echo "   Creating the Test database..."
dxemptydb test
echo
echo " Step 3 completed - Test database created"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 4.
#
clear
echo
echo " Step 4 - Starting the Test DXserver DSA"
echo " ---------------------------------------"
echo
echo "   The command 'dxserver start test' is used to start each DXserver DSA"
echo
echo
echo "   Starting the Test DXserver..."
dxserver stop test >/dev/null 2>&1
dxserver start test
if [ $? -ne 0 ]; then
    fail "dxserver start test"
fi
echo
echo " Step 4 completed - Test DXserver DSA started"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 5.
#
clear
echo
echo " Step 5 - Run the test scripts (1-6) using the DAP DUA Directory Client"
echo " ----------------------------------------------------------------------"
echo
echo  "   The command '../dua/dua basic.tests' is used to run the scripts"
echo
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the directory test scripts using the DAP DUA..."
../dua/dua basic.tests
if [ $? -ne 0 ]; then
    fail "../dua/dua basic.tests"
fi
echo
echo " Step 5 completed - Execution of directory tests using the DAP DUA complete"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Step 6.
#
clear
echo
echo " Step 6 - Run the test scripts (1-6) using the LDAP DUA Directory Client"
echo " -----------------------------------------------------------------------"
echo
echo  "   The command '../ldua/ldua basic.tests' is used to run the scripts"
echo
echo
if [ $1 != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi
echo " Executing the directory test scripts using the LDAP DUA..."
../ldua/ldua basic.tests
if [ $? -ne 0 ]; then
    fail "../ldua/ldua basic.tests"
fi

echo
echo " Step 6 completed - Execution of directory tests using the LDAP DUA complete"
echo
if [ "$1" != "-q" ]; then
    echo Press RETURN to continue . . .
    read TMP
fi

#
# Tidy Up.
#
rm -f test.ldi

#
# Stop and remove test
#
dxserver stop test >/dev/null 2>&1
dxserver remove test >/dev/null 2>&1
echo
rm -f $DXHOME/config/knowledge/test.dxc
rm -f $DXHOME/config/servers/test.dxi
rm -f $DXHOME/data/test.db
rm -f $DXHOME/data/test.tx
echo " Test sample CA Directory configuration complete." | tee /tmp/status 
echo

exit 0
