#
# Copyright (C) 2016 CA Technologies. All Rights Reserved.
#
# dxagent_config.py
#
# Contains customized config options for DXagent
# This file is preserved on upgrade
# See dxagent_default_config.py for defaults

import socket
import ssl
