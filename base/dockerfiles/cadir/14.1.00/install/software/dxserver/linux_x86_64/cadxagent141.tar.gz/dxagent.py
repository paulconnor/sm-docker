#
# Copyright (C) 2016 CA Technologies. All Rights Reserved.
#
# dxagent.py
# CA Directory Management REST Service
#
# This script is structured in a way that the main Bottle app is instantiated first. This app
# object is required in REST resource handlers below.
# All entities must be subclasses of BaseEntity (see more comments for this class). This base
# entity class provides the common methods for serializing response in JSON or plain text,
# depending on the request.
# REST resource handlers are defined last. All resource handlers must only return subclasses
# of BaseEntity in its response, no matter if it was a success or failure response. Resource
# handlers must ensure any exception is caught and returned to the client as DsaExceptionEntity.

import sys

PYTHON_VERSION = float(sys.version[:3])    
if PYTHON_VERSION < 2.6:
    logger.error("Dxagent requires Python 2.6 or higher")
    exit()

import bz2
import difflib
import gettext
import gzip
import json
import jsonschema
import locale
import logging
import logging.config
import platform
import socket
import stat
import tarfile
import weakref
from base64 import b64decode, b64encode
from bottle import *
from contextlib import closing
from distutils.version import StrictVersion
from errno import EEXIST
from functools import wraps
from glob import glob
from hashlib import md5
from io import open
from shutil import copyfileobj, copyfile, move, rmtree
from tarfile import TarInfo
        
if PYTHON_VERSION < 3:
    from StringIO import StringIO
else:
    from functools import cmp_to_key
    from io import StringIO
    
# Import configuration, default first and then customized
from dxagent_default_config import *
from dxagent_config import *


#import pydevd # -- uncomment to debug
#pydevd.settrace("localhost", 5678, suspend=False) # -- uncomment to debug

weakReferenceToFilenameMap = dict()  # global variable to hold weakrefences

logger = logging.getLogger("dxagent")
audit = logging.getLogger("dxagent.access")
    
if 'CYGWIN' in platform.system():
    logger.error("CYGWIN Python not supported, requires Windows Native Python")
    exit()

if "DXHOME" in os.environ:
	DXHOME = os.path.abspath(os.environ['DXHOME'])
else:
	DXHOME = "__DXHOME__"

BIN_DIR = os.path.join(DXHOME, 'bin')    
DXSERVER_BINARY = os.path.join(BIN_DIR, 'dxserver')
DXLOADDB_BINARY = os.path.join(BIN_DIR, 'dxloaddb')
DXDUMPDB_BINARY = os.path.join(BIN_DIR, 'dxdumpdb')
DXEMPTYDB_BINARY = os.path.join(BIN_DIR, 'dxemptydb')
DXSYNTAX_BINARY = os.path.join(BIN_DIR, 'dxsyntax')
DXDISP_BINARY = os.path.join(BIN_DIR, 'dxdisp')
DXCERTGEN_BINARY = os.path.join(BIN_DIR, 'dxcertgen')
DXINFO_BINARY = os.path.join(BIN_DIR, 'dxinfo')
DXEXTENDDB_BINARY = os.path.join(BIN_DIR, 'dxextenddb')
# DXconfig shipped with DXagent
DXAGENTHOME = os.path.join(DXHOME, 'dxagent')
DXCONFIG_BINARY = os.path.join(DXAGENTHOME, 'bin', 'dxconfig')
LOCALE_DIR = os.path.join(DXAGENTHOME, 'locale')

SERVERS_FOLDER = os.path.join(DXHOME, 'config', 'servers')
TRANSLATED_METADATA = ['title', 'description']
SCHEMA_CATEGORY_TITLES =  ["dsaLogging", "dsaKnowledge", "dsaSettings", "dsaPasswordPolicies", "dsaMultiPasswordPolicies", "dsaLimits", "dsaSSL", "dsaServer"]
MIN_DXSERVER_VERSION = '12.0.1'
DEFAULT_MAX_RESULTS = 500
DEFAULT_MAX_PREVIOUS_FILES = 7

STATISTICS_PROPERTIES = {"Amount of db file padding in KB" : "filePaddingKB",
                         "Total Datasize in MB" : "datasizeMB",
                         "Number of entries read" : "entriesRead",
                         "Number of entries loaded" : "entriesLoaded",
                         "Average number of entries per MB" : "averageEntriesMB"}

if not (DXAGENT_BASE_URI):
    logger.error("DXAGENT_BASE_URI variable not set in config")
    exit()
else:
    DXAGENT_BASE_URI = DXAGENT_BASE_URI[:-1] if DXAGENT_BASE_URI[-1] == '/' else DXAGENT_BASE_URI

TEMP_DIR = os.path.join(DXAGENTHOME, DXAGENT_TEMP_DIR_PATH.replace('/', os.sep))
try:
    os.makedirs(TEMP_DIR)
except OSError as e:
    if e.errno == EEXIST and os.path.isdir(TEMP_DIR):
        pass
    else:
        raise

app = Bottle()

# ================================================================
#
#  Classes
#
# ================================================================
            
# Custom exception class that extends Exception. Purpose of having this
# class is so we can throw an exception with "errno" instance variable. This is to
# be consistent with built-in exception (ie. OSError) classes that has errno
# member variable. We can then handle custom and built-in exceptions consistently
# in returning a meaningful HTTP error code in the response. 
class DxagentException(Exception):
    def __init__(self, errno, message):
        super(DxagentException, self).__init__(message)
        self.errno = errno


class DxagentDSANotExistError(DxagentException):
    def __init__(self, dsa_name):
        super(DxagentDSANotExistError, self).__init__(2, _("DSA {0} does not exist").format(dsa_name))


class DxagentSyntaxError(DxagentException):
    def __init__(self, syntax_error):
        super(DxagentSyntaxError, self).__init__(22, syntax_error)


class DsaEntityProvider:
    
    @staticmethod
    def get_entities(reg_filter):
        dsas = list()
        pstdout = run_dxserver_cmd([DXSERVER_BINARY, 'status'])
        pairs = pstdout.split(os.linesep)
        regex_pattern = None

        # No DSAs found
        if pstdout == '':
            return dsas

        if reg_filter:
            regex_pattern = re.compile(reg_filter)

        for pair in pairs:
            if pair == '':
                continue
            key_value = pair.split(' ')
            if len(key_value) is not 2:
                logger.warn("unexpected line from 'dxserver status' output: " + pair)
                continue
            if regex_pattern:
                if not regex_pattern.match(key_value[0]):
                    continue
            dsa = DsaEntity(key_value[0])
            dsa.status = key_value[1]
            dsas.append(dsa)

        return dsas


class SimpleFileEntityProvider:

    @staticmethod
    def get_entities(file_filter, simple_file_entity_class):

        if not file_filter:
            file_filter = '*'

        listing = glob(os.path.join(simple_file_entity_class.get_base_dir(), file_filter))

        entities = []
        for file in listing:
            if not file:
                continue
            valid = SimpleFileEntity.is_valid_name(file, simple_file_entity_class)
            if not valid:
                continue

            schema = simple_file_entity_class(os.path.basename(file))
            entities.append(schema)
        return entities


class SchemaEntityProvider:
    
    @staticmethod
    def get_entities(schema_filter):
        return SimpleFileEntityProvider.get_entities(schema_filter, SchemaEntity)

class AccessControlEntityProvider:
    
    @staticmethod
    def get_entities(access_control_filter):
        return SimpleFileEntityProvider.get_entities(access_control_filter, AccessControlEntity)


class PersonalityEntityProvider:
    
    @staticmethod
    def get_entities(pem_filter):
        return SimpleFileEntityProvider.get_entities(pem_filter, PersonalityEntity)


class TrustedCAEntityProvider:
    
    @staticmethod
    def get_entities(ca_filter):
        entities = list()
        pstdout = run_dxserver_cmd([DXCERTGEN_BINARY, 'listca'])
        lines = pstdout.split('\n')
                
        record_started = False
        regex_pattern = None
        if ca_filter:
            regex_pattern = re.compile(ca_filter)
        
        for line in lines:

            if not record_started and not line.startswith('certificate'):
                continue
            elif line.startswith('certificate'):
                properties = {}
                record_started = True
            
            tokens = line.split(':', 1)
                
            properties[tokens[0].strip()] = tokens[1].strip()
            
            if record_started and line.startswith('status'):
                record_started = False

                if regex_pattern:
                    if not regex_pattern.match(properties['certificate']):
                        continue
                
                trusted_ca = TrustedCAEntity(properties)
                entities.append(trusted_ca)
                
        return entities
    
class LogDeltaEntityProvider:
    
    @staticmethod
    def get_entities(log_filter, dsaname, logtype):
        max_results = int(request.query.get('max_results', DEFAULT_MAX_RESULTS))
        if max_results and max_results < 1:
            raise DxagentException(22, _("max_results must be greater than 0."))
        last_entry_time = request.query.get('last_entry_time', None)
        if last_entry_time:        
            # Validate format e.g. 20160720.132302.173
            last_entry_time_split = last_entry_time.split('.')
            if (len(last_entry_time_split) != 3 or len(last_entry_time_split[0]) != 8 
                or len(last_entry_time_split[1]) != 6 or len(last_entry_time_split[2]) != 3):
                raise DxagentException(22, _("Invalid last_entry_time: ") + last_entry_time)
        
        # Try to get the log config. Alarm has a default, if its not found use that
        try:
            log_config = dsa_config = DsaEntity(dsaname).get_config()['logging'][logtype + '-log']
        except KeyError as e:
            if logtype == 'alarm':
                log_config = 'logs/$s_alarm.log'
            else:
                raise DxagentException(22, _("Log Type: {0} not configured on DSA: {1}").format(logtype, dsaname))
        
        # Find all the log files
        log_file_pattern = os.path.join(DXHOME, log_config.replace('$s', dsaname).replace('.log', '*.log').replace('/', os.sep))
        files =  glob(log_file_pattern)
        date_less_name = dsaname + '_' + logtype + '.log'
        
        # If a last entry time was supplied filter out any files older than it
        if last_entry_time:
            last_entry_date = int(last_entry_time.split('.')[0])
            
            def log_file_filter(element):
                file_name = os.path.split(element)[1]
                if date_less_name == file_name:
                    return True
                log_file_date = int(file_name.replace('.log', '').split('_')[-1])
                return log_file_date >= last_entry_date
            
            files = filter(log_file_filter, files)
            
        # Sort the log files in date ascending order and ensure file with no date prefix is last    
        def log_file_sort(x, y):
            file_name_x = os.path.split(x)[1]
            file_name_y = os.path.split(y)[1]
            if date_less_name == file_name_x:
                return 1
            if date_less_name == file_name_y:
                return -1
            if file_name_x == file_name_y:
                return 0
            if int(file_name_x.replace('.log', '').split('_')[-1]) > int(file_name_y.replace('.log', '').split('_')[-1]):
                return 1
            else:
                return -1
            
        files = sorted(files, cmp=log_file_sort) if PYTHON_VERSION < 3 else sorted(files, key=cmp_to_key(log_file_sort))
        
        # We don't want to go back too far into the history
        if len(files) > DEFAULT_MAX_PREVIOUS_FILES:
            del files[:len(files) - DEFAULT_MAX_PREVIOUS_FILES]
        
        ret = list()
        count = 0
        if last_entry_time:
            last_entry_time_tok = last_entry_time.split('.')
            last_entry_found = False
        else:
            last_entry_found = True
            
        # Build the results
        # Will attempt to limit result size to max_results however if the last
        # result falls in the middle of a group of lines with the same date/time
        # we must keep going until we find a new date/time.
        for item in files:
            with open(item, 'r') as log_file:
                for line in log_file.readlines():
                    tokens = line.split(' ')
                    line_date_time = tokens[1]
                    del tokens[0:2]
                    message = ' '.join(tokens).strip()
                    if not last_entry_found:
                        line_date_time_tok = line_date_time.split('.')                        
                        for i in range(3):
                            if int(line_date_time_tok[i]) < int(last_entry_time_tok[i]):
                                break
                            if int(line_date_time_tok[i]) == int(last_entry_time_tok[i]):
                                continue
                            else:
                                last_entry_found = True
                                break
                            
                        if not last_entry_found:
                            continue
                        
                    # Can't close the envelope until find a new date/time
                    if count >= max_results and line_date_time != previous_line_date_time:
                        return ret
                    
                    result = dict()
                    result['time'] = line_date_time
                    result['message'] = message
                    ret.append(result)
                    count += 1
                    previous_line_date_time = line_date_time
            
        return ret

# ================================================================
#
#  Entities
#
# ================================================================

# Base entity that all other entities should extend. This class provides
# common methods to return JSON response.
class BaseEntity:
    
    def __init__(self, name):
        self.name = name
        
    # Returns an array of names of attributes that are returned by default when no
    # return attributes are explicitly specified in a GET request. Subclasses should
    # override this method
    def get_default_return_attributes(self):
        return ['name']
    
    # Checks if "attributes" is specified in the GET request URL. If it is not present
    # then call get_default_return_attributes() to get the default attributes to return.
    def get_return_attributes(self):
        ret_attributes = None

        if request.method == "GET":
            attributes_str = str(request.GET.get("attributes", ''))
            if attributes_str:
                ret_attributes = attributes_str.split(',')

        if not ret_attributes:
            ret_attributes = self.get_default_return_attributes()

        return ret_attributes
    
    # This method is called when constructing a response for this entity. 
    # Subclasses should NOT need to override this method.
    def to_response(self):
        if header_contains("Accept", "application/json") is False:
            return self.to_other()
        else:
            attributes = self.get_return_attributes()
            return self.to_dict(attributes)

    # This is called when returning a non-JSON response.
    # Subclasses should override this method and return a string.
    # The default implementation calls str() on itself
    def to_other(self):
        return str(self)    
        
    # Returns a readable/printable string
    def __str__(self):
        return self.get_name()
    
    # This is called when returning a JSON response.
    # Subclasses should override this method and return a dictionary object.
    def to_dict(self, requested_attributes=list()):
        r = dict()
        r["name"] = self.get_name()
        return r
   
    def get_name(self):
        return self.name


# Exception entity
class DsaExceptionEntity(BaseEntity):
    
    def __init__(self, exception):
        BaseEntity.__init__(self, '')
        self.exception = exception
        
    def get_exception_message(self):
        return type(self.exception).__name__ + ": " + str(self.exception)
    
    def to_dict(self, requested_attributes=list()):
        j = dict()
        j["error"] = dict()
        j["error"]["code"] = self.get_exception_code()
	# Reverting this change as it broke the build tests
        # This line causes the error message returned to the client having the escaped characters
        j["error"]["message"] = html_escape(self.get_exception_message().replace(os.linesep, '.'))
        # j["error"]["message"] = self.get_exception_message().replace('\n', '.')
        return j
    
    def get_exception_code(self):
        return getattr(self.exception, 'errno', 22)  # default to EINVAL: invalid argument
    
    def __str__(self):
        return 'Error ' + 'self.get_exception_code()' + ': ' + self.get_exception_message()
    
    # Maps system errno into a suitable HTTP error code.
    def get_http_error_code(self):
        return {
            1: 403,  # operation not permitted
            2: 404,  # no such file or directory
            13: 403,  # permission denied
            19: 404,  # no such device
            20: 404,  # not a directory
            22: 400  # invalid
        }.get(self.get_exception_code(), 500)


# This is the DSA entity that also has methods to carry out operations for various requests.
# Attributes are not obtained unless requested for performance reason. This happens during
# construction of the response object. 
class DsaEntity(BaseEntity):
    DEFAULT_RET_PROPERTIES = ['config', 'status', 'name']
    
    def __init__(self, name):
        BaseEntity.__init__(self, name)

        if name is None:
            raise DxagentException(22, _('name is mandatory'))

        DsaEntity.check_dsa_name(name)

        self.filename = os.path.join(SERVERS_FOLDER, name + '.dxi')
        self.pid_filename = os.path.join(DXHOME, 'pid', self.name)
        self.is_new = os.path.isfile(self.filename) is False
        self.is_data = None
        self.db_location = None
        
        # Set status to "stopped" if we know this is a new DSA so that get_status can skip
        # run_dxserver_cmd when "status" is being returned in the response.
        if self.is_new:
            self.status = 'stopped'
        else:
            self.status = 'unknown'
            
        self.init_db_location()
            
    def get_default_return_attributes(self):
        return DsaEntity.DEFAULT_RET_PROPERTIES

    def get_name(self):
        if self.is_new:
            raise DxagentDSANotExistError(self.name)
        return self.name

    def run_action(self, action):
        
        if action in [ 'start', 'stop', 'forcestart', 'forcestop', 'init' ]:
            # forcestart is not available in older versions
            if action == 'forcestart':
                action = 'start'
                if os.path.isfile(self.pid_filename):
                    os.unlink(self.pid_filename)
                
            pstdout = run_dxserver_cmd([DXSERVER_BINARY, action, self.name])
        else:
            raise DxagentException(22, _('Invalid action'))
        
        # If dxserver command was successful then map the action performed to a status
        # Note: dxserver init <dsa> will return success even if the DSA was not running
        if action == 'start' or action == 'forcestart':
            self.status = 'started'
        elif action == 'stop' or action == 'forcestop':
            self.status = 'stopped'
    
    def get_status(self):
        # Ideally is_new shouldn't be checked to throw DxagentDSANotExist as this logic is inrun_dxserver_cmd
        # But in this case, the DSA's status may be set to "stopped" for a new DSA that does not yet exist.
        # This is done for performance optimization.
        # So throw DxagentDSANotExist if is_new is True.
        if self.is_new:
            raise DxagentDSANotExistError(self.name)

        if self.status != 'unknown':
            return self.status

        pstdout = run_dxserver_cmd([DXSERVER_BINARY, 'status', self.name])
        # get the last word in the string "<dsa> started/stopped"
        self.status = str(pstdout).replace('\n', '').split(' ')[-1]
        
        if self.status == 'inconsistent':
            with open(self.pid_filename, 'r') as pid_file:
                if 'tx' in pid_file.read():
                    self.status = 'recoverable'
                    
        return self.status
        
    def to_dict(self, requested_attributes=list()):

        r = dict()
        for attr in requested_attributes:
            if attr == 'config':
                r[attr] = self.get_config()
            elif attr == 'name':
                r[attr] = self.get_name()
            elif attr == 'status':
                r[attr] = self.get_status()
        return r
                
    def __str__(self):
        return json_dumps(self.get_config())
            
    # Reads config file into a tempfile object    
    def readToTempfile(self):
        temp_file = tempfile.NamedTemporaryFile(delete=False, dir=TEMP_DIR)
        with open(self.filename, 'rb') as originalFile:
            original_content = originalFile.read()
            temp_file.write(original_content)
        return temp_file

    # Restores the contents from tempfile into config
    def restore_from_temp_file(self, temp_file):
        temp_file.seek(0)
        with open(self.filename, 'wb') as originalFile:
            originalContent = temp_file.read()
            originalFile.write(originalContent)
    
    def check_dxsyntax(self):
        run_dxserver_cmd([DXSYNTAX_BINARY, self.name])

    def validate_request(self, jsonRequest):
        # don't need to do the tranlation for the schema validation
        dsaSchema = get_dsa_config_schema()
        try:
            jsonschema.validate(jsonRequest, dsaSchema)
        except jsonschema.exceptions.ValidationError as e:
            # last path would contain the offended property
            offendedProperty = e.path[-1]
            # log the full message of the exception, but only return the message and the offended property
            logger.error(e)
            # get rid of the any 'u so that the error message is more readable
            errorMsg = e.message.replace("u'", "'")
            raise DxagentException(22, _("Schema validation failed on property '{0}': {1}").format(offendedProperty, errorMsg))
        
    def create_from_request(self):
        if self.is_new is False:
            raise DxagentException(22, _("DSA {0} already exist").format(self.name))
        
        self.validate_request(request.json)
        
        # config is mandatory when creating a new DSA
        config = request.json.get("config", None)
        if config:
            self.set_config(config)
        else:
            raise DxagentException(22, _("config is mandatory"))
        
        # install the DSA
        run_dxserver_cmd([DXSERVER_BINARY, 'install', self.name])
        
    # This is the method called when updating a DSA. Setting of all attributes
    # are handled here.
    def update_from_request(self):
        if self.is_new:
            raise DxagentDSANotExistError(self.name)
            
        self.validate_request(request.json)
        
        # are we updating config?
        config = request.json.get("config", None)
        if config:
            self.set_config(config)
        
    def init_db_location(self):
        self.db_location = None
        self.is_data = False
        if not self.is_new:
            config = self.get_config()
            if 'server' in config:
                self.db_location = config['server'].get('dxgrid-db-location', None)
                if self.db_location and not os.path.isabs(self.db_location):
                    self.db_location = os.path.join(DXHOME, self.db_location)
                self.is_data = config['server'].get('lookup-cache', False)
    
    def get_db_location(self):
        return self.db_location
    
    def is_data_dsa(self):
        return self.is_data

    def get_dxi_config(self):
        try:
            with open(self.filename, 'r') as fd:
                return fd.read()
        except IOError as ie:
            if ie.errno is 2:
                raise DxagentDSANotExistError(self.name)
            else:
                raise ie
    
    def get_config(self):
        return json.loads(run_dxconfig_cmd([DXCONFIG_BINARY, DXSERVER_VERSION, "GET", self.name]))
        
    def set_config(self, new_content):
        temp_file = None
        self.runExtendDB = False
        try:
            # If this is an existing DSA, then backup its config into temp_file
            if not self.is_new:
                temp_file = self.readToTempfile()

            server = new_content.get('server', None)
            if server:
                dbSize = server.get('dxgrid-db-size', None)
                if dbSize and dbSize < 0:
                    new_content['server']["dxgrid-db-size"] = dbSize * -1
                    self.runExtendDB = True
    
            process_version_specific_kludges(new_content)
            new_content_str = json.dumps(new_content)
            
            # Write the new content
            if request.method.upper() == "POST" or request.method.upper() == "PUT":
                run_dxconfig_cmd([DXCONFIG_BINARY, DXSERVER_VERSION, request.method, self.name, "-i"], False, new_content_str.encode())
            else:
                run_dxconfig_cmd([DXCONFIG_BINARY, DXSERVER_VERSION, request.method, self.name, new_content_str])
            
            # Check syntax of the new config. Will throw DxagentSyntaxError if "dxsyntax" fails
            self.check_dxsyntax()
            self.is_new = False
            if self.runExtendDB == True:
                logger.info("dxgrid-db-size got changed running dxextenddb")
                run_dxserver_cmd([DXEXTENDDB_BINARY, self.name])

            self.init_db_location()

        except DxagentSyntaxError as syntax_exception:
            # If syntax validation failed, then restore config from temp_file if one exists
            if temp_file:
                self.restore_from_temp_file(temp_file)
            
            # If this is a new DSA then delete the newly-written config file as it is bad
            if self.is_new and os.path.isfile(self.filename):
                os.unlink(self.filename)
            raise syntax_exception

        finally:
            # Finally, delete the temp_file in all cases
            if temp_file:
                temp_file.seek(0)
                original_config = temp_file.readlines()
                with open(self.filename, 'rb') as new_config_file:
                    new_config = new_config_file.readlines()

                if original_config[0] and type(original_config[0]) is not str:
                    # Python3 bytes convert to str
                    original_config = [litem.decode('utf-8') for litem in original_config]
                    new_config = [litem.decode('utf-8') for litem in new_config]

                diff_string = ''.join(difflib.unified_diff(original_config, new_config, fromfile=self.filename,
                                                          tofile=self.filename, lineterm='\n'))
                audit.info("DSA Configuration Diff:\n" + diff_string)
                temp_file.close()
                os.unlink(temp_file.name)
    
    def delete(self):
        # Stop dsa first
        if self.get_status() != 'stopped':
            self.run_action('forcestop')

        # Delete db file?
        delete_db = request.GET.get('delete_db', '')
        if self.db_location and (delete_db == '1' or delete_db == 'true'):
            try:
                db = DsaDBEntity(self.name)
                db.delete()
            except (DxagentException, OSError):
                pass
        
        delete_db_all = request.GET.get('delete_db_all', '')
        if self.db_location and (delete_db_all == '1' or delete_db_all == 'true'):
            try:
                db = DsaDBEntity(self.name)
                db.delete()
                zdb = DsaDBEntity(self.name, True)
                zdb.delete()
            except (DxagentException, OSError):
                pass
        try:
            os.remove(self.filename)
        except OSError as os_error:
            if os_error.errno is not 2:
                raise DxagentException
            else:
                raise DxagentDSANotExistError(self.name)  # should do this in the handler instead?

        self.is_new = True
            
        # remove the DSA
        run_dxserver_cmd([DXSERVER_BINARY, 'remove', self.name])
        
    @staticmethod    
    def check_dsa_name(name):
        re_name_validation = re.compile(r"[a-zA-Z0-9_\-\.]+$")
        if re_name_validation.match(name) is None:
            raise DxagentException(22, 'Invalid name')
        
class DsaStatusEntity(BaseEntity):
    
    DEFAULT_RET_PROPERTIES = ['name', 'status']
    
    def __init__(self, name, online=False):
        BaseEntity.__init__(self, name)
        
        self.parent_dsa = DsaEntity(self.name)
        
    def get_default_return_attributes(self):
        return DsaStatusEntity.DEFAULT_RET_PROPERTIES
        
    def to_dict(self, requested_attributes=list()):
        
        return self.parent_dsa.to_dict(requested_attributes)
    
    def update_from_request(self):
        
        action = request.json.get('action', None)
        if action:
            self.parent_dsa.run_action(action)
        else:
            raise DxagentException(22, _("action is mandatory"))

class DsaDataEntity(BaseEntity):
    
    def __init__(self, name, online=False):
        BaseEntity.__init__(self, name)
        
        self.parent_dsa = DsaEntity(self.name)
        if not self.parent_dsa:
            raise DxagentException(22, _("Data must belong to a DSA"))
        if not self.parent_dsa.is_data_dsa() :
            raise DxagentException(22, _("{0} is not a data DSA").format(self.parent_dsa.get_name()))
        if not self.parent_dsa.get_db_location() :
            raise DxagentException(22, _("{0} has no data location defined").format(self.parent_dsa.get_name()))
        
        if request.query.online == "true" or online:
            self.extension = ".zdb"
            self.online = True
        else:
            self.extension = ".db"
            self.online = False
            
        self.db_filename = self.parent_dsa.get_name() + self.extension
        self.db_file = os.path.join(self.parent_dsa.get_db_location(), self.db_filename)
        
    def to_response(self):
        
        data_file = self.get_data()
        
        if header_contains('Accept', "*/*") or header_contains('Accept', "application/octet-stream"):
            return_file = data_file
            response.content_type = "application/octet-stream"
            extension = ''
        elif header_contains('Accept', "application/x-bzip2"):
            return_file = auto_delete_file(bz2_compress(data_file.name))
            data_file.close()
            response.content_type = "application/x-bzip2"
            extension = '.bz2'
        elif header_contains('Accept', "application/x-gzip"):
            return_file = auto_delete_file(gzipCompress(data_file.name))
            data_file.close()
            response.content_type = "application/x-gzip"
            extension = '.gz'

        response.content_length = os.path.getsize(return_file.name)
        response["Content-MD5"] = file_md5(return_file.name)
        response["Content-Disposition"] = "attachment; filename=" + self.get_data_filename() + extension

        return return_file
    
    def create_from_request(self):
        
        data = request.body
        
        try:
            # StringIO/ByteIO e.g. LDIF file
            data_length = len(data.getvalue())
        except Exception as e:
            # file, "instance"
            # Can't use os.path.getsize(data.name) because name not set correctly on data
            data_length = os.fstat(data.fileno()).st_size
                
        header_md5 = request.headers.get("Content-MD5")
        header_length = request.content_length
        passPhrase = request.headers.get("passPhrase")

        if header_md5:
            data_md5 = stream_md5(data)
            data.seek(0)
            if header_md5 != data_md5:
                raise DxagentException(22, _("Data MD5 mismatch {0} <> {1}").format(header_md5, data_md5))
            
        if header_length and header_length != data_length:
            raise DxagentException(22, _("Data length mismatch {0} <> {1}").format(str(header_length), str(data_length)))
        
        if data_length > 0:
            if header_contains('Content-Type', "application/x-bzip2"):
                data_file_name = bz2_de_compress(data)
            elif header_contains('Content-Type', "application/x-gzip"):
                data_file_name = gzip_de_compress(data)
            else:
                data_file_name = save_to_tempfile(data)
                
            self.load_data(data_file_name, passPhrase)
        else:
            raise DxagentException(22, _("Empty Request Body"))
            
    def get_db_file(self):
        return self.db_file
        

class DsaDBEntity(DsaDataEntity):
    
    def __init__(self, name, online=False):
        DsaDataEntity.__init__(self, name, online)
        
        self.accessory_file_extensions = ['.tx', '.dp', '.dx']
        
    def update_from_request(self):
        
        self.empty_data()
        
    def get_data(self):
        
        self.checkOffline(True)
                
        if not self.db_exists():
            raise DxagentException(2, _("DB file {0} does not exist").format(self.db_file))
        
        return open(self.db_file , 'rb')
    
    def get_data_filename(self):
        
        return self.db_filename
    
    # Added new argument passphrase which is not used in this class load_data
    # Added to fix build error as the same method with passphrase is used in
    # other class DsaLDIFEntity
    def load_data(self, data_file_name, passphrase):
        try:
            self.checkOffline()
        except DxagentException as e:
            os.unlink(data_file_name)
            raise e
            
        if self.db_exists():
            self.delete()
        # TODO Some kind of db file validation
        move(data_file_name, self.db_file)
        
        # On windows if we have pywin32 give Local Service user full access
        try:
            import win32security
            import ntsecuritycon as con
            
            local_service_user, domain, type = win32security.LookupAccountName (None, "LOCAL SERVICE")
            sd = win32security.GetFileSecurity(self.db_file, win32security.DACL_SECURITY_INFORMATION)
            dacl = sd.GetSecurityDescriptorDacl()
            dacl.AddAccessAllowedAce(win32security.ACL_REVISION, con.FILE_ALL_ACCESS, local_service_user)        
            sd.SetSecurityDescriptorDacl(1, dacl, 0)
            win32security.SetFileSecurity(self.db_file, win32security.DACL_SECURITY_INFORMATION, sd)
        except ImportError:
            pass
        
    def empty_data(self):
        
        run_dxserver_cmd([DXEMPTYDB_BINARY, self.parent_dsa.get_name()])
        
    def delete(self):
        
        self.checkOffline()
        
        if not self.online:
            for extension in self.accessory_file_extensions:
                file_name = os.path.join(self.parent_dsa.get_db_location(), self.parent_dsa.get_name() + extension)
                if os.path.isfile(file_name):
                    os.unlink(file_name)
        
        # Delete after accessory files incase DB file has already been deleted
        os.unlink(self.db_file)
        
    def db_exists(self):
        return os.path.isfile(self.db_file)
        
    def checkOffline(self, strict=False):
        if self.online:
            return
        
        if strict and self.parent_dsa.get_status() != 'stopped':
            raise DxagentException(22, _("DSA {0} is online or inconsistent").format(self.name))
        elif self.parent_dsa.get_status() == 'started':
            raise DxagentException(22, _("DSA {0} is online").format(self.name))
            
        
class DsaLDIFEntity(DsaDataEntity):
    
    def __init__(self, name, online=False):
        DsaDataEntity.__init__(self, name, online)
        
    def get_data(self):
        
        ldif_file = auto_delete_file(tempfile.NamedTemporaryFile(delete=False, prefix="dxagentLDIF", dir=TEMP_DIR).name)

        try:
            if StrictVersion(DXSERVER_VERSION) >= StrictVersion ('14.1.00'):
                passPhrase = request.headers.get("passPhrase")
                if(self.online):
                    if passPhrase:
                        run_dxserver_cmd([DXDUMPDB_BINARY, "-p", passPhrase, "-f", ldif_file.name, "-z", self.parent_dsa.get_name()])
                    else:
                        run_dxserver_cmd([DXDUMPDB_BINARY, "-c", "-f", ldif_file.name, "-z", self.parent_dsa.get_name()])
                else:
                    if passPhrase:
                        run_dxserver_cmd([DXDUMPDB_BINARY, "-p", passPhrase, "-f", ldif_file.name, self.parent_dsa.get_name()])
                    else:
                        run_dxserver_cmd([DXDUMPDB_BINARY, "-c", "-f", ldif_file.name, self.parent_dsa.get_name()])
            else:
                if(self.online):
                    run_dxserver_cmd([DXDUMPDB_BINARY, "-f", ldif_file.name, "-z", self.parent_dsa.get_name()])
                else:
                    run_dxserver_cmd([DXDUMPDB_BINARY, "-f", ldif_file.name, self.parent_dsa.get_name()])

        except Exception:
            ldif_file.close()
            raise
            
        return ldif_file
    
    def get_data_filename(self):
        
        return self.parent_dsa.get_name() + ('.zdb.ldif' if self.online else '.ldif')
    
    def load_data(self, data_file_name, passPhrase):
        
        # Need this placeholder so that the weakref is still in context but
        # will be deleted if there is an exception
        file_placeholder = auto_delete_file(data_file_name)
        # Must close file or on Windows it won't delete
        file_placeholder.close()
        try:
            if passPhrase:
                pstdout = run_dxserver_cmd([DXLOADDB_BINARY, "-p", passPhrase,  "-s", self.name, data_file_name])
            else:
                pstdout = run_dxserver_cmd([DXLOADDB_BINARY, "-s", self.name, data_file_name])
        except Exception as e:
            error_msg = str(e)
            raise Exception(error_msg.replace('\t', ''))
        
        self.json_response = self.parse_load_statistics(pstdout)

    def parse_load_statistics(self, pstdout):
        r = dict()
        lines = pstdout.split('\n')
    
        for line in lines:
            if line == '':
                continue
            tokens = line.split(':')
            if len(tokens) is not 2:
                continue
            try:
                value = int(tokens[1].strip())
                r[STATISTICS_PROPERTIES.get(tokens[0])] = value
            except Exception:
                pass
    
        return r
    
    def to_response(self):
        try:
            return self.json_response
        except Exception:
            return DsaDataEntity.to_response(self)
        
    def empty_data(self):
        
        raise DxagentException(22, _("Missing LDIF data."))
        
# An online backup is an online dump/backup of DSA data. This is treated as a sub-resource
# of a DSA   
class DsaOnlineBackupEntity(DsaDataEntity):
    DEFAULT_RET_PROPERTIES = ['status', 'utcTimestamp']
    
    def __init__(self, name):

        DsaDataEntity.__init__(self, name, True)

        self.onlinebackupTempFilename = os.path.join(self.parent_dsa.get_db_location(), self.parent_dsa.get_name() + ".zd$")
        
    def get_default_return_attributes(self):
        return DsaOnlineBackupEntity.DEFAULT_RET_PROPERTIES
        
    def create_from_request(self):
        run_dxserver_cmd([DXSERVER_BINARY, "onlinebackup", self.parent_dsa.get_name()])
        
    def update_from_request(self):
        if self.get_status() == "ready":
            db = DsaDBEntity(self.name)
            if db.db_exists():
                db.delete()
            copyfile(self.db_file, db.get_db_file())
        elif self.get_status() == "in progress":
            raise DxagentException(2, _("Onlinebackup in progress"))
        else:
            raise DxagentException(2, _("Onlinebackup not available"))
        
    def to_response(self):
        return BaseEntity.to_response(self)
    
    def get_status(self):
        if os.path.isfile(self.onlinebackupTempFilename):
            return "in progress"
        if os.path.isfile(self.db_file):
            return "ready"
        else:
            return "unavailable"
    
    def getUtcTimestamp(self):
        if self.get_status() == 'ready':
            mtime = os.path.getmtime(self.db_file)
            # Manually format UTC time. Value returned from isoformat() method is not correct...
            utime = datetime.utcfromtimestamp(mtime).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            return utime

        return None
    
    def to_dict(self, requested_attributes=list()):

        r = dict()

        for attr in requested_attributes:
            if attr == "status":
                r[attr] = self.get_status()
            if attr == "utcTimestamp":
                ts = self.getUtcTimestamp()
                if ts:
                    r[attr] = str(ts)
        return r
                
    def __str__(self):
        return self.db_file


# A DxserverInfo encapsulates informationa about the CA Directory Dxserver
# installed on the host machine
class DxserverInfo(BaseEntity):
    DEFAULT_RET_PROPERTIES = ['name', 'version']
    
    def __init__(self, name=None):
        BaseEntity.__init__(self, 'CA Directory')
    
    def get_default_return_attributes(self):
        return DxserverInfo.DEFAULT_RET_PROPERTIES
        
    def get_version(self):
        return run_dxserver_cmd([DXSERVER_BINARY, 'version'])
    
    def get_normalized_version(self):
        return DxserverInfo.normalize_version(self.get_version())

    def get_dsa_schema(self):
        return get_dsa_config_schema()
    
    def get_dsa_actions(self):
        return [elem for elem in get_supported_actions() if '/dsas/' in elem['endpoint']]
    
    def get_dxserver_actions(self):
        return [elem for elem in get_supported_actions() if '/dsas/' not in elem['endpoint']]
    
    def to_dict(self, requested_attributes=list()):

        r = dict()

        for attr in requested_attributes:
            if attr == "name":
                r[attr] = self.name
            if attr == "version":
                r[attr] = self.get_version()
            if attr == "normalizedVersion":
                r[attr] = self.get_normalized_version()
            if attr == "dsaSchema":
                r[attr] = self.get_dsa_schema()
            if attr == "dsaActions":
                r[attr] = self.get_dsa_actions()
            if attr == "dxserverActions":
                r[attr] = self.get_dxserver_actions()

        return r
                
    def __str__(self):
        return self.name
    
    @staticmethod
    def normalize_version(version):
        tokens = version.strip().split()
        normalized_version = tokens[1][len('r'):] if tokens[1].lower().startswith('r') else tokens[1]
        if tokens[2].upper().startswith('SP'):
            normalized_version += '.' + tokens[2][len('SP'):]
            
        # Version string before SP10 did not include SP    
        if normalized_version == '12.0':
            for i in range(len(tokens)):
                if 'build' in tokens[i]:
                    build_string = tokens[i+1]
                    break
            found_build = int(build_string[0:len(build_string)-1] if build_string.endswith(')') else build_string)
            if found_build < 2441:
                return normalized_version
            
            build_to_version = {2441 : '12.0.1', 4076 : '12.0.2', 4346 : '12.0.3',
                                4457 : '12.0.4', 4574 : '12.0.5', 6058 : '12.0.6',
                                6275 : '12.0.7', 6484 : '12.0.8', 6667 : '12.0.9'}
            builds = list(build_to_version.keys())
            builds.sort()
            for build in builds:
                if found_build >= build:
                    normalized_version = build_to_version[build]
                else:
                    break
                
        return normalized_version


# Log file that belongs to a DSA. Can only get/retrieval of log contents.
# TODO: Expose an endpoint for this
class DsaLog(BaseEntity):
    DEFAULT_RET_PROPERTIES = ['data']
    
    def __init__(self, parent_dsa, log_name):
        BaseEntity.__init__(self, parent_dsa.get_name() + '_' + log_name)
        self.parent_dsa = parent_dsa
        self.filename = os.path.join(DXHOME, 'logs', parent_dsa.get_name() + '_' + log_name + '.log')
        
    def get_default_return_attributes(self):
        return DsaLog.DEFAULT_RET_PROPERTIES
    
    def to_dict(self, requested_attributes=list()):
        r = dict()

        for attr in requested_attributes:
            if attr == 'name':
                r[attr] = self.get_name()
            if attr == 'data':
                data = self.getLog()
                if type(data) is str:
                    # For Python3
                    # TODO: Check what content type is appropriate here
                    r[attr] = b64encode(data.encode('utf-8')).decode('utf-8')
                else:
                    r[attr] = b64encode(data)

        return r
    
    def __str__(self):
        return self.getLog()
    
    def getLog(self):
        with open(self.filename) as fd:
            return fd.read()


# Simple file
class SimpleFileEntity(BaseEntity):
    DEFAULT_RET_PROPERTIES = ['name', 'readOnly']

    def __init__(self, name):
        BaseEntity.__init__(self, name)
        
        self.set_file_name(name)
        self.is_new = os.path.isfile(self.filename) is False

        if not SimpleFileEntity.is_valid_name(name, self.__class__):
            raise DxagentException(22, _("Invalid name. Must have an extension that matches one of the following: ") +
                                   str(self.get_valid_extensions()))
        
    def get_default_return_attributes(self):
        return SimpleFileEntity.DEFAULT_RET_PROPERTIES
    
    def to_dict(self, requested_attributes=list()):
        r = dict()

        for attr in requested_attributes:
            if attr == "name":
                r[attr] = self.get_name()
            if attr == "readOnly":
                r[attr] = self.is_read_only()
            if attr == "data":
                data = self.getData()
                if type(data) is bytes:
                    # For Python3
                    r[attr] = b64encode(data).decode('utf-8')
                else:
                    r[attr] = b64encode(data)

        return r
    
    def __str__(self):
        return self.getData()
    
    def getData(self):
        try:
            with open(self.filename, 'rb') as fd:
                data = fd.read()
                return data
        except IOError as ie:
            if ie.errno is 2:
                raise DxagentException(22, _("{0} does not exist").format(self.name))
    
    def set_data(self, new_content):
        with open(self.filename, 'wb') as fd:
            fd.write(new_content)

        hasher = md5()
        hasher.update(new_content)
        audit.info(self.type_string + " MD5:\n" + hasher.hexdigest() + "  " + self.filename)
    
    def is_read_only(self):
        try:
            mode = os.stat(self.filename).st_mode
            return not ((mode & stat.S_IWUSR) == stat.S_IWUSR)
        except OSError as oe:
            if oe.errno is 2:
                raise DxagentException(22, _("{0} does not exist").format(self.name)) 
    
    def create_from_request(self):
        if self.is_new is False:
            raise DxagentException(22, _("{0} already exists").format(self.name))
        
        # data is mandatory when creating a new file
        data = request.json.get("data", None)
        if data is not None:
            self.set_data(b64decode(data))
        else:
            raise DxagentException(22, _("data is mandatory"))

    # This is the method called when updating a file. Setting of all attributes are hanlded here.
    def update_from_request(self):
        if self.is_new:
            raise DxagentException(22, _("{0} does not exist").format(self.name)) 
        
        if self.is_read_only():
            raise DxagentException(22, _("{0} is read only").format(self.name))
        
        data = request.json.get("data", None)
        if data is not None:
            self.set_data(b64decode(data))
        else:
            raise DxagentException(22, _("data is mandatory"))
            
    def delete(self):
        if self.is_new:
            raise DxagentException(22, _("{0} does not exist").format(self.name)) 
        
        if self.is_read_only():
            raise DxagentException(22, _("{0} is read only").format(self.name)) 
        
        os.remove(self.filename)
        
    def set_file_name(self, name):
        
        # Only use the last part to prevent malicious paths e.g. ../../something
        name = os.path.split(name)[-1]
        if len(name) == 0:
            raise DxagentException(22, _("Invalid name ") + self.name)
        
        self.filename = os.path.join(self.basedir, name)
        
        file_path = os.path.abspath(self.filename)
        checkBase = os.path.dirname(file_path)

        if self.basedir.find(checkBase) is not 0:
            raise DxagentException(22, _("Invalid name ") + self.name)
        
    @staticmethod
    def is_valid_name(name, simple_file_entity_class):
        valid = False

        for extension in simple_file_entity_class.get_valid_extensions():
            if name.endswith(extension):
                valid = True
                break

        return valid
    
    @staticmethod
    def get_valid_extensions():
        return []


# Schema file
class SchemaEntity(SimpleFileEntity):
    
    def __init__(self, name):
        self.basedir = SchemaEntity.get_base_dir()
        self.type_string = "Schema"
        SimpleFileEntity.__init__(self, name)

    @staticmethod
    def get_base_dir():
        return os.path.join(DXHOME, 'config', 'schema')
    
    @staticmethod
    def get_valid_extensions():
        return ['.dxc', '.dxg']
    

# Access Control file
class AccessControlEntity(SimpleFileEntity):
    
    def __init__(self, name):
        self.basedir = AccessControlEntity.get_base_dir()
        self.type_string = "Access Control"
        SimpleFileEntity.__init__(self, name)

    @staticmethod
    def get_base_dir():
        return os.path.join(DXHOME, 'config', 'access')
    
    @staticmethod
    def get_valid_extensions():
        return ['.dxc', '.dxg']


# Personality file
class PersonalityEntity(SimpleFileEntity):
    
    def __init__(self, name):
        self.basedir = PersonalityEntity.get_base_dir()
        self.type_string = "Personality"
        SimpleFileEntity.__init__(self, name)

    @staticmethod
    def get_base_dir():
        return os.path.join(DXHOME, 'config', 'ssld', 'personalities')
    
    @staticmethod
    def get_valid_extensions():
        return ['.pem']


# Trusted CA
class TrustedCAEntity(BaseEntity):
    DEFAULT_RET_PROPERTIES = \
        ["certificate", "version", "serialNum", "issuer", "notBefore", "notAfter", "subject", "status"]
    
    def __init__(self, properties):
        BaseEntity.__init__(self, properties["certificate"])
        self.properties = properties
        
    def get_default_return_attributes(self):
        return TrustedCAEntity.DEFAULT_RET_PROPERTIES
    
    def to_dict(self, requested_attributes=list()):
        return self.properties
    
    def delete(self):
        pstdout = run_dxserver_cmd([DXCERTGEN_BINARY, "-r", self.name, "removeca"])
        
    def create_from_request(self):
        # data is mandatory when creating a new Schema
        data = request.json.get("data", None)
        if data:
            self.set_data(b64decode(data))
        else:
            raise DxagentException(22, _("data is mandatory"))
        
    def set_data(self, new_content):
        temp_file = auto_delete_file(tempfile.NamedTemporaryFile(delete=False, prefix="dxagentTrustedCA", dir=TEMP_DIR).name, "wb")
        temp_file.write(new_content)
        temp_file.flush()
        temp_file.close()
            
        pstdout = run_dxserver_cmd([DXCERTGEN_BINARY, "-n", temp_file.name, "importca"])

        hasher = md5()
        hasher.update(new_content)
        audit.info("Trusted CA MD5:\n" + hasher.hexdigest())

# Wraps execution of dxinfo tool
class DxInfoEntity(BaseEntity):
    
    def __init__(self, name):

        BaseEntity.__init__(self, name)
        
    def to_response(self):
        
        temp_output_dir = auto_delete_dir(tempfile.mkdtemp(prefix='dxagentDxinfo', dir=TEMP_DIR))
        cmd_list = [DXINFO_BINARY, "-t", temp_output_dir.name + os.sep]
        
        for param, cmd_option in zip(['date', 'exclude'], ['-d', '-x']):
            value = request.GET.get(param, None)
            if value:
                cmd_list.append(cmd_option)
                cmd_list.append(value)
        
        run_dxserver_cmd(cmd_list)
        
        if header_contains('Accept', "*/*") or header_contains('Accept', "*/*") == None or header_contains('Accept', "application/x-gzip"):
            response.content_type = "application/x-gzip"
            extension = '.gz'
            mode = 'w:gz'
        elif header_contains('Accept', "application/x-bzip2"):
            response.content_type = "application/x-bzip2"
            extension = '.bz2'
            mode = 'w:bz2'        
        
        temp_tar_file = auto_delete_file(tempfile.NamedTemporaryFile("wb", delete=False, prefix="dxagentDxinfoTar", dir=TEMP_DIR).name)
        # Must use closing for python 2.6 support
        with closing(tarfile.open(temp_tar_file.name, mode)) as tar:
            for f in glob(os.path.join(temp_output_dir.name, '*')):
                tarinfo = TarInfo(os.path.split(f)[-1])
                tarinfo.size = os.path.getsize(f)
                with open(f, 'rb') as f_file:
                    tar.addfile(tarinfo, f_file)

        response.content_length = os.path.getsize(temp_tar_file.name)
        response["Content-MD5"] = file_md5(temp_tar_file.name)
        response["Content-Disposition"] = "attachment; filename=dxinfo.tar" + extension
        
        return temp_tar_file
    
class DsaLogRollEntity(BaseEntity):
    
    def __init__(self, name):
        BaseEntity.__init__(self, name)        
        self.parent_dsa = DsaEntity(self.name)
        
    def create_from_request(self):
        run_dxserver_cmd([DXSERVER_BINARY, "logroll", self.parent_dsa.get_name()])
    
class DxdispEntity(BaseEntity):
    
    def __init__(self, name):
        BaseEntity.__init__(self, name)
        
    def create_from_request(self):
        dsaname = request.json.get('peerDsa', None)
        if dsaname is None:
            raise DxagentException(22, _('A dsa must be specified'))

        DsaEntity.check_dsa_name(dsaname)

        run_dxserver_cmd([DXDISP_BINARY, dsaname])

# ================================================================
#
#  Global functions
#
# ================================================================


def file_md5(filename):
    f = open(filename, 'rb')
    logger.debug("hashing " + filename)

    stream_md5(f)

    f.close()
    
def stream_md5(stream):
    hasher = md5()
    
    while True:
        # TODO: fix this
        buf = stream.read(65536)
        if len(buf) > 0:
            hasher.update(buf)
        else:
            break

    return hasher.hexdigest()


def gzipCompress(filename):
    f_in = open(filename, 'rb')
    f_tmp = tempfile.NamedTemporaryFile("wb", delete=False, prefix="dxagentGzip", dir=TEMP_DIR)
    temp_filename = f_tmp.name
    fGzip = gzip.GzipFile(fileobj=f_tmp)
    copyfileobj(f_in, fGzip)
    f_in.close()
    fGzip.close()
    f_tmp.close()
    return temp_filename


# No decompression needs to be done
def save_to_tempfile(inobj):
    f_tmp = tempfile.NamedTemporaryFile("wb", delete=False, prefix="dxagentTemp", dir=TEMP_DIR)
    temp_filename = f_tmp.name
    copyfileobj(inobj, f_tmp)
    f_tmp.close()
    return temp_filename


def gzip_de_compress(inobj):
    f_tmp = tempfile.NamedTemporaryFile("wb", delete=False, prefix="dxagentGunzip", dir=TEMP_DIR)
    temp_filename = f_tmp.name
    # Have to open it with the specified mode, otherwise it will have errors when
    # reading a large file
    fGzip = gzip.GzipFile(fileobj=inobj, mode='rb')
    copyfileobj(fGzip, f_tmp)
    fGzip.close()
    f_tmp.close()
    return temp_filename


def bz2_compress(filename):
    f_in = open(filename, 'rb')
    f_tmp = tempfile.NamedTemporaryFile("wb", delete=False, prefix="dxagentBz2", dir=TEMP_DIR)
    temp_filename = f_tmp.name
    bz2Compressor = bz2.BZ2Compressor()

    while True:
        buf = f_in.read(65536)
        if len(buf) > 0:
            compressed = bz2Compressor.compress(buf)
            f_tmp.write(compressed)
        else:
            break

    compressed = bz2Compressor.flush()
    f_tmp.write(compressed)
    f_in.close()
    f_tmp.close()
    return temp_filename

def bz2_de_compress(inobj):
    temp_file = tempfile.NamedTemporaryFile("wb", delete=False, prefix="dxagentBz2Decompressed", dir=TEMP_DIR)
    bz2_decompressor = bz2.BZ2Decompressor()

    while True:
        buf = inobj.read(65536)
        if len(buf) > 0:
            decompressed = bz2_decompressor.decompress(buf)
            temp_file.write(decompressed)
        else:
            break

    temp_file.close()
    return temp_file.name


# Return a file object for filename. The file will be automatically deleted
# when the file object is closed/garbage collected. A weak reference is used to
# receive notification via callback when this happens. The callback then deletes
# the file from disk. The weak reference object must be held in a global
# variable otherwise it will die first before the referent and callback won't be
# invoked. Do not use any other object as the referent or the deletion will not
# occur at the right time. See https://docs.python.org/2/library/weakref.html
def auto_delete_file(filename, mode='rb'):
    f = open(filename, mode)
    wr = weakref.ref(f, auto_delete_file_callback)
    weakReferenceToFilenameMap[wr] = filename
    return f


def auto_delete_file_callback(wr):
    filename = weakReferenceToFilenameMap.pop(wr, None)
    logger.debug("Auto deleting file " + filename)
    if filename is not None:
        os.unlink(filename)
        
# Can't have a weakref to a string need an object
class DirWrapper():

    def __init__(self, name):
        self.name = name
    
def auto_delete_dir(dirname):
    d = DirWrapper(dirname)
    wr = weakref.ref(d, auto_delete_dir_callback)
    weakReferenceToFilenameMap[wr] = dirname
    return d


def auto_delete_dir_callback(wr):
    dirname = weakReferenceToFilenameMap.pop(wr, None)
    logger.debug("Auto deleting dir " + dirname)
    if dirname is not None:
        rmtree(dirname)

def run_dxconfig_cmd(command, wait=False, inputForCmd=''):
    
    # Replace DXHOME env variable with our sanitized value.
    # This is needed to convert paths in dxconfig relative to DXHOME
    env_variables = os.environ.copy()
    env_variables['DXHOME'] = DXHOME
    # DXagent bundles version of CAPKI DXconfig was built with.
    # This may be newer than the version available if DXagent is managing
    # an older version of Directory
    env_variables['CAPKIHOME'] = DXAGENTHOME
    
    ret = run_dxserver_cmd(command, wait, inputForCmd, env_variables)
        
    # Split and return last line to filter out any parser messages printed to
    # stdout. E.g
    #  ** ALARM **
    # Error:
    lines = ret.split(os.linesep)
    ret = lines[-1]
    return ret
    
    
def run_dxserver_cmd(command, wait=False, inputForCmd='', env_variables=os.environ):

    logger.debug('running command: ' + ' '.join(command))

    # TODO: Sanitise command
    if wait:
        logger.debug('Not waiting for response')
        subprocess.Popen(command)
        return None

    p = subprocess.Popen(command,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT,
                         stdin=subprocess.PIPE,
                         env=env_variables,
                         cwd=DXHOME)
    if inputForCmd != '':
        pstdout = p.communicate(input=inputForCmd)[0]  # just return the stdout
    else:
        pstdout = p.communicate()[0]  # just return the stdout

    pstdout = pstdout.rstrip().decode('utf-8')

    logger.debug("Stdout is " + pstdout)
    logger.debug("return code " + str(p.returncode))
    
    if p.returncode:
        if 'Syntax check failed' in pstdout:
            raise DxagentSyntaxError(pstdout)
        
        if 'The command dxserver start failed' in pstdout:
            raise DxagentException(22, _('Invalid configuration, please check the dxserver logs'))
        
        dsa_not_found = re.search("DSA '(.*)' not found", pstdout, re.DOTALL)
        if dsa_not_found:
            raise DxagentDSANotExistError(dsa_not_found.group(1))

        dsa_does_not_exist = re.search("DSA (.*) does not exist", pstdout, re.DOTALL)
        if dsa_does_not_exist:
            raise DxagentDSANotExistError(dsa_does_not_exist.group(1))
        
        db_cannot_be_accessed = re.search(".*Datastore '(.*)' cannot be accessed.*", pstdout, re.DOTALL)
        if db_cannot_be_accessed:
            raise DxagentException(2, _('Unable to retrieve DSA db file: ') + db_cannot_be_accessed.group(1))
        
        mw_disp_dsa_not_found = re.search("No Multiwrite-DISP DSA '(.*)' was found", pstdout, re.DOTALL)
        if mw_disp_dsa_not_found:
            raise DxagentException(2, _('DSA {0} is not a Multiwrite-DISP DSA').format(mw_disp_dsa_not_found.group(1)))
        
        raise Exception(pstdout)
    
    return pstdout


def header_contains(name, value):
    all_values = request.headers.get(name)
    if all_values is None:
        return None

    for token in all_values.strip().split(','):
        if token == value or token == '*/*':
            return True

    return False 


def check_header_types(header, error_msg, allowed_types=None):
    
    if allowed_types is None:
        return

    # Assume application/json if not set
    if header_contains(header, ''):
        return

    for type in allowed_types:
        if not type:
            return
        contains = header_contains(header, type)
        if contains or contains == None:
             return

    raise DxagentException(22, error_msg)
    
def check_accept_types(allowed_accept_types):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                check_header_types('Accept', "Unsupported response Accept-Type, expected one of " + str(allowed_accept_types), allowed_accept_types)
            except Exception as e:
                return get_exception_response(e)
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

def check_content_type(allowed_content_types):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                check_header_types('Content-Type', "Unsupported request Content-Type, expected one of " + str(allowed_content_types), allowed_content_types)
            except Exception as e:
                return get_exception_response(e)
            
            return func(*args, **kwargs)
        return wrapper
    return decorator
    
# Define a separate function so it can be used as a decorator and a function
def check_dxserver_version_func(min_version):
    
    if StrictVersion(min_version) > StrictVersion(DXSERVER_VERSION):
        raise DxagentException(22, _("Requires Dxserver version of at least {0} found version {1}").format(min_version, DXSERVER_VERSION))
    
def check_dxserver_version(min_version):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                check_dxserver_version_func(min_version)
            except Exception as e:
                return get_exception_response(e)
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

def check_api_version():
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            url_version = kwargs.get('version', None)
            # Only support one version at the moment
            # Will need additonal logic later
            if url_version and url_version == 'v1.0':
                # Set global api version
                global API_VERSION
                API_VERSION=url_version
                return func(*args, **kwargs)
            else:
                e = DxagentException(22, _("Unsupported API version specified"))
                return get_exception_response(e)
            
            return func(*args, **kwargs)
        return wrapper
    return decorator


# Returns an entity response. If obj is a subclass of BaseEntity
# then its to_response method will be called. Else, if the response
# is not to be in JSON then serialize the object into a string.
def get_entity_response(obj):
    if obj is not None and isinstance(obj, BaseEntity):
        return obj.to_response()
    elif isinstance(obj, dict):
        return obj


# Returns a success response with default code 200
# obj is expected to be a subclass of BaseEntity
def get_success_response(code=0, httpCode=200, obj=None):
    response.status = httpCode
    if obj is None:
        return

    return get_entity_response(obj)


def get_success_collection_response(code=0, httpCode=200, coll=None):
    response.status = httpCode
    if coll is None:
        return

    l = list()
    for e in coll:
        l.append(get_entity_response(e))

    return l


def get_exception_response(e):
    entity = DsaExceptionEntity(e) 
    response.status = entity.get_http_error_code()
    logger.exception(str(entity))
    return get_entity_response(entity)


# By default both request and response are in JSON. The REST handler may optionally
# allow a different response content type.
def init_response():
    response.status = 200
    # Default response content_type to JSON
    response.content_type = 'application/json'

    # Need to initialize the language based on the passed header value for the language
    language = request.headers.get("Accept-Language")
    if language:
        logger.debug("Language '" + language + "' is specified from the request")
    else:
        logger.debug("No Language is specified from the request")
        language = 'en'

    init_localization(language)
        
    # TODO: Is this really the way to do it?
    # response.headers["Access-Control-Allow-Origin"] = "*"  # enable CORS

def get_dsa_config_schema():
    # Parse and construct a JSON Schema that is palatable to jsonschema
    swagger_json = get_swagger_json()    
    
    for name in SCHEMA_CATEGORY_TITLES:
        title_properties_list = swagger_json["definitions"][name]['properties']
        for key, value in title_properties_list.items():
            for item in TRANSLATED_METADATA:
                value_item = value.get(item, None)
                if value_item:
                    # the strID is the key of the property appended by '.title' or '.description'
                    str_id = '.'.join([name, key, item])
                    # if there is translation string found, _(strId) should be different from the strId
                    if _(str_id) != str_id:
                        value[item] = _(str_id)

        swagger_json["definitions"][name]["properties"]["metadata"] = swagger_json["definitions"][name + "Metadata"]
    
    dsaConfig = swagger_json["definitions"]["dsaConfig"]
    dsaConfig["properties"]["logging"] = swagger_json["definitions"]["dsaLogging"]
    dsaConfig["properties"]["knowledge"]["items"] = swagger_json["definitions"]["dsaKnowledge"]
    dsaConfig["properties"]["settings"] = swagger_json["definitions"]["dsaSettings"]
    dsaPasswordPolicies = swagger_json["definitions"]["dsaPasswordPolicies"]
    dsaPasswordPolicies["properties"]["policies"]["items"] = swagger_json["definitions"]["dsaMultiPasswordPolicies"]
    dsaConfig["properties"]["passwordPolicies"] = dsaPasswordPolicies
    dsaConfig["properties"]["limits"] = swagger_json["definitions"]["dsaLimits"]
    dsaConfig["properties"]["ssl"] = swagger_json["definitions"]["dsaSSL"]
    dsaConfig["properties"]["server"] = swagger_json["definitions"]["dsaServer"]
    dsa = swagger_json["definitions"]["DSA"]
    dsa["properties"]["config"] = dsaConfig
    definitions = dict()
    definitions["dsaMetadata"] = swagger_json["definitions"]["dsaMetadata"]
    dsa["definitions"] = definitions
    
    return dsa

def get_supported_actions():
    
    swagger_json = get_swagger_json()
    
    actions = list()
    for endpointURL, endpoint in swagger_json['paths'].items():
        for http_method, operation in endpoint.items():
            action = operation.get('action', None)
            if action:
                item = dict()
                item['action'] = action
                item['title'] = operation['title']
                item['summary'] = operation['summary']
                item['description'] = operation['description']
                item['httpMethod'] = http_method.upper()
                item['endpoint'] = endpointURL    
                # Optional values            
                for target, source in [('acceptTypes', 'produces'), ('contentTypes', 'consumes'), ('parameters', 'parameters')]:
                    value = operation.get(source, None)
                    if value:
                        item[target] = value
                actions.append(item)
                
    return actions

# only return ture when other language than English is being used 
def init_localization(language):
    # if the language is not specified, use the default locale
    if not language:
         locale.setlocale(locale.LC_ALL, '') # use user's preferred locale
         # take first two characters of country code
         loc = locale.getlocale()
         language = locale.getlocale()[0][0:5]

    # if the language is from the machine env, the language is having the underscore like 'en_AU', so replace the '_' to '-'
    language = language.replace('_', '-')

    try:
        lan = gettext.translation('dxagent', localedir=LOCALE_DIR, languages=[language])
        logger.debug("Using '" + language + "' language file for tranlating strings.")
    except Exception:
        useDefault = True
        #if the language is having the full locale value (e.g. en-AU, zh-CN) and if not found, just try to find the first two letters language
        if len(language) > 2:
            try:
                logger.debug("The specified language file for '" + language + "' is not found, trying to find language for '" + language[0:2] + "'")
                lan = gettext.translation('dxagent', localedir=LOCALE_DIR, languages=[language[0:2]])
                logger.debug("Using '" + language[0:2] + "' language file for tranlating strings.")
                useDefault = False
            except Exception:
                pass

        if useDefault:
            # use the English as the default language if the specified language cannot be found
            logger.debug("The specified language file for '" + language + "' is not found, use the English as the default language")
            lan = gettext.translation('dxagent', localedir=LOCALE_DIR, languages=['en'])

    if PYTHON_VERSION < 3:
        lan.install(unicode=True)
    else:
        lan.install()

def process_swagger(input_file, output_file, target_version):
    
    # Nested functions
    def process_config_properties(swagger_json, target_version):
    
        # Start processing from the dsaConfig level and drill down
        # At the root level of dsaConfig will be categories that reference other object definitions
        # Special case where it is an array of references to object definitions
        
        for key, value in swagger_json['definitions']['dsaConfig']['properties'].items():
            type = value.get('type', None)
            items = value.get('items', None)
            if '$ref' in value:
                category = get_referenced_definition(swagger_json, value)
            elif type == 'array' and items:
                if '$ref' in items:
                    category = get_referenced_definition(swagger_json, items)
                else:
                    continue
            else:
                category = value
                
            process_object(swagger_json, category['properties'], target_version)
                    
    def process_object(swagger_json, object, target_version):
        
        # Python 3 won't let you delete from a dict while iterating over it
        delete_keys = list()
        for key, value in object.items():
            
            if not isinstance(value, dict):
                continue
            
            min_version = value.get('minVersion', None)
            min_version_values = value.get('minVersionValues', None)
            type = value.get('type', None)
            items = value.get('items', None)
            
            # Check for minVersion property if it's supported remove the minVersion property.
            # By removing it we can easily test if call occurences are being handled by grepping the output file.
            if min_version:
                if version_supported(target_version, min_version):
                    del value['minVersion']
                else:
                    delete_keys.append(key)
                    continue
            # The property we're looking at may be an array with references to other objects or an array of enum values
            elif type  == 'array' and items:
                if '$ref' in items:
                    category = get_referenced_definition(swagger_json, items)
                    process_object(swagger_json, category['properties'], target_version)
                elif 'enum' in items and min_version_values:
                    enum = items.get('enum', None)
                    for enum_value, version in min_version_values.items():
                        if not version_supported(target_version, version):
                            enum.remove(enum_value)
                            
                    del value['minVersionValues']                          
                else:
                    continue
                
            process_object(swagger_json, object[key], target_version)
            
        for key in delete_keys:
            del object[key]
                
        # Create metadata object definitions for each category.
        # There is a placeholder metadata property with a reference to an object that does not exist, we will create it.
        # Iterate the properties of the object and add them to the metadata object as a reference to dsaMetadata.
        metadata = object.get('metadata', None)
        if metadata and '$ref' in metadata:
            definitionName = get_referenced_definition_name(swagger_json, metadata)
            category_metadata = dict()
            category_properties = dict()
            for key in object.keys():
                if key == 'metadata':
                    continue
                property_metadata = dict()
                property_metadata['$ref'] = "#/definitions/dsaMetadata"
                category_properties[key] = property_metadata
                
            category_metadata['properties'] = category_properties
            swagger_json['definitions'][definitionName] = category_metadata
    
    def get_referenced_definition(swagger_json, ref):
        return swagger_json['definitions'][get_referenced_definition_name(swagger_json, ref)]
    
    def get_referenced_definition_name(swagger_json, ref):
        ref_value = ref['$ref']
        return ref_value.split('/')[-1]          
                    
    def version_supported(target_version, version_value):
        if target_version == 'latest':
            return True
        
        return StrictVersion(version_value) <= StrictVersion(target_version)
    
    # Start main function code
    with open(input_file, encoding='utf8') as swagger_file:
        swagger_json = json.load(swagger_file)

    process_config_properties(swagger_json, target_version)
    process_object(swagger_json, swagger_json['paths'], target_version)
    
    with open(output_file, 'wb' if PYTHON_VERSION < 3 else 'w') as outfile:
        json.dump(swagger_json, outfile)
        
def get_swagger_json():
    swagger_file_name =  os.path.join(DXAGENTHOME, 'doc', 'json', API_VERSION, 'dxagent_swagger.json')

    with open(swagger_file_name) as swagger_file:
        swagger_json = json.load(swagger_file)
        
    return swagger_json

def process_version_specific_kludges(dsa_config):
    # These are items that have been fixed in 12.5 and newer parser but have to be worked around in older versions 
    if StrictVersion(DXSERVER_VERSION) < StrictVersion('12.5'):
        settings = dsa_config.get('settings', None)
        if settings:
            # use-roles checks if role-subtree is set even when not enabled
            use_roles = settings.get('use-roles', None)
            # Use explicit comparision to make sure not None
            if use_roles == False:
                del settings['use-roles']
                
        limits = dsa_config.get('limits', None)
        if limits:
            # max-cache-index-size can't be set to 0 in older versions
            max_cache_index_size = limits.get('max-cache-index-size', None)
            # If it's 0 remove it
            if max_cache_index_size != None and max_cache_index_size == 0:
                del limits['max-cache-index-size']
        
        password_policies = dsa_config.get('passwordPolicies', None)
        if password_policies:
            policies = password_policies.get('policies', None)
            if policies:
                for policy in policies:
                    # password-max-length checks it is greater than password-min-length even if it is set to 0 (disabled)
                    password_max_length = policy.get('password-max-length', None)
                    if password_max_length != None and password_max_length < 1:
                        del policy['password-max-length']
    

# ================================================================
#
#  Dxserver Version Specific Initialization
#
# ================================================================

def dxagent_init():
    # Needs to go after the class and function defs
    global DXSERVER_VERSION
    DXSERVER_VERSION = DxserverInfo().get_normalized_version()
    # Dxagent requires minimum of Dxserver 12.0
    check_dxserver_version_func(MIN_DXSERVER_VERSION)
    # Generate swagger doc
    for version_dir in glob(os.path.join(DXAGENTHOME, 'doc', 'json', 'v*')):
        try:
            src_swagger_file = os.path.join(version_dir, 'src_dxagent_swagger.json')
            output_swagger_file = os.path.join(version_dir, 'dxagent_swagger.json')
            process_swagger(src_swagger_file, output_swagger_file, DXSERVER_VERSION)
        except Exception as e:
            logger.error("Processing of " + src_swagger_file + " failed. Some API functionality may be unavailable.")

# ================================================================
#
#  REST resource handlers
#
# ================================================================


# Generic Entity functions to reduce copy and paste boiler plate
def get_all_entities(entityProvider, *args):
    try:
        init_response()
        entities = entityProvider.get_entities(request.GET.get('filter', ''), *args)
        l = get_success_collection_response(0, 200, entities)
        return json.dumps(l)  # not sure why we cannot simply return a list like we can with dict

    except Exception as e:
        return get_exception_response(e)


def get_entity(entity_class, entityname):
    try:
        init_response()
        entity = entity_class(entityname)
        return get_success_response(0, 200, entity)

    except Exception as e:
        return get_exception_response(e)


def create_entity(entity_class, entityname=None, entityResponse=True):
    try:
        init_response()
        if not entityname:
            entityname = request.json.get('name', None)
        entity = entity_class(entityname)
        entity.create_from_request()
        return get_success_response(0, 201 if entityResponse else 204, entity if entityResponse else None)

    except Exception as e:
        return get_exception_response(e)


def update_entity(entity_class, entityname, entityResponse=True):
    try:
        init_response()
        entity = entity_class(entityname)
        entity.update_from_request()
        return get_success_response(0, 200, entity if entityResponse else None)

    except Exception as e:
        return get_exception_response(e)


def delete_entity(entity_class, entityname):
    try:
        init_response()
        entity = entity_class(entityname)
        entity.delete()
        return get_success_response(0, 204, None)

    except Exception as e:
        return get_exception_response(e)
    
#
# Endpoint definitions
#


# GET all DSAs
@app.get(DXAGENT_BASE_URI + '/<version>/dsas')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_all_dsas(version):
    return get_all_entities(DsaEntityProvider)


# GET a DSA
@app.get(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_dsa(version, dsaname=''):
    return get_entity(DsaEntity, dsaname)


# POST to create new DSA
@app.post(DXAGENT_BASE_URI + '/<version>/dsas')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def create_dsa(version):
    return create_entity(DsaEntity)


# PUT to update existing DSA
@app.put(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def update_dsa(version, dsaname=''):
    return update_entity(DsaEntity, dsaname)


# DELETE a DSA
@app.delete(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_dsa(version, dsaname=''):
    return delete_entity(DsaEntity, dsaname)

# PUT to update DSA's status
@app.put(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/status')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def update_dsa_status(version, dsaname=''):
    return update_entity(DsaStatusEntity, dsaname)

# GET a DSA DB
@app.get(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/db')
@check_api_version()
@check_accept_types(["application/octet-stream", "application/x-bzip2", "application/x-gzip"])
@check_content_type(None)
def get_dsa_db(version, dsaname=''):
    return get_entity(DsaDBEntity, dsaname)

# POST a DSA DB
@app.post(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/db')
@check_api_version()
@check_accept_types(None)
@check_content_type(["application/octet-stream", "application/x-bzip2", "application/x-gzip"])
def create_dsa_db(version, dsaname=''):
    return create_entity(DsaDBEntity, dsaname, False)

# DELETE a DSA DB
@app.delete(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/db')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_dsa_db(version, dsaname=''):
    return delete_entity(DsaDBEntity, dsaname)

# PUT (empty) a DSA DB
@app.put(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/db')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def dsa_empty_db(version, dsaname=''):
    return update_entity(DsaDBEntity, dsaname, False)

# GET a DSA LDIF
@app.get(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/ldif')
@check_api_version()
@check_accept_types(["application/octet-stream", "application/x-bzip2", "application/x-gzip"])
@check_content_type(None)
def get_dsa_ldif(version, dsaname=''):
    return get_entity(DsaLDIFEntity, dsaname)

# POST a DSA DB
@app.post(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/ldif')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/octet-stream", "application/x-bzip2", "application/x-gzip"])
def create_dsa_ldif(version, dsaname=''):
    return create_entity(DsaLDIFEntity, dsaname, True)

# POST to trigger an online backup
@app.post(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/onlinebackups')
@check_dxserver_version('12.0.15')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def create_online_backup(version, dsaname=''):
    return create_entity(DsaOnlineBackupEntity, dsaname, False)


# GET an online backup
@app.get(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/onlinebackups')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_online_backup(version, dsaname=''):
    return get_entity(DsaOnlineBackupEntity, dsaname)


# PUT an online backup
@app.put(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/onlinebackups')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def restore_from_online_backup(version, dsaname=''):
    return update_entity(DsaOnlineBackupEntity, dsaname, False)

# DELETE a DSA DB
@app.delete(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/onlinebackups')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_dsa_backup(version, dsaname=''):
    request.query.online = "true"
    return delete_entity(DsaDBEntity, dsaname)

# GET a DSA online backup DB
@app.get(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/onlinebackups/db')
@check_api_version()
@check_accept_types(["application/octet-stream", "application/x-bzip2", "application/x-gzip"])
@check_content_type(None)
def get_dsa_backup_db(version, dsaname=''):
    request.query.online = "true"
    return get_entity(DsaDBEntity, dsaname)

# GET a DSA online backup LDIF
@app.get(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/onlinebackups/ldif')
@check_api_version()
@check_accept_types(["application/octet-stream", "application/x-bzip2", "application/x-gzip"])
@check_content_type(None)
def get_dsa_backup_ldif(version, dsaname=''):
    request.query.online = "true"
    return get_entity(DsaLDIFEntity, dsaname)

# POST to trigger log rollover
@app.post(DXAGENT_BASE_URI + '/<version>/dsas/<dsaname>/logroll')
@check_dxserver_version('12.0.18')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def logroll(version, dsaname=''):
    return create_entity(DsaLogRollEntity, dsaname, False)


# GET CA Directory installation information
@app.get(DXAGENT_BASE_URI + '/<version>/about')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_dxserver_info(version):
    return get_entity(DxserverInfo, None)


# POST to run the cmd 'dxdisp'
# /v1.0/dsas/<dsaname/dxdisp is not appropriate this is applied to all DSAs on
# the host. The dsa passed in the pay load is the peer dsa
@app.post(DXAGENT_BASE_URI + '/<version>/dsas/dxdisp')
@check_api_version()
@check_accept_types(None)
@check_content_type(["application/json"])
def run_dxdisp(version):
    return create_entity(DxdispEntity, 'Disp', False)


# API Spec - Filepath for Swagger JSON, CSS, HTML files
@app.get(DXAGENT_BASE_URI + '/<version>/doc/<filepath:path>')
@check_api_version()
def swagger(version, filepath):
    # TODO: does reponse shadow parent?
    if(filepath == 'dxagent-api.html'):
        return template(os.path.join(DXAGENTHOME, 'doc', 'dxagent-api.html'), dict(api_version=API_VERSION, base_uri=DXAGENT_BASE_URI))
    else:
        response = static_file(filepath, root=os.path.join(DXAGENTHOME, 'doc'))
        response.set_header("Last-Modified", '')
    return response


@app.error(404)
def error404(code):
    response.content_type = "application/json"
    # response.headers["Access-Control-Allow-Origin"] = "*"  # enable CORS
    return json.dumps(DsaExceptionEntity(DxagentException(2, _("Entity type not found"))).to_dict())


@app.error(405)
def error405(code):
    response.content_type = "application/json"
    # response.headers["Access-Control-Allow-Origin"] = "*"  # enable CORS
    return json.dumps(DsaExceptionEntity(DxagentException(22, _("Method not defined"))).to_dict())
    
    
# GET all Schema files
@app.get(DXAGENT_BASE_URI + '/<version>/schemas')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_all_schemas(version):
    return get_all_entities(SchemaEntityProvider)


# GET a Schema file
@app.get(DXAGENT_BASE_URI + '/<version>/schemas/<schemaname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_schema(version, schemaname=''):
    return get_entity(SchemaEntity, schemaname)


# POST to create new Schema file
@app.post(DXAGENT_BASE_URI + '/<version>/schemas')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def create_schema(version):
    return create_entity(SchemaEntity)


# PUT to update existing Schema file
@app.put(DXAGENT_BASE_URI + '/<version>/schemas/<schemaname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def update_schema(version, schemaname=''):
    return update_entity(SchemaEntity, schemaname)


# DELETE a Schema file
@app.delete(DXAGENT_BASE_URI + '/<version>/schemas/<schemaname>')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_schema(version, schemaname=''):
    return delete_entity(SchemaEntity, schemaname)

# GET all _access_control files
@app.get(DXAGENT_BASE_URI + '/<version>/accesscontrols')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_all_access_controls(version):
    return get_all_entities(AccessControlEntityProvider)


# GET a _access_control file
@app.get(DXAGENT_BASE_URI + '/<version>/accesscontrols/<accesscontrolname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_access_control(version, accesscontrolname=''):
    return get_entity(AccessControlEntity, accesscontrolname)


# POST to create new _access_control file
@app.post(DXAGENT_BASE_URI + '/<version>/accesscontrols')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def create_access_control(version):
    return create_entity(AccessControlEntity)


# PUT to update existing _access_control file
@app.put(DXAGENT_BASE_URI + '/<version>/accesscontrols/<accesscontrolname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def update_access_control(version, accesscontrolname=''):
    return update_entity(AccessControlEntity, accesscontrolname)


# DELETE a _access_control file
@app.delete(DXAGENT_BASE_URI + '/<version>/accesscontrols/<accesscontrolname>')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_access_control(version, accesscontrolname=''):
    return delete_entity(AccessControlEntity, accesscontrolname)


# GET all Personality files
@app.get(DXAGENT_BASE_URI + '/<version>/certificates/personalities')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_all_personalities(version):
    return get_all_entities(PersonalityEntityProvider)


# GET a Personality file
@app.get(DXAGENT_BASE_URI + '/<version>/certificates/personalities/<personalityname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_personality(version, personalityname=''):
    return get_entity(PersonalityEntity, personalityname)


# POST to create new Personality file
@app.post(DXAGENT_BASE_URI + '/<version>/certificates/personalities')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def create_personality(version):
    return create_entity(PersonalityEntity)


# PUT to update existing Personality file
@app.put(DXAGENT_BASE_URI + '/<version>/certificates/personalities/<personalityname>')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(["application/json"])
def updatePersonality(version, personalityname=''):
    return update_entity(PersonalityEntity, personalityname)


# DELETE a Personality file
@app.delete(DXAGENT_BASE_URI + '/<version>/certificates/personalities/<personalityname>')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_personality(version, personalityname=''):
    return delete_entity(PersonalityEntity, personalityname)


# GET all Trusted CAs
@app.get(DXAGENT_BASE_URI + '/<version>/certificates/trustedcas')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_all_trusted_cas(version):
    return get_all_entities(TrustedCAEntityProvider)


# POST to create new Trusted CA
@app.post(DXAGENT_BASE_URI + '/<version>/certificates/trustedcas')
@check_api_version()
@check_accept_types(None)
@check_content_type(["application/json"])
def create_trusted_ca(version):
    try:
        init_response()
        properties = dict()
        properties["certificate"] = -1
        trustedca = TrustedCAEntity(properties)
        trustedca.create_from_request()
        return get_success_response(0, 201, None)

    except Exception as e:
        return get_exception_response(e)


# DELETE a Trusted CA
@app.delete(DXAGENT_BASE_URI + '/<version>/certificates/trustedcas/<trusted_ca_name>')
@check_api_version()
@check_accept_types(None)
@check_content_type(None)
def delete_trusted_ca(version, trusted_ca_name=''):
    try:
        init_response()
        properties = dict()
        properties["certificate"] = trusted_ca_name
        entity = TrustedCAEntity(properties)
        entity.delete()
        return get_success_response(0, 204, None)

    except Exception as e:
        return get_exception_response(e)
    
@app.get(DXAGENT_BASE_URI + '/<version>/dxinfo')
@check_dxserver_version('12.0.2')
@check_api_version()
@check_accept_types(["application/x-bzip2", "application/x-gzip"])
@check_content_type(None)
def get_dxinfo(version):
    return get_entity(DxInfoEntity, None)
    
@app.get(DXAGENT_BASE_URI + '/<version>/logs/<dsaname>/<logtype>/delta')
@check_api_version()
@check_accept_types(["application/json"])
@check_content_type(None)
def get_log_delta(version, dsaname, logtype):
    if logtype not in ['alarm', 'stats']:
        e = DsaExceptionEntity("Log Type: " + logtype + " not supported.")
        return get_exception_response(e)
    
    return get_all_entities(LogDeltaEntityProvider, dsaname, logtype)
    
                
if __name__ == "__main__":
    logger = logging.getLogger('dxagent')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)
    dxagent_init()
    app.run(host='0.0.0.0', port=8080, debug=True, reloader=True)
    
