The setup script creates a sample SCIM DSA to demonstrate the SCIM v2 server capabilities.

USAGE

setup.sh (Solaris)
setup.bat (Windows NT)

Arguments: [dsaname] [port]

Running the script without any argument to create a sample DSA named "scimdemo" using port "20389".
An alternative DSA name and port number can be specified as arguments.

"dxcertgen certs" command is invoked by the script to generate SSL certificate for the DSA.
