#
# Copyright (C) 2016 CA Technologies. All Rights Reserved.
#
# dxagent_default_config.py
#
# Contains default config options for DXagent
# This file is over written on upgrade
# Customized values should be set in dxagent_config.py

import socket
import ssl

#
# Server configuration
#

#
# DXAGENT_HOST - 0.0.0.0 will bind to all interfaces, Hostname will bind to localhost
#
DXAGENT_HOST = '0.0.0.0'

#
# DXAGENT_PORT - server port
#
DXAGENT_PORT = 9443

#
# DXAGENT_BASE_URI - All API URI's defined relative to this
#
DXAGENT_BASE_URI = '/ca/api/dxagent/'

#
# DXAGENT_TEMP_DIR_PATH - Path relative to DXagent parent dir for creating temporary files
# e.g. 'temp' is equivalent of $DXHOME/dxagent/temp
#
DXAGENT_TEMP_DIR_PATH = 'temp'

#
# SSL configuration
#

# SSLContext requires at least 2.7.9 or 3.4
if hasattr(ssl, 'SSLContext'):
    #
    # DXAGENT_SSL_PROTOCOL - Protocol used by the SSL Context
    # Valid values:
    # ssl.PROTOCOL_SSLv23
    # ssl.PROTOCOL_TLSv1
    # ssl.PROTOCOL_TLSv1_1
    # ssl.PROTOCOL_TLSv1_2
    #
    DXAGENT_SSL_PROTOCOL = ssl.PROTOCOL_TLSv1_2
    
    #
    # DXAGENT_SSL_VERIFY_MODE - Used to enable two-way SSL
    #
    DXAGENT_SSL_VERIFY_MODE = ssl.CERT_REQUIRED
else:
    try:
        from OpenSSL import SSL
        #
        # DXAGENT_SSL_PROTOCOL - Protocol used by the SSL Context
        # Valid values:
        # SSL.SSLv23_METHOD
        # SSL.TLSv1_METHOD
        #
        DXAGENT_SSL_PROTOCOL = SSL.TLSv1_METHOD
    
        #
        # DXAGENT_SSL_VERIFY_MODE - Used to enable two-way SSL
        #
        DXAGENT_SSL_VERIFY_MODE = SSL.VERIFY_PEER | SSL.VERIFY_FAIL_IF_NO_PEER_CERT
    except Exception:
        pass 
#
# DXAGENT_CA_FILE_PATH - Path to Certificate Authority 
#
DXAGENT_CA_FILE_PATH = 'openssl-ca/CA/certs/ca.pem'

#
# DXAGENT_SERVER_CERT_PATH - Path to Server Certificate 
#
DXAGENT_SERVER_CERT_PATH = 'openssl-ca/out/' + socket.gethostname() + '.pem'

#
# DXAGENT_SERVER_KEY_PATH - Path to Server Key 
#
DXAGENT_SERVER_KEY_PATH = 'openssl-ca/out/' + socket.gethostname() + '.key'

#
# Logging configuration
#

DXAGENT_LOGGING_CONF_FILE = 'dxagent_logging.conf'
