const logger = require('../utils/logger');
const user = require('../models/user');
const config = require('../utils/config-index');
const utils = require('../utils/utils');
const ldap = require('../models/ldap-operations');
const ldapjs = require('ldapjs');
const async = require('async');
const ldap2date = require('ldap2date');

/**
 * login the user
 *
 * By default, if authentication fails, Passport will respond with a 401 Unauthorized status, and any additional 
 * route handlers will not be invoked. If authentication succeeds, the next handler will be invoked and the 
 * req.user property will be set to the authenticated user.
 */
module.exports.login = function (req, res) {
  // If this function gets called, authentication was successful.'req.user' contains the authenticated user.
  try {
    logger.debug('Logged in user is  - ' + JSON.stringify(req.user));
    logger.debug('Logged in user session is ... "' + JSON.stringify(req.session) + '"');
  } catch (err) {}

  res.cookie(config.loggedInUserName, req.user.username, config.cookieConfig);
  res.cookie('XSRF-TOKEN', req.csrfToken(), config.cookieConfig);
  res.status(200).json({message: utils.i18nTranslate(req.getLocale(), 'controllers.login.loginSuccess')});
};

/**
 * logout the user
 *
 * Passport exposes a logout() function on req (also aliased as logOut()) that can be called from any route 
 * handler which needs to terminate a login session. Invoking logout() will remove the req.user property 
 * and clear the login session (if any).
 */
module.exports.logout = function (req, res) {
  logger.info('Logout user ...');

  try {
    logger.debug('Logout user ... "' + JSON.stringify(req.user) + '"');
  } catch (err) {}

  user.removeSession(req.user[user.SESSION_ID]);
  req.logout();
  res.status(200).json({message: utils.i18nTranslate(req.getLocale(), 'controllers.login.loginSuccess')});
};


/* This function is used to change/update the user password */
module.exports.updatePassword = function (req, res) {
  
  var change = new ldapjs.Change({
    operation: 'replace',
    modification: {
      userPassword: req.body.newPassword
    }
  });
  var dn = "cn=" + req.body.username + "," + utils.managementUiLdapConfig.ldapUsersBaseDN;
  var oldPassword = req.body.oldPassword;
  
  ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
      return;
    } else {

      ldapClient.ldapConnection.bind(dn, oldPassword, function(err) {
        if(err) {
          ldap.returnLdapClient(ldapClient); 
          res.status(401).json(err);
          return; 
        } else {
            ldapClient.ldapConnection.modify(dn, change, function(err, result) {
              if (err) {
                if(err.lde_message.indexOf("Password match") !== -1 ) {
                  logger.error("Error when trying to change the password, error is: " + err);
                  res.status(406).json(err);
                } else {
                  logger.error("Error when trying to change the password, error is: " + err);
                  res.status(500).json(err); 
                }               
              } else {
                res.status(200).json(result); 
              }
              ldapClient.ldapConnection.unbind(function(err) {
                ldap.returnLdapClient(ldapClient);
                if(err) {
                  logger.info("Unbind failed with error : " + err);
                }
              }); 
       
            });  

        }
        
      });

    }
  });
   
};


module.exports.saveEmailConfig = function(req,res) {
  var baseDN = utils.managementUiLdapConfig.ldapManagementUIBaseDN; 
  var emailConfig = req.body.config;
  var user = req.body.username;
  var length;
  var searchOptions = {
    scope: "one",
    filter: '(ou=settings)'
  };
  ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
      return;
    }
  
  async.waterfall([
    function(callback) {
      ldapClient.ldapConnection.search(baseDN, searchOptions, function(err, res) {
        var entries = [];
        res.on('searchEntry', function(entry) {
          entries.push(entry.object);
        }); 
        res.on('error', function(err) {
          logger.error('Error: ' + err.message);
          ldap.returnLdapClient(ldapClient);
          return;
        });
        res.on('end', function(result) {
			    length = entries.length;
		      return process.nextTick(function () {callback(null, length);});
		    });
		  });
    },

    function(length, callback) {
	    if(length == 0) {
		    ldapClient.createManagementUiSettings('settings', emailConfig, user, function(err,result) {
          if (err) {
            logger.error('Error occurred while creating user settings, error is ' + err);
            res.status(500).json(err);
          } else {
            ldapClient.createManagementUiSettingsUser(emailConfig, user, function(err, result) {
              res.status(200).json(result);
            });
          }
          ldap.returnLdapClient(ldapClient);
        });
	    } else {
        async.waterfall([
          function(callback) {
            var dn = utils.managementUiLdapConfig.ldapSettingsBaseDN;
            var searchOptions = {
              scope: "one",
              filter: '(name=' + user +')'
            };
            ldapClient.ldapConnection.search(dn, searchOptions, function(err, res) {
              var entries = [];
              res.on('searchEntry', function(entry) {
                entries.push(entry.object);
              }); 
              res.on('error', function(err) {
                logger.error('Error: ' + err.message);
                ldap.returnLdapClient(ldapClient);
                return;
              });
              res.on('end', function(result) {
                length = entries.length;
                return process.nextTick(function () {callback(null, length);});
              });
            });
          },
          
          function(length, callback) {
            if (length == 0) {
              ldapClient.createManagementUiSettingsUser(emailConfig, user, function(err, result) {
                if (err) {
                  logger.error('Error occurred while creating user, error is ' + err);
                  res.status(500).json(err);
                } else {
                  res.status(200).json(result);
                }
              });
            } else {
              ldapClient.updateManagementUISettingsUser('settings', emailConfig, user, function(err, result) {
                if (err) {
                  logger.error('Error occurred while updating user settings, error is ' + err);
                  res.status(500).json(err);
                } else {
                  res.status(200).json(result);
                }
              });
            }
            ldap.returnLdapClient(ldapClient); 
          }
        ]);
        
      }
    }   
  ]); 
});
};
  
module.exports.sendOtp = function (req,res) {
  var user = req.body.user;
  var email = req.body.mail;
  var dn = "name=" + user + "," + utils.managementUiLdapConfig.ldapSettingsBaseDN;
   ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
    } else {
        ldapClient.ldapConnection.compare(dn, 'otherSettings', '{"emailConfigEnabled":true}', function(err, result) {
          if (err) {
            if (err.lde_message.indexOf("No Such Object") !== -1) {
              logger.error("Error when trying to check if password reset is enabled, error is: " + err);
              res.status(404).json(err);
            } else {
              logger.error("Error when trying to check if password reset is enabled, error is: " + err);
              res.status(500).json(err);
            }
          } else {
            if (result) {
              ldapClient.ldapConnection.compare(dn, 'email', email, function(err, result) {
                if (err) {
                    logger.error("Error when trying to compare email value, error is: " + err);
                    res.status(500).json(err);              
                } else {
                  if (result) {
                    ldapClient.generateAndSendOtp(dn, user, function(err, result) {
                      if (err) {
                        logger.error("Error when trying to send email, error is: " + err);
                        res.status(500).json(err);
                      } else {
                        res.status(200).json(result);
                      }
                    });
                  } else {
                    res.status(200).json(result);
                  }
                  
                } 
                ldap.returnLdapClient(ldapClient);     
              });
            } else {
              logger.error("Password reset is not enabled.");
              res.status(404).json(result);
            }
          }

        });
          
      }
  }); 
};

module.exports.resendOtp = function (req, res) {
  var user = req.body.user;
  var dn = "name=" + user + "," + utils.managementUiLdapConfig.ldapSettingsBaseDN;

   ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
    } else {
      ldapClient.generateAndSendOtp(dn, user, function(err, result) {
        if (err) {
          res.status(500).json(err);
        } else {
          res.status(200).json(result);
        }
      }); 
      }
      ldap.returnLdapClient(ldapClient);
  }); 
};

module.exports.getEmailConfig = function (req, res) {
  console.log(req.body.user);
  var user = req.body.user;
  var dn = "name=" + user + "," + utils.managementUiLdapConfig.ldapSettingsBaseDN;
  var searchOptions = {
    filter: '(name=' + user +')',
    scope: 'base',
    attributes: ['email', 'emailSmtpConfig', 'otherSettings']
  };
 
  ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
      return;
    } 
    async.waterfall([ 
      function(callback) {
        ldapClient.ldapConnection.search(dn, searchOptions, function(err, res) {
          var entries = [];
          res.on('searchEntry', function(entry) {
            entries.push(entry.object);
          }); 
          res.on('error', function(err) {
            logger.error('Error: ' + err.message);
            ldap.returnLdapClient(ldapClient);
            return;
          });
          res.on('end', function(result) {
            length = entries.length;
            return process.nextTick(function () {callback(null, entries, length);});
          });
        });
      },
      
      function(entries, length, callback) {
        ldap.returnLdapClient(ldapClient); 
        if(length == 1) {
          res.status(200).json(entries);
        }
        
      }  
          
    ]); 
  })
};

module.exports.validateOtp = function (req, res) {
  var user = req.body.user;
  var otp = req.body.otp;
  var dn = "name=" + user + "," + utils.managementUiLdapConfig.ldapSettingsBaseDN;

   ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
    } else {
        ldapClient.validateOTP(user, otp, function(err, result) {
          ldap.returnLdapClient(ldapClient);
          if (err) {
            logger.error("Error when trying to validate OTP, error is: " + err);
            res.status(500).json(err);                
          } else {
            res.status(200).json(result);           
          }
        });
      }
  });
};

module.exports.setNewPassword = function (req, res) {

  var user = req.body.username;
  var otp = req.body.otp;
  var dn = "name=" + user + "," + utils.managementUiLdapConfig.ldapSettingsBaseDN;

   ldap.acquireLdapClient(function(err, ldapClient) {
    if (err) {
      logger.error("Error when trying to connect to LDAP server, error is: " + err);
      res.status(500).json(err);
    } else {
      ldapClient.validateOTP(user, otp, function(err, resultdata) {
        if(err)
        {
          logger.error("Error when trying to get OTP data, error is: " + err);
          res.status(500).json(err);
        }
        else 
        {
          if(resultdata)
          {
            var changeotp = new ldapjs.Change({
              operation: 'replace',
              modification: {
                otp: ''
              }
            });                       

            var changepasswd = new ldapjs.Change({
              operation: 'replace',
              modification: {
                userPassword: req.body.password
              }
            });

            var userdn = "cn=" + user + "," + utils.managementUiLdapConfig.ldapUsersBaseDN;            
            ldapClient.ldapConnection.modify(userdn, changepasswd, function(err, result) {
              if (err) {
                if(err.lde_message.indexOf("Password match") !== -1 ) {
                  logger.error("Error when trying to change the password, error is: " + err);
                  res.status(406).json(err);
                } else {
                  logger.error("Error when trying to change the password, error is: " + err);
                  res.status(500).json(err);
                  ldapClient.ldapConnection.modify(dn, changeotp, function(err, result) {
                    if (err) {
                      logger.error("Failed to reset OTP: " + err);
                      res.status(500).json(err);              
                    } else {
                        logger.debug("OTP is being reset");
                      }
                  });
                }                 
              } else {
                logger.debug("User password updated ");
                res.status(200).json("User password updated"); 
                ldapClient.ldapConnection.modify(dn, changeotp, function(err, result) {
                  if (err) {
                    logger.error("Failed to reset OTP: " + err);
                    res.status(500).json(err);              
                  } else {
                      logger.debug("OTP is being reset");
                    }
                });
              }
            });
          } else {
            logger.error("Error: Failed to get OTP data" );
            res.status(500).json("Failed to get OTP data");
          }
        }
      });
     ldap.returnLdapClient(ldapClient);
    }
  });
};




