const express = require('express');
const path = require('path');
const morganLogger = require('morgan');
const logger = require('./api-server/utils/logger');
const utils = require('./api-server/utils/utils');
const cookieParser = require('cookie-parser');
const cookieSession = require('cookie-session');
const compression = require('compression');
const csrf = require('csurf');
const bodyParser = require('body-parser');
const config = require('./api-server/utils/config-index');
const crypto = require('crypto');
const user = require('./api-server/models/user');

// passport authentication with local and HTTP basic strategy
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const BasicStrategy = require('passport-http').BasicStrategy;
// configure passport
passport.use(new LocalStrategy(user.local));
passport.use(new BasicStrategy(user.basic));
passport.serializeUser(user.serializeUser);
passport.deserializeUser(user.deserializeUser);

const app = express();

const buf1 = crypto.randomBytes(32);
const buf2 = crypto.randomBytes(32);
const buf3 = crypto.randomBytes(32);

var cookieConfig = config.cookieSessionConfig;
cookieConfig.keys = [buf1.toString('hex'), buf2.toString('hex'), buf3.toString('hex')];

const cookieSessionMiddleware = cookieSession(cookieConfig);
const passportBasicAuthenticationMiddleware = passport.authenticate('basic', {session: false});
const passportInitializeMiddleware = passport.initialize();
const passportSessionMiddleware = passport.session();

const ignoredHttpMethods = ['GET', 'OPTIONS', 'HEAD'];
const csrfIgnoreSome = csrf({cookie: false, ignoreMethods: ignoredHttpMethods}); // CSRF control that ignore HTTP GET, HEAD and OPTIONS method
const csrfIgnoreNone = csrf({cookie: false, ignoreMethods: []});                 // CRRF control that does not ignore any HTTP methods

// prevent this header from being sent from the server
app.set('x-powered-by', false);

// a new morgan logger token for the rest api request id
morganLogger.token('id', function getRestAPIRequestId(req) {
  return req.restapi_request_id;
});

// a new morgan logger format string for logging rest api call
morganLogger.format('restapi', '[:id] :remote-addr - :remote-user [:date[clf]] ":method :url HTTP/:http-version" :status :res[content-length] :response-time ms');

var morganCommonLogger = morganLogger('common', {stream: logger.stream});
var morganRestAPILogger = morganLogger('restapi', {stream: logger.stream});

// assigne a unique id to each REST API request
app.use(config.apiPath, assignRestAPIRequestId);
app.use(logHttpRequest);
app.use(bodyParser.json({limit: '10mb'}));
app.use(bodyParser.urlencoded({limit:'10mb', extended: false }));
app.use(cookieParser()); // don't use cookie parser to sign cookies, use cookie session instead

//i18n init parses req for language headers, cookies, etc.
app.use(utils.i18n.init);

if (process.env.NO_AUTH_CSRF) {
  logger.warn('No CSRF token is enabled. No user authentication is enabled. This should only be used for development');
} else {
  app.use(useAuthentication);
  app.use(checkAuthorization);
  // Login APIs
  app.use('/', require('./api-server/routes/login-index'));
}

app.use(compression());

// REST API doc
app.use('/', require('./api-server/routes/api-doc'));

// REST APIs
app.use(config.apiPath, require('./api-server/routes/api-index'));
// For receiving DSA monitoring message from embedded DSA that stores messages
app.use('/', require('./api-server/routes/management-index'));
//For the Ldif file upload
app.use("/file", require('./api-server/utils/fileupload'));

// clear the loggedInUsername cookie when there is no user logged in
app.use(clearLoggedInUsernameCookie);

// static files
if (process.env.UNIT_TEST) {
  app.use(express.static(path.join(__dirname, '../../test/src/management-ui/public'), {fallthrough: false}));
} else {
  app.use(express.static(path.join(__dirname, 'public'), {fallthrough: false, setHeaders: setHttpHeadersForStaticFiles}));
}

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers
// development error handler, will print stacktrace
if (app.get('env') === 'development') {
  utils.enableDebugFeatures();
  logger.warn('Development error handler is used');
  app.use(function(err, req, res, next) {
    
		if (res.headersSent) {
      // pass to default error handler
      return next(err);
    }

		if (err.code !== 'EBADCSRFTOKEN') {
		
			// If the error code is 'no such file or directory', return the generic error here.
			if (err.code === 'ENOENT') {
				logger.error(req.url + ' cannot be found.');
				res.status(404).send({message: 'The URL cannot be found.'});	
			}
			
      res.status(err.status || 500).send({message: err.message, error: err});
    } else {
      logger.error('CSRF validation failed with error - ' + err, {id: req.restapi_request_id});
      res.status(403).send({message: 'CSRF validation failed'});
    }
  });
}

// production error handler, no stacktraces leaked to user
app.use(function(err, req, res, next) {

  if (res.headersSent) {
    // pass to default error handler
    return next(err);
  }

  if (err.code !== 'EBADCSRFTOKEN') {

    // If the error code is 'no such file or directory', return the generic error here.
    if (err.code === 'ENOENT') {
      logger.error(req.url + ' cannot be found.');
      res.status(404).send({message: 'The URL cannot be found.'});
      return next(err);
    }

    res.status(err.status || 500).send({message: err.message});
  } else {
    logger.error('CSRF validation failed with error - ' + err, {id: req.restapi_request_id});
    res.status(403).send({message: 'CSRF validation failed'});
  }
});

/**
 * Do HTTP Basic Authentication for the REST APIs
 * Otherwise, pass the control to the next middleware
 */
function doHttpBasicAuthentication(req, res, next) {
  // only do HTTP basic authentication for REST API
  if (req.path.startsWith(config.apiPath) || req.path.startsWith('/download') || req.path.startsWith('/saveEmailConfig') || req.path.startsWith('/getEmailConfig')) {
    // do the authentication here
    passportBasicAuthenticationMiddleware(req, res, next);
  } else {
    next();
  }
}

/**
 * Do CSRF and passport session - chaining the middleware functions
 */
function doCsrfAndPassportSession(req, res, next) {
  cookieSessionMiddleware(req, res, function(){
    useCsrfControl(req, res, function(){
      generateCsrfToken(req, res, function(){
        passportInitializeMiddleware(req, res, function(){
          passportSessionMiddleware(req, res, next);
        });
      });
    });
  });
}

/**
 * Do CSRF token, HTTP basic authentication or passport session based on whether
 * the HTTP authorization header is present or not
 */
function useAuthentication(req, res, next) {
  if (checkHttpBasicAuthHeaderPresence(req)) {
    doHttpBasicAuthentication(req, res, next);
  } else {
    doCsrfAndPassportSession(req, res, next);
  }
}

/**
 * Apply strict CSRF control on the REST API (no HTTP method is ignored)
 * Apply looser CSRF control on the other endpoints.
 */
function useCsrfControl(req, res, next) {
  logger.debug('URL path is - ' + req.path, {id: req.restapi_request_id});
  if (req.path.startsWith(config.apiPath) || req.path.startsWith('/download') || req.path.startsWith('/saveEmailConfig') || req.path.startsWith('/getEmailConfig')) {
    logger.debug('Strict CSRF control, no HTTP method is ignored', {id: req.restapi_request_id});
    csrfIgnoreNone(req, res, next);
  } else {
    logger.debug('Relaxed CSRF control, HTTP methods ignored are - ' + ignoredHttpMethods, {id: req.restapi_request_id});
    csrfIgnoreSome(req, res, next);
  }
}

/**
 * Check to see if there is a user logged in for the REST APIs
 */
function checkAuthorization(req, res, next) {
  // only enforce this on REST API
  if (req.path.startsWith(config.apiPath) || req.path.startsWith('/download') || req.path.startsWith('/saveEmailConfig') || req.path.startsWith('/getEmailConfig')) {
    if (req.user && req.isAuthenticated()) {
      logger.info('Logged in user is - "' + req.user.username + '"', {id: req.restapi_request_id});
      next();
    } else {
      logger.info('No user has logged in for REST API', {id: req.restapi_request_id});
      res.status(401).json({message: 'Unauthorized. No user has logged in for REST API'});
    }
  } else {
    next();
  }
}

/**
 * Check to see if HTTP basic authentication header is present
 */
function checkHttpBasicAuthHeaderPresence(req) {
  if (!req.headers || !req.headers.authorization) {
    logger.debug('HTTP basic authentication header is not present.', {id: req.restapi_request_id});
    return false;
  }
  logger.debug('HTTP basic authentication header is present.', {id: req.restapi_request_id});
  return true;
}

/**
 * Generate CSRF token
 */
function generateCsrfToken(req, res, next) {
  if (req.path === '/' || req.path === 'index.html') {
    res.cookie('XSRF-TOKEN', req.csrfToken(), config.cookieConfig);
  }
  next();
}

/**
 * Give the HTTP request to REST API a unique id for tracking purpose
 */
function assignRestAPIRequestId(req, res, next) {
  req.restapi_request_id = crypto.randomBytes(8).toString('hex');
  next();
}

/**
 * Add HTTP headers for static file index.html
 */
function setHttpHeadersForStaticFiles(res, path, stat) {
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Strict-Transport-Security', 'max-age=600; includeSubDomains; preload');
}

/**
 * Log the HTTP request
 */
function logHttpRequest(req, res, next) {
  if (req.path.startsWith(config.apiPath)) {
    morganRestAPILogger(req, res, next);
  } else {
    morganCommonLogger(req, res, next);
  }
}

/**
 *  Clear the "loggedInUserName" cookie
 */
function clearLoggedInUsernameCookie(req, res, next) {
  if (req.cookies) {
    var loggedInUsernameCookie = req.cookies[config.loggedInUserName];
    if (loggedInUsernameCookie && loggedInUsernameCookie.length && (!(req.user) || req.user.length === 0)) {
      logger.warn('Clearing logged in username cookie');
      res.clearCookie(config.loggedInUserName, config.cookieConfig);
    }
  }
  next();
}

module.exports = app;

require('./api-server/utils/autocleanup').cleanup();
