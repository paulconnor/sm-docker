/**
 * Default configuration options
 */
const winston = require('winston');
const path = require('path');

/**
 * REST API path
 */
module.exports.apiPath = '/ca/api/dxmanagement/v0.1';

/**
 * Configuration for running node.js web server on HTTPS
 */
module.exports.sslConfig = {
  key: path.join(__dirname, 'api-server', 'certs', 'webservercert.key'),
  cert: path.join(__dirname, 'api-server', 'certs', 'webservercert.pem'),
  secureProtocol: 'TLSv1_2_method',
  ciphers: 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256'
};

/**
 * The certificate file of the Certificate Authority that has issued the server certificate for this node js server
 */
module.exports.caCertificateFile = path.join(__dirname, 'CA', 'certs', 'ca.pem');

/**
 * Port number to run HTTP/HTTPS server on
 */
module.exports.port = 3100;

/**
 * winston logger configuration
 */
module.exports.winstonLoggerConfig = {
  emitError: true,
  config: {
    transports: [
      new winston.transports.File({
        level: 'error',
        filename: path.join(__dirname, 'logs', 'process-id-' + process.pid + '-.log'),
        handleExceptions: true,
        humanReadableUnhandledException: true,
        json: true,
        maxsize: 100000000,
        maxFiles: 100,
        colorize: false
      }),

      new winston.transports.Console({
        level: 'error',
        handleExceptions: true,
        humanReadableUnhandledException: true,
        json: false,
        colorize: true
      })
    ],

    exitOnError: true
  }
};

/**
 * Connection to the Management Server
 */
module.exports.mgmtServerConnection = {
  host: 'localhost',
  port: 3000,
  ssl: true,
  rejectUnauthorized: false,
  username: 'scim',
  password: 'changeme'                         // user credentials. Used in HTTP Basic authentication when using REST API.
};

/**
 * LDAP connection pool configuration
 */
module.exports.ldapConnectionPoolConfig = {
  max: 1024,                    // max number of connections
  idleTimeoutMillis: 300000,    // specifies how long a resource can stay idle in pool before being removed
  useProxiedConnection: false   // use the proxied connection, proxied connection requires two-way SSL
};

/**
 * LDAP syntaxes that can be treated as binary.
 * Syntax names are in lower case characters
 */
module.exports.ldapBinarySyntaxes = ['Binary', 'Bit String', 'Octet String', 'JPEG', 'Certificate', 'Certificate Pair', 'Certificate List', 'Audio', 'Fax'];
