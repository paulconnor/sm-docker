const assert = require('assert');
const ldap = require('../models/ldap-operations');
const dxagentOps = require('../models/dxagent-operations');
const utilsLogger = require('../utils/logger');
const utils = require('../utils/utils');
const fs = require('fs');
const config = require('../utils/config-index');
const EventEmitter = require('events').EventEmitter;
const Validator = require('jsonschema').Validator;
const jsonValidator = new Validator();
const async = require('async');
const crypto = require('crypto');
const ldap2date = require('ldap2date');
const dsaMessages = require('./dsa-messages');
const emailNotification = require('./email-notification');
const ldapjs = require('ldapjs');
const ObjectClasses = require('../models/object-classes');
const execSync = require('child_process').execSync;

const statusConfigOnly = 'configOnly';

const EXISTING_UNMANAGED_DSA = 'temp_existingUnmanagedDsa';
const DSAS_ARRAY = 'temp_dsaArray';
const SELF_KNOWLEDGE_ARRAY = 'temp_selfKnowledgeArray';
const KNOWLEDGE_ABOUT_SELF = 'temp_knowledgeSelf';
const UNMANAGED_DSA_AUTO_CREATED = 'auto';
const PROVIDED_MONITORING_LABEL_MAX_LENGTH = 12;
const NOTHING_TO_DO = 'Nothing to be done';

const dxagentAttributeList = utils.managementUiLdapConfig.uiDxagentUpdateAttributes.concat('serverCaCertPem');

/**
 * get the next alarm message id for alarm messages retrieved from dxagent
 */
var getNextAlarmMessageId = (function() {
  var id = 0;
  return function() {
    id++;
    if (id >= Number.MAX_SAFE_INTEGER) {
      // set it back to 1;
      id = 1;
    }
    return id;
  };
})();

var dxagentController = new EventEmitter();
const dsaNameRegExp = new RegExp('^[a-zA-Z0-9_\\-\\.]+$');

const alarmLogMessageRegExp = /^(DSA_([IWE])[0-9]{4})\s(.+)$/;

utilsLogger.info('DSA peers schema file is - "' + __dirname + '/dsa-peers-schema.json"');
// if this fails, it will throw and will terminate the program
const dsaPeersJsonSchema = JSON.parse(fs.readFileSync(__dirname + '/dsa-peers-schema.json'));

/**
 * Add the CA certificate of the server to dxagent as trusted CA
 */
function addServerCaCertificatePemToDxagent(logger, dxagent, environmentName, ldapClient, callback) {
  assert(arguments.length === 4 || arguments.length === 5);
  if (arguments.length === 4) {
    callback = ldapClient;
    ldapClient = null;
  }
  assert(typeof callback === 'function');

  var prefixArgs = 'Adding CA certificate of the server to dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  logger.info(utils.i18nTranslate(prefixArgs));

  async.series([
    // check file stats to see if its data has been changed or not.
    function (callback) {
      fs.lstat(config.caCertificateFile, function(err, stat) {
        if (err) {
          logger.error(utils.i18nTranslate(prefixArgs) + ': failed to get the file stat of the CA certificate file, error is "' + err + '"');
          // we still want to go ahead
          return process.nextTick(function () {callback();});
        }

        // see if the file has been modified
        if (!config.caCertificateStat || stat.mtime.getTime() !== config.caCertificateStat.mtime.getTime()) {
          config.caCertificateStat = stat;
          // read the file again
          fs.readFile(config.caCertificateFile, function(err, data) {
            if (err) {
              logger.error(utils.i18nTranslate(prefixArgs) + ': failed to read from the CA certificate file, error is "' + err + '"');
              // we still want to go ahead
              return process.nextTick(function () {callback();});
            }

            config.serverCaCertificatePem = data;
            config.base64EncodedServerCaCertificatePem = new Buffer(data).toString('base64');
            return process.nextTick(function () {callback();});
          });
        } else {
          return process.nextTick(function () {callback();});
        }
      });
    },
    function (callback) {
      // check the value of attribute "serverCaCertPem" on the dxagent object to see if CA certificate has been added or not
      if (dxagent.serverCaCertPem && dxagent.serverCaCertPem === config.base64EncodedServerCaCertificatePem) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': Server CA certificate has already been added to the dxagent "' + dxagent.name + '"');
        return process.nextTick(function(){callback(NOTHING_TO_DO);});
      }

      if (ldapClient) {
        doIt(ldapClient, function(err) {
          return process.nextTick(function(){callback(err);});
        });
      } else {
        ldap.acquireLdapClient(logger, 'en', function(err, ldapClientAcquired) {
          if (err) {
            return process.nextTick(function(){callback(err);});
          }

          doIt(ldapClientAcquired, function(err) {
            ldap.returnLdapClient(ldapClientAcquired);
            return process.nextTick(function(){callback(err);});
          });
        });
      }
    }
  ],
  function(err) {
    if (NOTHING_TO_DO === err) {
      return process.nextTick(function(){callback();});
    }
    return process.nextTick(function(){callback(err);});
  });

  function doIt(ldapClient, callback) {
    /**
     * Use the async library to execute tasks sequentially
     */
    var processingErrors = [];
    async.series([
      // check to see if there is any DSA with monitoring by management UI enabled
      function (callback) {
        ldapClient.listDsasBeingMonitoredInDxagent(dxagent.name, environmentName, function(err, dsasWithMonitoringOn) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // check to see if it is an empty list.No need to add if list is empty
          if (!dsasWithMonitoringOn || dsasWithMonitoringOn.length === 0) {
            logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA has been set up for monitoring for the dxagent "' + dxagent.name + '", so no need to add the server CA certificate to it');
            // this will end the sequence of callbacks
            return process.nextTick(function(){callback(NOTHING_TO_DO);});
          }
          // we want to go ahead
          return process.nextTick(function () {callback();});
        });
      },
      // we add the CA certificate to dxagent
      function (callback) {
        dxagentOps.getDxagentOperations(logger, 'en').addTrustedCa(dxagent, JSON.stringify({data: config.base64EncodedServerCaCertificatePem}), function(err) {
          return process.nextTick(function () {callback(err);});
        });
      },
      // CA certificate added successfully, update the "serverCaCertPem" attribute on dxagent object
      function (callback) {
        ldapClient.updateServerCaCertPemAttribute(dxagent.name, environmentName, config.base64EncodedServerCaCertificatePem, function(err) {
          if (err) {
            // save the error
            processingErrors = processingErrors.concat(err);
          }
        });
        // ignore the error and don't wait
        return process.nextTick(function(){callback();});
      }
    ],
    function(err) {
      if (NOTHING_TO_DO === err) {
        return process.nextTick(function(){callback();});
      }
      return process.nextTick(function(){callback(err);});
    });
  }
}

/**
 * Perform maintenance tasks
 */
function performMaintenanceTasks(callback) {
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});
  var prefixArgs = 'Performing maintenance tasks';
  logger.info(utils.i18nTranslate(prefixArgs));

  var processingErrors = [];

  ldap.acquireLdapClient(logger, function(err, ldapClient) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }
    /**
     * Use the async library to execute tasks sequentially
     */
    var environmentList;
    async.series([
      // list all environments
      function (callback) {
        ldapClient.listEnvironments(function(err, envs) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // no environment exists yet
          if (!envs || envs.length === 0) {
            logger.info(utils.i18nTranslate(prefixArgs) + ': no environment has been found, nothing to do');
            // this will end the whole callback sequence
            return process.nextTick(function () {callback(NOTHING_TO_DO);});
          }
          // we want to go ahead
          environmentList = envs;
          return process.nextTick(function () {callback();});
        });
      },
      // go through the list of environments
      function (callback) {
        // process all the environments sequentially
        async.eachSeries(environmentList,
          function(env, callback) {
            performMaintenanceTasksEnv(logger, ldapClient, env.name, function(err) {
              if (err) {
                processingErrors = processingErrors.concat(err);
              }
              return process.nextTick(function () {callback();});
            });
          },
          function(err)
          {
            logger.info(utils.i18nTranslate(prefixArgs) + ': processed all environments');
            return process.nextTick(function () {callback();});
          });
      }
    ],
    function(err) {
      ldap.returnLdapClient(ldapClient);

      // schedule a maintenance task next run
      setTimeout(function() {
        performMaintenanceTasks(function(){});
      }, config.maintenanceTaskInterval * 60 * 1000);

      if (NOTHING_TO_DO === err) {
        return process.nextTick(function(){callback();});
      }
      if (err) {
        try {
          var errorString = JSON.stringify(err);
          logger.error(utils.i18nTranslate(prefixArgs) + ': maintenance tasks finished with error - "' + errorString + '"');
        } catch (error) {
          logger.error(utils.i18nTranslate(prefixArgs) + ': maintenance tasks finished with error');
        }
      }
      return process.nextTick(function(){callback(err);});
    });
  });
}

/**
 * Perform maintenance task(s) on every dxagent in the named environment
 */
function performMaintenanceTasksEnv(logger, ldapClient, environmentName, callback) {
  var prefixArgs = 'Performing maintenance tasks for environment "' + environmentName + '"';
  logger.info(utils.i18nTranslate(prefixArgs));

  var processingErrors = [];

  /**
   * Use the async library to execute tasks sequentially
   */
  var dxagentList;
  async.series([
    // list all dxagents
    function (callback) {
      ldapClient.listDxagents(environmentName, function(err, dxagents) {
        if (err) {
          return process.nextTick(function () {callback(err);});
        }
        // no dxagent exists in the environment yet
        if (!dxagents || dxagents.length === 0) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': no dxagent has been found, nothing to do');
          // this will end the whole callback sequence
          return process.nextTick(function () {callback(NOTHING_TO_DO);});
        }
        // we want to go ahead
        dxagentList = dxagents;
        //logger.debug(utils.i18nTranslate(prefixArgs) + ': dxagent list is "' + JSON.stringify(dxagentList) + '"');
        return process.nextTick(function () {callback();});
      });
    },
    // go through the list of dxagents
    function (callback) {
      // process all the dxagents sequentially
      async.eachSeries(dxagentList,
        function(dxagent, callback) {
          performMaintenanceTasksDxagent(logger, dxagent, environmentName, ldapClient, function(err) {
            if (err) {
              processingErrors = processingErrors.concat(err);
            }
            return process.nextTick(function () {callback();});
          });
        },
        function(err)
        {
          logger.info(utils.i18nTranslate(prefixArgs) + ': processed all dxagents');
          return process.nextTick(function () {callback();});
        });
    }
  ],
  function(err) {
    if (NOTHING_TO_DO === err) {
      return process.nextTick(function(){callback();});
    }
    return process.nextTick(function(){callback(err);});
  });
}

/**
 * Performa maintenance tasks for the dxagent
 */
function performMaintenanceTasksDxagent(logger, dxagent, environmentName, ldapClient, callback) {
  var prefixArgs = 'Perform maintenance tasks for dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  logger.info(utils.i18nTranslate(prefixArgs));

  var processingErrors = [];
  var tasks = [];
  dxagentMaintenanceTasks.forEach(function(oneTask) {
    tasks.push(function(callback){
      oneTask(logger, dxagent, environmentName, ldapClient, function(err) {
        if (err) {
          processingErrors = processingErrors.concat(err);
        }
        return process.nextTick(function(){callback(err);});
      });
    });
  });

  /**
   * Use the async library to execute tasks sequentially
   */
  async.series(tasks,
  function() {
    if (processingErrors.length > 0) {
      return process.nextTick(function(){callback(processingErrors);});
    }
    return process.nextTick(function(){callback();});
  });
}

/**
 * Perform maintenance tasks for all DSAs with monitoring by management UI enabled on the dxagent
 */
function performMaintenanceTasksForAllMonitoredDsasOnDxagent(logger, dxagent, environmentName, ldapClient, callback) {
  var prefixArgs = 'Perform maintenance tasks for all DSAs with monitoring by management UI enabled on dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  logger.info(utils.i18nTranslate(prefixArgs));

  var processingErrors = [];

  /**
   * Use the async library to execute tasks sequentially
   */
  var dsaList;
  async.series([
    // list all dsas
    function (callback) {
      ldapClient.listDsasBeingMonitoredInDxagent(dxagent.name, environmentName, function(err, dsas) {
        if (err) {
          return process.nextTick(function () {callback(err);});
        }
        // no dsa exists
        if (!dsas || dsas.length === 0) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA has been found, nothing to do');
          // this will end the whole callback sequence
          return process.nextTick(function () {callback(NOTHING_TO_DO);});
        }
        // we want to go ahead
        dsaList = dsas;
        return process.nextTick(function () {callback();});
      });
    },
    // go through the list of dsas
    function (callback) {
      // process all the dsas sequentially
      async.eachSeries(dsaList,
        function(currentDsa, callback) {
          performMaintenanceTasksMonitoredDsa(logger, currentDsa, dxagent, environmentName, ldapClient, function(err) {
            if (err) {
              processingErrors = processingErrors.concat(err);
            }
            return process.nextTick(function () {callback();});
          });
        },
        function(err)
        {
          logger.info(utils.i18nTranslate(prefixArgs) + ': processed all dsas');
          return process.nextTick(function () {callback();});
        });
    }
  ],
  function(err) {
    if (NOTHING_TO_DO === err) {
      return process.nextTick(function(){callback();});
    }
    return process.nextTick(function(){callback(err);});
  });
}

/**
 * Perform maintenance tasks for the named DSA that is being monitored
 * It will execute all the maintenance tasks and save the errors
 */
function performMaintenanceTasksMonitoredDsa(logger, dsa, dxagent, environmentName, ldapClient, callback) {
  var prefixArgs = 'Perform maintenance tasks for DSA "' + dsa.name + '" with monitoring by management UI enabled on dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  logger.info(utils.i18nTranslate(prefixArgs));

  var processingErrors = [];
  var tasks = [];
  dsaMaintenanceTasks.forEach(function(oneTask) {
    tasks.push(function(callback){
      oneTask(logger, dsa, dxagent, environmentName, ldapClient, function(err) {
        if (err) {
          processingErrors = processingErrors.concat(err);
        }
        return process.nextTick(function(){callback(err);});
      });
    });
  });

  /**
   * Use the async library to execute tasks squentially
   */
  async.series(tasks,
  function() {
    if (processingErrors.length > 0) {
      return process.nextTick(function(){callback(processingErrors);});
    }
    return process.nextTick(function(){callback();});
  });
}

/**
 * Get the alarm messages from the DSA since the last time it was received
 */
function getNewAlarmMessagesDsa(logger, dsa, dxagent, environmentName, ldapClient, callback) {
  var prefixArgs = 'Getting alarm messages that have not been received before for DSA "' + dsa.name + '" on dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  logger.info(utils.i18nTranslate(prefixArgs));

  /**
   * Use the async library to execute tasks sequentially
   */
  var dateNow = new Date();
  dateNow.setDate(dateNow.getDate() - 7);
  var lastReceivedTime = utils.dateToDsaTimestamp(dateNow); // default to getting a week's worth of alarms
  var alarmLogMessages;

  async.series([
    // get the stored alarms for the DSA
    function (callback) {
      ldapClient.getLastAlarmTime(dsa.name, dxagent.name, environmentName, function(err, timestamp) {
        if (err) {
          return process.nextTick(function(){callback(err);});
        }
        // find out the last time alarm was received
        if (timestamp) {
          var lastReceivedDate = ldap2date.parse(timestamp);
          if (lastReceivedDate.getTime() > dateNow.getTime()) {
            // increase miniseconds by 1 to avoid retrieving the same alarm messages again
            lastReceivedDate.setMilliseconds(lastReceivedDate.getMilliseconds() + 1);
            lastReceivedTime = utils.dateToDsaTimestamp(lastReceivedDate);
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': last time an alarm log message was received/retrieved from dxagent - "' + lastReceivedTime + '"');
        }
        return process.nextTick(function(){callback();});
      });
    },
    // call the dxagent api to get the alarm logs
    function (callback) {
      dxagentOps.getDxagentOperations(logger, 'en').getAlarmLogMessages(dxagent, dsa.name, lastReceivedTime, function(err, logMessages){
        if (err) {
          return process.nextTick(function(){callback(err);});
        }

        logger.debug(utils.i18nTranslate(prefixArgs) + ': alarm log messages retrieved from dxagent - "' + JSON.stringify(logMessages) + '"');
        if (!logMessages || logMessages.length === 0) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': no alarm message has been retrieved from dxagent, nothing to do');
          // this will end the whole callback sequence
          return process.nextTick(function () {callback(NOTHING_TO_DO);});
        }

        alarmLogMessages = logMessages;
        return process.nextTick(function(){callback();});
      });
    },
    // now save the alarm message and send them through SSE
    function (callback) {
      // define a function to turn a alarm log message into an alarm object for storage
      function createDsaAlarmObject(alarmMessage) {
        if (!alarmMessage.time || !alarmMessage.message) {
          return null;
        }

        var messageComponents = alarmMessage.message.match(alarmLogMessageRegExp);
        if (!messageComponents) {
          return null;
        }

        logger.debug(utils.i18nTranslate(prefixArgs) + ': alarm log message components - "' + JSON.stringify(messageComponents) + '"');

        var alarmObject = {};
        alarmObject.time = utils.dsaTimestampToLdap(alarmMessage.time);
        alarmObject.messageId = getNextAlarmMessageId();
        alarmObject.name = alarmObject.messageId + ':' + alarmObject.time;
        alarmObject.host =  dxagent.host;
        alarmObject.id = messageComponents[1];
        alarmObject.type = (function(type) {
          if (type === 'E') return 'critical';
          if (type === 'W') return 'caution';
          if (type === 'I') return 'information';
          return 'unknown';
        }(messageComponents[2]));
        alarmObject.message = messageComponents[3];
        logger.debug(utils.i18nTranslate(prefixArgs) + ': created alarm object - "' + JSON.stringify(alarmObject) + '"');

        return alarmObject;
      }

      var processingErrors = [];

      // process each of the retrieved alarm message
      async.eachSeries(
        alarmLogMessages,
        function (oneAlarmMessage, callback) {
          var alarmObject = createDsaAlarmObject(oneAlarmMessage);
          if (!alarmObject) {
            logger.debug(utils.i18nTranslate(prefixArgs) + ': failed to create an alarm object for alarm message  - "' + JSON.stringify(oneAlarmMessage) + '"');
            return process.nextTick(function(){callback();});
          }

          // do the SSE
          dsaMessages.alarmMessageType.emitter.emit('message', {dsaName: dsa.name, dxagentName: dxagent.name, environmentName: environmentName, 'messageType': dsaMessages.alarmMessageType.messageType}, alarmObject);

          // send the email notification by scheduling the sending of email to run after I/O events' callbacks are cleared
          var alarm = {};
          Object.assign(alarm, alarmObject, {host: dxagent.name, dsa: dsa.name});
          setImmediate(emailNotification.sendEmail, environmentName, alarm);

          // save the alarm object in directory
          ldapClient.storeDsaAlarm(dsa.name, dxagent.name, environmentName, alarmObject, function(err) {
            if (err) {
              processingErrors.push(err);
            }
            return process.nextTick(function(){callback();});
          });
        },
        function (err) {
          return process.nextTick(function(){callback(processingErrors);});
        }
      );
    }
  ],
  function(err) {
    if (NOTHING_TO_DO === err) {
      return process.nextTick(function(){callback();});
    }
    return process.nextTick(function(){callback(err);});
  });
}

/**
 * Retrieve DSA schema for all supported languages
 *
 * @param logger
 * @param dxagent
 * @param callback(err, result)
 *
 * @returns
 */
function retrieveDsaSchemas(prefixArgs, logger, dxagent, callback) {
  var locales = utils.getLocales();
  if (!locales || locales.length === 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': not retrieving any DSA JSON schema as locales array is empty');
    return process.nextTick(function(){callback(null, null);});
  }

  var dsaSchemas = {};

  // define a function to recursively retrieve the DSA schema for each language
  function retrieveOne(index) {
    if (index === locales.length) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished retrieving DSA JSON schemas for locales "' + locales + '"');
      if (dsaSchemas) {
        try {
          dsaSchemas = JSON.stringify(dsaSchemas);
        } catch (error) {
          logger.error(utils.i18nTranslate(prefixArgs) + ': failed to stringify retrieved DSA JSON schemas, error is - "' + error + '"');
          return process.nextTick(function(){callback(error);});
        }
        return process.nextTick(function(){callback(null, dsaSchemas);});
      } else {
        return process.nextTick(function(){callback(null, null);});
      }
    }

    var currentLocale = locales[index];
    dxagentOps.getDxagentOperations(logger, currentLocale).getDsaJsonSchema(dxagent, function(err, data) {
      if (err) {
        logger.warn(utils.i18nTranslate(prefixArgs) + ': retrieving DSA JSON schemas for locale "' + currentLocale + '" failed with error - ' + err );
      } else {
        logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved DSA JSON schemas for locale "' + currentLocale + '"');
        dsaSchemas[currentLocale] = data;
      }
      retrieveOne(index + 1);
    });
  }
  // start
  retrieveOne(0);
}

/**
 * Retrieve schema for a specific locale
 */
function retrieveDsaSchemaForLocale(prefixArgs, ldapClient, dxagent, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  /**
   * Use async library
   */
  async.waterfall([
    // get DSA json schema
    function (callback) {

      // try parse the stored JSON schemas
      var storedSchemas;
      var schemaToReturn;

      if (dxagent.dsaJsonSchema) {
        try {
          storedSchemas = JSON.parse(dxagent.dsaJsonSchema);
        } catch (error) {
          logger.warn(utils.i18nTranslate(prefixArgs) + ': failed to parse dsaJsonSchema property on dxagent with error - "' + error + '"');
        }
      }

      // retrieve from dxagent
      dxagentOps.getDxagentOperations(logger, locale).getDsaJsonSchema(dxagent, function(err, data) {
        if (err) {
          // failed to retrieve DSA Json schema from dxagent, try cached ones
          logger.error(utils.i18nTranslate(prefixArgs) + ': failed to retrive DSA json schema from dxagent for locale "' + locale + '", error is - "' + err + '"');
          // check to see if there is a cache copy for the locale
          if (storedSchemas && storedSchemas[locale]) {
            schemaToReturn = storedSchemas[locale];
            return callback(null, storedSchemas, schemaToReturn);
          } else {
            logger.warn(utils.i18nTranslate(prefixArgs) + ': no stored DSA json schema for locale "' + locale + '" is found');
            // return original error from dxagent
            return callback(err);
          }
        } else {
          schemaToReturn = data;
          return callback(null, storedSchemas, schemaToReturn);
        }
      });
    },
    // update dsaJsonSchema attribute on dxagent in directory
    function (storedSchemas, schemaToReturn, callback) {
      // check to see if we need to update
      if (!storedSchemas || !storedSchemas[locale] || storedSchemas[locale] !== schemaToReturn) {
        if (!storedSchemas) {
          storedSchemas = {};
          storedSchemas[locale] = schemaToReturn;
        } else {
          storedSchemas[locale] = schemaToReturn;
        }
        // save to directory
        ldapClient.updateDxagentDsaJsonSchemaAttribute(dxagent.name, environmentName, storedSchemas, function(err) {
          if (err) {
            logger.warn(utils.i18nTranslate(prefixArgs) + ': failed to update dsaJsonSchema attribute on dxagent, error is - "' + err + '"');
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': dsaJsonSchema attribute on dxagent updated');
          }
          // never return an error
          return callback(null, schemaToReturn);
        });
      } else {
        // no need to update
        return process.nextTick(function () {callback(null, schemaToReturn);});
      }
    }
  ],
  function(err, schemaToReturn) {
    if (err) {
      return process.nextTick(function () {callback(err);});
    } else {
      return process.nextTick(function () {callback(null, schemaToReturn);});
    }
  });
}

/**
 * Find what are the missing attributes that are required
 */
function checkRequiredAttributes(requestObject, requiredAttributeArray) {
  var missingAttrs = [];
  requiredAttributeArray.forEach(function(attr) {
    if (!requestObject[attr]) {
      missingAttrs.push(attr);
    }
  });
  return missingAttrs;
}

/**
 * check among the array of existing dxagents, if there is one (with different name) with the
 * same host name and port number conbination
 */
function checkHostnameAndPort(requestObject, existingDxagents) {
  if (existingDxagents && Array.isArray(existingDxagents)) {
    for (var i = 0; i < existingDxagents.length; i++) {
      if (requestObject.name != existingDxagents[i].name &&
          requestObject.host == existingDxagents[i].host &&
          requestObject.port == existingDxagents[i].port) {
        return existingDxagents[i];
      }
    }
  }
}

/**
 * Check DSA name conflict on the same dxagent. DSA names are case-insensitive
 *
 * @param prefixArgs
 * @param ldapClient
 * @param dsaName
 * @param dxagentName
 * @param environmentName
 * @param callback(err)
 */
function checkDsaNameConflict(prefixArgs, ldapClient, dsaName, dxagentName, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  // get the list of DSAs for this dxagent
  ldapClient.listDsas(dxagentName, environmentName, function(err, dsasForCurrentDxagent) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }

    // if there is no DSA on the dxagent
    if (!dsasForCurrentDxagent || dsasForCurrentDxagent.length === 0) {
      return process.nextTick(function(){callback();});
    }

    // check the names now
    var nameConflictIndex = dsasForCurrentDxagent.findIndex(function(currentDsa) {
      if (currentDsa && currentDsa.name && currentDsa.name.toUpperCase() === dsaName.toUpperCase()) {
        return true;
      }
    });

    if (nameConflictIndex !== -1) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': DSA name conflicts with other DSA names on dxagent "' + dxagentName + '" in environment "' + environmentName + '"');
      var nameConflictError = utils.createLocalizedAPIError(locale, prefixArgs, ['errors.dsaNameConflictOnDxagent', dsaName, dxagentName, environmentName], 409);
      return process.nextTick(function(){callback(nameConflictError);});
    } else {
      return process.nextTick(function(){callback();});
    }
  });
}

/**
 * Get all the DSAs on all the dxagent hosts in the environment
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param callback
 */
function getAllDSAsInEnvironment(prefixArgs, ldapClient, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  logger.info(utils.i18nTranslate(prefixArgs) + ': retrieving all DSAs for all dxagents');

  // call into LDAP server to get the list of dxagents
  ldapClient.listDxagents(environmentName, function(err, dxagentsInEnvironment) {
    if (err) {
      ldap.returnLdapClient(ldapClient);
      return process.nextTick(function(){callback(err);});
    }

    if (dxagentsInEnvironment.length > 0) {
      // go through the list of dxagents and retrieve the list of DSAs for them
      getDsasForDxagents(dxagentsInEnvironment, function(err) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return process.nextTick(function(){callback(err);});
        } else {
          return process.nextTick(function(){callback(null, dxagentsInEnvironment);});
        }
      });
    } else {
      // no dxagent exist in the environment yet, return the empty list
      ldap.returnLdapClient(ldapClient);
      return process.nextTick(function(){callback(null, dxagentsInEnvironment);});
    }

    /**
     * Define a function to retrieve all DSAs for all the dxagents
     *
     * @param dxagentsInEnv
     * @param callback
     */
    function getDsasForDxagents(dxagentsInEnv, callback) {

      /**
       * Define a function to retrieve DSAs for one dxagent
       *
       * @param dxagentIndex
       * @param callback
       */
      function getDsasForDxagent(dxagentIndex, callback) {
        if (dxagentIndex === dxagentsInEnv.length) {
          // no more dxagent
          logger.info(utils.i18nTranslate(prefixArgs) + ': finished retrieving all DSAs for all dxagents');
          return process.nextTick(function(){callback();});
        }

        // get the dxagent at the current index
        var currentDxagent = dxagentsInEnv[dxagentIndex];

        // get the list of DSAs for this dxagent
        ldapClient.listDsas(currentDxagent.name, environmentName, function(err, dsasForCurrentDxagent) {
          if (err) {
            return process.nextTick(function(){callback(err);});
          } else {
            // retrieved the DSAs
            currentDxagent[DSAS_ARRAY] = dsasForCurrentDxagent;
            // go to the next dxagent
            getDsasForDxagent(dxagentIndex + 1, callback);
          }
        });
      }
      // kick off the retrieving here
      getDsasForDxagent(0, callback);
    }
  });
}

/**
 * Find out if there is an unmanaged DSA in the environment that is the same DSA for
 * each DSA being imported in the list. If a match is found, set the gloablKnowledge to
 * be the same as the unmanaged DSA and mark the unmanaged DSA as needing deletion.
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param managedDsas
 * @param callback(err, unmanagedDsas) - unmanagedDsas could be null or empty
 */
function findMatchingUnmanagedDsasForDsas(prefixArgs, ldapClient, environmentName, managedDsas, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  logger.info(utils.i18nTranslate(prefixArgs) + ': finding matching unmanaged DSA for the DSAs being imported');

  if (!managedDsas || !(Array.isArray(managedDsas)) || managedDsas.length === 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': empty managed DSA list, no need to check unmanaged DSAs');
    return process.nextTick(function(){callback(null, []);});
  }

  // get the list of unmanaged DSAs first
  ldapClient.listUnmanagedDsas(environmentName, function(err, unmanagedDsas) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }

    // see if we have any unmanaged DSA
    if (!unmanagedDsas || !(Array.isArray(unmanagedDsas)) || unmanagedDsas.length === 0) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': there is no unmanaged DSAs in the environment');
    }

    // now go through the list
    managedDsas.forEach(function(managedDsa) {
      var knowledgeAboutSelf = utils.getKnowledgeAboutSelf(managedDsa);
      if (!knowledgeAboutSelf) {
        logger.warn(utils.i18nTranslate(prefixArgs) + ': no knowledge about the DSA itself has been found for DSA "' + managedDsa.name + '"');
        return;
      } else {
        managedDsa[KNOWLEDGE_ABOUT_SELF] = knowledgeAboutSelf;
        // find the unamanaged DSA with the same name and has one interface item to be the same
        if (unmanagedDsas.length > 0) {
          var foundUnmanagedDsa = unmanagedDsas.find(function(unmanagedDsa) {
            if (managedDsa.name.toUpperCase() === unmanagedDsa.name.toUpperCase()) {
              // check the interfaces now
              var managedInterface = knowledgeAboutSelf.interface;
              var unmanagedInterface = unmanagedDsa.config.interface;
              if (managedInterface && Array.isArray(managedInterface) && managedInterface.length > 0) {
                if (unmanagedInterface && Array.isArray(unmanagedInterface) && unmanagedInterface.length > 0) {
                  // now go through the interface ...
                  var matchedInterface = findMatchingInterface(managedInterface, unmanagedInterface);
                  // if we found a match
                  if (matchedInterface) {
                    return true;
                  }
                } else {
                  logger.warn(utils.i18nTranslate(prefixArgs) + ': invalid interface configuration for unmanaged DSA "' + unmanagedDsa.name + '"');
                }
              } else {
                logger.warn(utils.i18nTranslate(prefixArgs) + ': invalid interface configuration for managed DSA "' + managedDsa.name + '"');
              }
            }
            return false;
          });

          // if we found an unmanaged DSA, save it on the managed DSA object
          if (foundUnmanagedDsa) {
            logger.warn(utils.i18nTranslate(prefixArgs) + ': found a corresponding unmanaged DSA for DSA "' + managedDsa.name + '"');
            managedDsa[EXISTING_UNMANAGED_DSA] = foundUnmanagedDsa;
            if (foundUnmanagedDsa.globalKnowledge) {
              managedDsa.globalKnowledge = foundUnmanagedDsa.globalKnowledge;
            }
          }
        }
      }
    });

    logger.info(utils.i18nTranslate(prefixArgs) + ': finished checking all unmanaged DSAs in the environment');
    return process.nextTick(function(){callback(null, unmanagedDsas);});
  });
}

/**
 * Compare interface objects ignoring case of address.
 * if matched return true, else false.
 */

function compareMatchingInterfaceIgnoreAddressCase(i1, i2)
{
  try {
    for (const property in i1) {
      if( property === "address") {
        if(!(i1[property].toLowerCase() === i2[property].toLowerCase())) {
          return false;
        }
      }
      else {
        assert.deepEqual(i1[property], i2[property]);
      }
    }
    return true;
  }
  catch (error) {}
  return false;
}


/**
 * Find an interface item in interfaceOne that matches an interface item in interfaceTwo. Return
 * matched interface item in interfaceOne. Return undefined when no match is found.
 *
 * @param interfaceOne
 * @param interfaceTwo
 */
function findMatchingInterface(interfaceOne, interfaceTwo) {

  var matchedInterface = interfaceOne.find(function(oneInterfaceOne) {
    for (var i = 0; i < interfaceTwo.length; i++) {
      try {
        assert.deepEqual(oneInterfaceOne, interfaceTwo[i]);
        return true;
      }
      catch (error) {}
      if(compareMatchingInterfaceIgnoreAddressCase(oneInterfaceOne, interfaceTwo[i])) {
        return true;
      }
    }
    return false;
  });

  return matchedInterface;
}

/**
 * Find the matching knowledge item in knowledgeList that matches oneKnowledge.
 *
 * The name has to be the same;
 * There is at least one interface definition that matches.
 *
 * @param prefixArgs
 * @param logger
 * @param oneKnowledge
 * @param knowledgeList
 */
function findMatchingKnowledgeItem(prefixArgs, logger, oneKnowledge, knowledgeList) {

  var foundMatchingKnowledge = knowledgeList.find(function(oneInknowledgeList) {
    if (oneKnowledge.name && oneInknowledgeList.name && typeof oneKnowledge.name === 'string' && typeof oneInknowledgeList.name === 'string' && oneKnowledge.name.toUpperCase() === oneInknowledgeList.name.toUpperCase()) {
      // check the interfaces now
      var interfaceOne = oneKnowledge.interface;
      var interfaceTwo = oneInknowledgeList.interface;
      if (interfaceOne && Array.isArray(interfaceOne) && interfaceOne.length > 0) {
        if (interfaceTwo && Array.isArray(interfaceTwo) && interfaceTwo.length > 0) {
          // now go through the interface ...
          var matchedInterface = findMatchingInterface(interfaceOne, interfaceTwo);
          // if we found a match
          if (matchedInterface) {
            return true;
          }
        } else {
          logger.warn(utils.i18nTranslate(prefixArgs) + ': invalid interface configuration for knowledge "' + oneInknowledgeList.name + '"');
        }
      } else {
        logger.warn(utils.i18nTranslate(prefixArgs) + ': invalid interface configuration for knowledge "' + oneKnowledge.name + '"');
      }
    }
    return false;
  });

  return foundMatchingKnowledge;
}

/**
 * Find the matching knowledge index in knowledgeList that matches oneKnowledge.
 *
 * The name has to be the same;
 * There is at least one interface definition that matches.
 *
 * @param prefixArgs
 * @param logger
 * @param oneKnowledge
 * @param knowledgeList
 */
function findMatchingKnowledgeIndex(prefixArgs, logger, oneKnowledge, knowledgeList) {

  var foundMatchingKnowledgeIndex = knowledgeList.findIndex(function(oneInknowledgeList) {
    if (oneKnowledge.name && oneInknowledgeList.name && typeof oneKnowledge.name === 'string' && typeof oneInknowledgeList.name === 'string' && oneKnowledge.name.toUpperCase() === oneInknowledgeList.name.toUpperCase()) {
      // check the interfaces now
      var interfaceOne = oneKnowledge.interface;
      var interfaceTwo = oneInknowledgeList.interface;
      if (interfaceOne && Array.isArray(interfaceOne) && interfaceOne.length > 0) {
        if (interfaceTwo && Array.isArray(interfaceTwo) && interfaceTwo.length > 0) {
          // now go through the interface ...
          var matchedInterface = findMatchingInterface(interfaceOne, interfaceTwo);
          // if we found a match
          if (matchedInterface) {
            return true;
          }
        } else {
          logger.warn(utils.i18nTranslate(prefixArgs) + ': invalid interface configuration for knowledge "' + oneInknowledgeList.name + '"');
        }
      } else {
        logger.warn(utils.i18nTranslate(prefixArgs) + ': invalid interface configuration for knowledge "' + oneKnowledge.name + '"');
      }
    }
    return false;
  });

  return foundMatchingKnowledgeIndex;
}

/**
 * Check the knowledge setting of DSAs being imported.
 *
 * 1) if the DSA is marked as globalKnowledge, then add the global knowledge list to the DSA.
 * 2) if the DSA is not marked as globalKnowledge, then go through its knowledge list and find out if we need to create unmanaged DSAs for any item. Fail operation
 *    when there is already one unmanaged DSA with the same name but different interface
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param newDxagent
 * @param managedDsas
 * @param unmanagedDsas
 * @param callback(err, allDsasWithDxagents, knowledgeWithoutExistingDsa)
 */
function checkKnowldgeSettingsOfDsas(prefixArgs, ldapClient, environmentName, newDxagent, managedDsas, unmanagedDsas, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  logger.info(utils.i18nTranslate(prefixArgs) + ': checking the knowledge settings of the DSAs being imported');

  if (!managedDsas || !(Array.isArray(managedDsas)) || managedDsas.length === 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': empty managed DSA list, no need to check');
    return process.nextTick(function(){callback(null, [], []);});
  }

  // get all the existing DSAs on all existing dxagent hosts first
  getAllDSAsInEnvironment(prefixArgs, ldapClient, environmentName, function(err, allDsasWithDxagents) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }

    if (allDsasWithDxagents.length === 0) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': no existing dxagent found in the environment');
    }

    // build the globalKnowledge list now
    utils.buildGlobalKnowledgeList(ldapClient, environmentName, function(err, globalKnowledgeListInEnv) {
      if (err) {
        return process.nextTick(function(){callback(err);});
      }

      var complateKnowledgeList = [];
      var knowledgeWithoutExistingDsa = [];

      // go through the list of DSAs and find self knowledge for each of them.
      allDsasWithDxagents.forEach(function(oneDxagent) {
        if (oneDxagent[DSAS_ARRAY] && Array.isArray(oneDxagent[DSAS_ARRAY])) {
          oneDxagent[DSAS_ARRAY].forEach(function(oneDsa) {
            var selfKnowledge = utils.getKnowledgeAboutSelf(oneDsa);
            if (selfKnowledge) {
              complateKnowledgeList.push(selfKnowledge);
            } else {
              logger.warn(utils.i18nTranslate(prefixArgs) + ': DSA "' + oneDsa.name + '" does not have knowledge setting for itself');
            }
          });
        }
      });

      // add self knowledge of DSAs being imported to the list
      managedDsas.forEach(function(managedDsa) {
        if (managedDsa[KNOWLEDGE_ABOUT_SELF]) {
          complateKnowledgeList.push(managedDsa[KNOWLEDGE_ABOUT_SELF]);
        }
      });

      // add unmanaged DSAs to the list
      unmanagedDsas.forEach(function(unmanagedDsa) {
        if (unmanagedDsa.config) {
          complateKnowledgeList.push(unmanagedDsa.config);
        }
      });

      // now go through the list
      managedDsas.forEach(function(managedDsa) {
        if (!managedDsa[KNOWLEDGE_ABOUT_SELF]) {
          logger.warn(utils.i18nTranslate(prefixArgs) + ': no knowledge about the DSA itself has been found for DSA "' + managedDsa.name + '"');
          return;
        }

        if (managedDsa.globalKnowledge) {
          // if DSA has globalKnowledge - add globalKnowledge list plus self knowledge if it is not in the global knowledge list
          if (globalKnowledgeListInEnv && globalKnowledgeListInEnv.length > 0) {
            var matchToSelfKnowledge = findMatchingKnowledgeItem(prefixArgs, logger, managedDsa[KNOWLEDGE_ABOUT_SELF], globalKnowledgeListInEnv);
            if (matchToSelfKnowledge) {
              managedDsa.config.knowledge = globalKnowledgeListInEnv;
            } else {
              managedDsa.config.knowledge = globalKnowledgeListInEnv.concat(managedDsa[KNOWLEDGE_ABOUT_SELF]);
            }
          } else {
            managedDsa.config.knowledge = managedDsa[KNOWLEDGE_ABOUT_SELF];
          }
        } else {
          // if DSA does not have globalKnowledge
          if (managedDsa.config && managedDsa.config.knowledge && Array.isArray(managedDsa.config.knowledge) && managedDsa.config.knowledge.length > 0) {
            managedDsa.config.knowledge.forEach(function(oneKnowledge) {
              if (!findMatchingKnowledgeItem(prefixArgs, logger, oneKnowledge, complateKnowledgeList)) {
                // we need to create unmanaged DSA here
                if (!findMatchingKnowledgeItem(prefixArgs, logger, oneKnowledge, knowledgeWithoutExistingDsa)) {
                  logger.info(utils.i18nTranslate(prefixArgs) + ': unmanaged DSA needs to be created for knowledge item with name "' + oneKnowledge.name + '"');
                  knowledgeWithoutExistingDsa.push(oneKnowledge);
                }
              }
            });
          }
        }
      });

      // check names in knowledgeWithoutExistingDsa with names for all unmanaged DSAs
      if (knowledgeWithoutExistingDsa.length > 0 && unmanagedDsas && unmanagedDsas.length > 0) {
        var nameConflictedKnowledgeItem = knowledgeWithoutExistingDsa.find(function(oneKnowledgeWithoutExistingDsa) {
          if (unmanagedDsas.find(function(oneUnmanagedDsa) {
            if (oneUnmanagedDsa.name.toUpperCase() === oneKnowledgeWithoutExistingDsa.name.toUpperCase()) {
              return true;
            }
            return false;
          })) {
            return true;
          }
          return false;
        });

        if (nameConflictedKnowledgeItem) {
          var nameConflictError = utils.createLocalizedAPIError(locale, prefixArgs, 'errors.nameConflictWithExistingUnmanagedDsa', 400);
          return process.nextTick(function(){callback(nameConflictError);});
        }
      }

      // done checking all DSAs being imported
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished checking the knowledge settings of the DSAs being imported');
      return process.nextTick(function(){callback(null, allDsasWithDxagents, knowledgeWithoutExistingDsa);});
    });
  });
}

/**
 * Save the new dxagent object and its DSAs:
 *
 * 1) Save the new dxagent object in directory, if it fails, fail the operation;
 * 2) Go through the list of DSAs being imported,
 *    a. Save the DSA object in directory, if it fails, log the error message and add an error object to the list of processing errors
 *    b.
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param newDxagent
 * @param managedDsas
 * @param allDsasWithDxagents
 * @param callback(err, dxagentCreated)
 */
function saveDxagentAndImportedDsas(prefixArgs, ldapClient, environmentName, newDxagent, managedDsas, allDsasWithDxagents, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;
  var processingErrors = [];

  function iterateDsas(dxagentCreated, index) {
    if (index === managedDsas.length) {
      // no more DSA to store
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished storing DSAs in directory');
      return process.nextTick(function(){callback(processingErrors, dxagentCreated);});
    }

    var currentDsa = managedDsas[index];
    var existingUnmanagedDsa;

    if (currentDsa[EXISTING_UNMANAGED_DSA]) {
      existingUnmanagedDsa = currentDsa[EXISTING_UNMANAGED_DSA];
      delete currentDsa[EXISTING_UNMANAGED_DSA];
    }
    delete currentDsa[KNOWLEDGE_ABOUT_SELF];

    logger.info(utils.i18nTranslate(prefixArgs) + ': storing DSA "' + currentDsa.name + '" to directory');

    // store the DSA object
    ldapClient.createDsa(dxagentCreated.name, environmentName, currentDsa, function(err) {
      if (err) {
        // log error, but continue
        logger.error(utils.i18nTranslate(prefixArgs) + ': failed to store DSA "' + currentDsa.name + '" in directory, error is "' + err + '"');
        // save the error in the processing error list
        processingErrors.push(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.failedToStoreDsa', currentDsa.name, dxagentCreated.name]));
        // go to the next one
        iterateDsas(dxagentCreated, index + 1);
      } else {
        logger.info(utils.i18nTranslate(prefixArgs) + ': successfully stored DSA "' + currentDsa.name + '" for dxagent "' + dxagentCreated.name + '" in directory');

        // check to see if there is an unmanaged DSA to be deleted
        if (existingUnmanagedDsa) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': need to delete unmanaged DSA "' + existingUnmanagedDsa.name + '"');

          // delete the unmanaged  DSA
          ldapClient.deleteUnmanagedDsa(existingUnmanagedDsa.name, environmentName, function(err) {
            if (err) {
              // log error, but continue
              logger.error(utils.i18nTranslate(prefixArgs) + ': failed to delete unmanaged DSA "' + existingUnmanagedDsa.name + '" from directory, error is "' + err + '"');
              processingErrors.push(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.failedToDeleteUnmanagedDsa', existingUnmanagedDsa.name, environmentName]));
              // go to the next one
              iterateDsas(dxagentCreated, index + 1);
            } else {
              logger.info(utils.i18nTranslate(prefixArgs) + ': successfully deleted unmanaged DSA "' + existingUnmanagedDsa.name + '" from directory');

              // update dsaPeers property of DSAs that reference the deleted unmanaged DSA
              updateDsaPeersOfAffectedDsas(prefixArgs, ldapClient, environmentName, newDxagent.name, existingUnmanagedDsa.name, 'deletion', allDsasWithDxagents, function(errs) {
                if (errs) {
                  processingErrors = processingErrors.concat(errs);
                }
                // go to the next one
                iterateDsas(dxagentCreated, index + 1);
              });
            }
          });
        } else {
          // go to the next one
          iterateDsas(dxagentCreated, index + 1);
        }
      }
    });
  }

  logger.info(utils.i18nTranslate(prefixArgs) + ': storing the dxagent object in directory');

  ldapClient.createDxagent(environmentName, newDxagent, function(err, dxagentCreated) {
    if (err) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed to store the dxagent object in directory, error is ' + err + '"');
      return process.nextTick(function(){callback(err);});
    }

    logger.info(utils.i18nTranslate(prefixArgs) + ': successfully stored the dxagent object in directory');

    if (managedDsas && managedDsas.length > 0) {
      // start from the first one
      iterateDsas(dxagentCreated, 0);
    } else {
      // no DSA to store
      logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA to store in directory');
      return process.nextTick(function(){callback(null, dxagentCreated);});
    }
  });
}

/**
 * Check the DSAs in the environment to see if any one of them is affected by the deletion/creation of the unmanaged DSA.
 * If it is, then update the dsaPeers property of it.
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param dxagentNameInvolved
 * @param unmanagedDsaName
 * @param action - has to be either 'deletion' or 'creation'
 * @param allDsasWithDxagents
 * @param callback(processingErrors)
 */
function updateDsaPeersOfAffectedDsas(prefixArgs, ldapClient, environmentName, dxagentNameInvolved, unmanagedDsaName, action, allDsasWithDxagents, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  assert(action === 'creation' || action === 'deletion');

  logger.info(utils.i18nTranslate(prefixArgs) + ': checking DSAs that are affected by the ' + action + ' of unmanaged DSA "' + unmanagedDsaName + '" in environment "' + environmentName + '"' );

  var processingErrors = [];
  var dsasAffected = [];

  // get the list of affected DSAs first
  allDsasWithDxagents.forEach(function(oneDxagent) {
    if (oneDxagent[DSAS_ARRAY] && Array.isArray(oneDxagent[DSAS_ARRAY])) {
      oneDxagent[DSAS_ARRAY].forEach(function(oneDsa) {

        if (!(oneDsa.globalKnowledge) && oneDsa.dsaPeers && Array.isArray(oneDsa.dsaPeers)) {
          oneDsa.dsaPeers.find(function(oneDsaPeersEntry) {

            if (action === 'deletion') {
              // unmanaged DSA being deleted case, dxagentNameInvolved contains the name of the dxagent to which the unmanaged DSA has been moved to
              if (oneDsaPeersEntry && (!oneDsaPeersEntry.dxagent || oneDsaPeersEntry.dxagent === '') && (oneDsaPeersEntry.dsa && oneDsaPeersEntry.dsa.toUpperCase() === unmanagedDsaName.toUpperCase())) {
                logger.info(utils.i18nTranslate(prefixArgs) + ': found DSA "' + oneDsa.name + '" on dxagent "' + oneDxagent.name + '" affected by the deletion of unmanaged DSA "' + unmanagedDsaName + '"');
                oneDsaPeersEntry.dxagent = dxagentNameInvolved;
                dsasAffected.push({dsa: oneDsa, dxagentName: oneDxagent.name});
                return true;
              }
            }

            if (action === 'creation') {
              // the case where an unmanaged DSA has been created, dxagentNameInvolved is the name of the dxagent on which the unmanaged DSA was on previously
              if (oneDsaPeersEntry && oneDsaPeersEntry.dxagent && oneDsaPeersEntry.dxagent === dxagentNameInvolved && oneDsaPeersEntry.dsa && oneDsaPeersEntry.dsa.toUpperCase() === unmanagedDsaName.toUpperCase()) {
                logger.info(utils.i18nTranslate(prefixArgs) + ': found DSA "' + oneDsa.name + '" on dxagent "' + oneDxagent.name + '" affected by the creation of unmanaged DSA "' + unmanagedDsaName + '"');
                delete oneDsaPeersEntry.dxagent;
                dsasAffected.push({dsa: oneDsa, dxagentName: oneDxagent.name});
                return true;
              }
            }

            return false;

          });
        }
      });
    }
  });

  function updateDsaPeersForAffectedDsas(index) {
    if (index === dsasAffected.length) {
      // no more DSA to update
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished updating dsaPeers property of DSAs affected by the ' + action + ' of unmanaged DSA "' + unmanagedDsaName + '" in environment "' + environmentName + '"');
      return process.nextTick(function(){callback(processingErrors);});
    }
    // update one DSA
    var currentDsa = dsasAffected[index];
    ldapClient.updateDsaPeersAttribute(currentDsa.dsa.name, currentDsa.dxagentName, environmentName, currentDsa.dsa.dsaPeers, function(err) {
      if (err) {
        // log error, but continue
        logger.error(utils.i18nTranslate(prefixArgs) + ': failed to update the dsaPeers property of DSA "' + currentDsa.dsa.name + '" in directory, error is "' + err + '"');
        // save the error in the processing error list
        processingErrors.push(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.failedToUpdateDsaPeersOfDsa', currentDsa.dsa.name, currentDsa.dxagentName, environmentName]));
      } else {
        logger.info(utils.i18nTranslate(prefixArgs) + ': successfully updated dsaPeers property for DSA "' + currentDsa.dsa.name + '" in directory');
      }

      // go to the next one
      updateDsaPeersForAffectedDsas(index + 1);
    });
  }

  // if we have found some
  if (dsasAffected.length > 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': there are DSAs affected by the ' + action + ' of unmanaged DSA "' + unmanagedDsaName + '" in environment "' + environmentName + '"');
    updateDsaPeersForAffectedDsas(0);
  } else {
    logger.info(utils.i18nTranslate(prefixArgs) + ': there is no DSA affected by the ' + action + ' of unmanaged DSA "' + unmanagedDsaName + '" in environment "' + environmentName + '"');
    return process.nextTick(function(){callback(processingErrors);});
  }
}

/**
 * Create one unmanaged DSA for each knowledge item in the list
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param knowledgeWithoutExistingDsa - list of knowledges
 * @param callback(processingErrors)
 */
function createUnmanagedDsasFromKnowledgeList(prefixArgs, ldapClient, environmentName, knowledgeWithoutExistingDsa, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;
  var processingErrors = [];

  if (!knowledgeWithoutExistingDsa || !(Array.isArray(knowledgeWithoutExistingDsa)) || knowledgeWithoutExistingDsa.length === 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': there is no unmanaged DSA to be created');
    return process.nextTick(function(){callback(processingErrors);});
  }

  // define a function to create the unmanaged DSAs
  function createOneUnmanagedDsa(index) {
    if (index === knowledgeWithoutExistingDsa.length) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished creating unmanaged DSAs');
      return process.nextTick(function(){callback(processingErrors);});
    }

    var currentKnowledge = knowledgeWithoutExistingDsa[index];
    if (!currentKnowledge || !currentKnowledge.name) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.invalidKnowledgeSetting'));
      processingErrors.push(utils.createLocalizedAPIError(locale, prefixArgs, 'errors.invalidKnowledgeSetting'));
      // go to the next one
      return createOneUnmanagedDsa(index + 1);
    }

    logger.info(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSA "' + currentKnowledge.name + '"');

    // validate the knowledge setting first
    var currentUnmanagedDsa = {name: currentKnowledge.name, config: currentKnowledge, unmanagedDsaCreatedBy: UNMANAGED_DSA_AUTO_CREATED};
    utils.determineUnmanagedDsaType(currentUnmanagedDsa);
    utils.validateUnmanagedDsaConfig(prefixArgs, logger, locale, currentUnmanagedDsa, function(err) {
      if (err) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSA "' + currentKnowledge.name + '" - schema validation failed');
        processingErrors.push(err);
        // go to the next one
        return createOneUnmanagedDsa(index + 1);
      } else {
        // go ahead creating the unmanaged DSA
        ldapClient.createUnmanagedDsa(environmentName, currentUnmanagedDsa, function(err, unmanagedDsaCreated) {
          if (err) {
            processingErrors.push(err);
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSA "' + currentKnowledge.name + '" - successfully created');
          }
          // go to the next one
          return createOneUnmanagedDsa(index + 1);
        });
      }
    });
  }

  // start the creation
  createOneUnmanagedDsa(0);
}

/**
 * Delete unmanaged DSA if it meets the following conditions:
 *
 * 1) not a global knowledge unmanaged DSA
 * 2) created by dxagent
 * 3) not referenced by any managed DSA
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param unmanagedDsaList - list of unmanaged DSA to check
 * @param allDsasWithDxagents - all managed DSAs with dxagent in the environment
 * @param callback(processingErrors)
 */
function deleteUnmanagedDsas(prefixArgs, ldapClient, environmentName, unmanagedDsaList, allDsasWithDxagents, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;
  var processingErrors = [];

  if (!unmanagedDsaList || !(Array.isArray(unmanagedDsaList)) || unmanagedDsaList.length === 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': there is no unmanaged DSA to be deleted in the environment "' + environmentName + '"');
    return process.nextTick(function(){callback();});
  }

  logger.info(utils.i18nTranslate(prefixArgs) + ': checking/deleting unmanaged DSAs in the environment "' + environmentName + '"');

  // define a function to check/delete the unmanaged DSAs
  function checkDeleteOneUnmanagedDsa(index) {
    if (index === unmanagedDsaList.length) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished checking/deleting unmanaged DSAs in the environment "' + environmentName + '"');
      return process.nextTick(function(){callback(processingErrors);});
    }

    var currentUnmanagedDsa = unmanagedDsaList[index];
    var affectedDxagentIndex = -1;

    // if it is global knowledge, go the next one
    if (currentUnmanagedDsa.globalKnowledge) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': unmanaged DSA "' + currentUnmanagedDsa.name + '" is global knowledge unmanaged DSA, skip deletion');
      return checkDeleteOneUnmanagedDsa(index + 1);
    }

    // if it is not created by dxagent, go to the next one
    if (!currentUnmanagedDsa.unmanagedDsaCreatedBy || currentUnmanagedDsa.unmanagedDsaCreatedBy !== UNMANAGED_DSA_AUTO_CREATED) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': unmanaged DSA "' + currentUnmanagedDsa.name + '" is not created by dxagent, skip deletion');
      return checkDeleteOneUnmanagedDsa(index + 1);
    } 

    // check to see if it is in the knowledge list of at least one other DSA
    affectedDxagentIndex = allDsasWithDxagents.findIndex(function(oneDxagent) {
      var affectedDsaIndex = -1;
      // if the dxagent has DSAs
      if (oneDxagent[DSAS_ARRAY] && Array.isArray(oneDxagent[DSAS_ARRAY]) && oneDxagent[DSAS_ARRAY].length > 0) {
        // go through the list of DSAs
        affectedDsaIndex = oneDxagent[DSAS_ARRAY].findIndex(function(oneDsa) {
          if (oneDsa && oneDsa.config && oneDsa.config.knowledge && (findMatchingKnowledgeIndex(prefixArgs, logger, currentUnmanagedDsa.config, oneDsa.config.knowledge) !== -1)) {
            return true;
          }
        });

        if (affectedDsaIndex !== -1) {
          return true;
        }
      }
    });

    // if it is still referenced by other DSAs, go to the next one
    if (affectedDxagentIndex !== -1) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': unmanaged DSA "' + currentUnmanagedDsa.name + '" is still referenced by other DSAs, skip deletion');
      return checkDeleteOneUnmanagedDsa(index + 1);
    }

    logger.info(utils.i18nTranslate(prefixArgs) + ': deleting unmanaged DSA "' + currentUnmanagedDsa.name + '"');

    // go ahead deleting the unmanaged DSA
    ldapClient.deleteUnmanagedDsa(currentUnmanagedDsa.name, environmentName, function(err) {
      if (err) {
        processingErrors.push(err);
      } else {
        logger.info(utils.i18nTranslate(prefixArgs) + ': deleting unmanaged DSA "' + currentUnmanagedDsa.name + '" - successfully deleted');
      }
      // go to the next one
      return checkDeleteOneUnmanagedDsa(index + 1);
    });
  }

  // start the iteration
  checkDeleteOneUnmanagedDsa(0);
}

/**
 * Create unmanaged DSA that are in the unmanaged DSA list and update the DSAs that are affected
 *
 * @param prefixArgs
 * @param ldapClient
 * @param dxagentName
 * @param environmentName
 * @param unmanagedDsaList - list of unmanaged DSA
 * @param allDsasWithDxagents - all managed DSAs with dxagent in the environment
 * @param callback(processingErrors)
 */
function createUnmanagedDsasAndUpdateAffectedDsas(prefixArgs, ldapClient, dxagentName, environmentName, unmanagedDsaList, allDsasWithDxagents, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;
  var processingErrors = [];

  if (!unmanagedDsaList || !(Array.isArray(unmanagedDsaList)) || unmanagedDsaList.length === 0) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': there is no unmanaged DSA to be created');
    return process.nextTick(function(){callback();});
  }

  logger.info(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSAs and updating affected managed DSAs');

  // define a function to create the unmanaged DSAs and update affected managed DSAs
  function createOneUnmanagedDsa(index) {
    if (index === unmanagedDsaList.length) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': finished creating unmanaged DSAs and updating affected managed DSAs');
      return process.nextTick(function(){callback(processingErrors);});
    }

    var currentUnmanagedDsa = unmanagedDsaList[index];
    var affectedDxagentIndex = -1;

    // we need to check whether we want to create the unmanaged DSA or not
    // only create the unmanaged DSA if it is globalKnowledge or when it is in the knowledge list of at least one other DSA
    if (!currentUnmanagedDsa.globalKnowledge) {
      affectedDxagentIndex = allDsasWithDxagents.findIndex(function(oneDxagent) {
        var affectedDsaIndex = -1;
        // if the dxagent has DSAs
        if (oneDxagent[DSAS_ARRAY] && Array.isArray(oneDxagent[DSAS_ARRAY]) && oneDxagent[DSAS_ARRAY].length > 0) {
          // go through the list of DSAs
          affectedDsaIndex = oneDxagent[DSAS_ARRAY].findIndex(function(oneDsa) {
            if (oneDsa && oneDsa.config && oneDsa.config.knowledge && (findMatchingKnowledgeIndex(prefixArgs, logger, currentUnmanagedDsa.config, oneDsa.config.knowledge) !== -1)) {
              return true;
            }
          });

          if (affectedDsaIndex !== -1) {
            return true;
          }
        }
      });
    }

    if (!currentUnmanagedDsa.globalKnowledge && affectedDxagentIndex === -1) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': DSA "' + currentUnmanagedDsa.name + '" is not a global knowledge DSA and is not included in the knowledge list of any of the other DSAs. No need to create unmanaged DSA for it');
      // go to the next one
      return createOneUnmanagedDsa(index + 1);
    }

    logger.info(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSA "' + currentUnmanagedDsa.name + '"');

    // validate the knowledge setting first
    utils.validateUnmanagedDsaConfig(prefixArgs, logger, locale, currentUnmanagedDsa, function(err) {
      if (err) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSA "' + currentUnmanagedDsa.name + '" - schema validation failed');
        processingErrors.push(err);
        // go to the next one
        return createOneUnmanagedDsa(index + 1);
      } else {
        // go ahead creating the unmanaged DSA
        ldapClient.createUnmanagedDsa(environmentName, currentUnmanagedDsa, function(err, unmanagedDsaCreated) {
          if (err) {
            processingErrors.push(err);
            // go to the next one
            return createOneUnmanagedDsa(index + 1);
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': creating unmanaged DSA "' + currentUnmanagedDsa.name + '" - successfully created');
            // update the affected managed DSAs now
            updateDsaPeersOfAffectedDsas(prefixArgs, ldapClient, environmentName, dxagentName, currentUnmanagedDsa.name, 'creation', allDsasWithDxagents, function(err) {
              if (err) {
                processingErrors = processingErrors.concat(err);
              }
              // go to the next one
              return createOneUnmanagedDsa(index + 1);
            });
          }
        });
      }
    });
  }

  // start the creation
  createOneUnmanagedDsa(0);
}

/**
 * Build the complete knowledge list for the named environment
 *
 * @param prefixArgs
 * @param ldapClient
 * @param environmentName
 * @param callback(err, allDsaKnowledgeWithDxagents)
 */
function getCompleteKnowledgeList(prefixArgs, ldapClient, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  //get all the existing DSAs on all existing dxagent hosts first
  getAllDSAsInEnvironment(prefixArgs, ldapClient, environmentName, function(err, allDsaKnowledgeWithDxagents) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }

    // get the list of unmanaged DSAs as well
    ldapClient.listUnmanagedDsas(environmentName, function(err, unmanagedDsas) {
      if (err) {
        return process.nextTick(function(){callback(err);});
      }

      // go through the list of DSAs and find self knowledge for each of them.
      allDsaKnowledgeWithDxagents.forEach(function(oneDxagent) {
        var selfKnowledgeArray = [];
        if (oneDxagent[DSAS_ARRAY] && Array.isArray(oneDxagent[DSAS_ARRAY])) {
          oneDxagent[DSAS_ARRAY].forEach(function(oneDsa) {
            var selfKnowledge = utils.getKnowledgeAboutSelf(oneDsa);
            if (selfKnowledge) {
              selfKnowledgeArray.push(selfKnowledge);
            } else {
              logger.warn(utils.i18nTranslate(prefixArgs) + ': DSA "' + oneDsa.name + '" does not have knowledge setting for itself');
            }
          });
        }
        oneDxagent[SELF_KNOWLEDGE_ARRAY] = selfKnowledgeArray;
      });

      // build the knowledge list for unmanaged DSAs
      var unmanagedDsaKnowledgeList = [];
      unmanagedDsas.forEach(function(oneUnmanagedDsa) {
        if (oneUnmanagedDsa.config) {
          unmanagedDsaKnowledgeList.push(oneUnmanagedDsa.config);
        }
      });

      // add the unmanaged DSA array
      var placeHolderForUnmanagedDsas = {};
      placeHolderForUnmanagedDsas[SELF_KNOWLEDGE_ARRAY] = unmanagedDsaKnowledgeList;
      allDsaKnowledgeWithDxagents.push(placeHolderForUnmanagedDsas);

      return process.nextTick(function(){callback(null, allDsaKnowledgeWithDxagents);});
    });
  });
}

/**
 * Calculate dsaPeers value for the DSA object and save it in directory
 *
 * @param prefixArgs
 * @param ldapClient
 * @param dsaObject
 * @param dxagentName
 * @param environmentName
 * @param allDsaKnowledgeWithDxagents
 * @param callback(err, dsaObject)
 */
function calculateAndSaveDsaPeers(prefixArgs, ldapClient, dsaObject, dxagentName, environmentName, allDsaKnowledgeWithDxagents, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  logger.info(utils.i18nTranslate(prefixArgs) + ': calculate and save dsaPeers attribute for DSA "' + dsaObject.name + '"');

  var dsaPeers = [];

  // now go through the list of DSA knowledge and build the dsaPeers value
  dsaObject.config.knowledge.forEach(function(oneKnowledge) {
    if (oneKnowledge.name && dsaObject.name && oneKnowledge.name.toUpperCase() === dsaObject.name.toUpperCase()) {
      // self knowledge
      logger.debug(utils.i18nTranslate(prefixArgs) + ': found self knowledge for DSA "' + dsaObject.name + '"');
    } else {
      // if this knowledge is not about self, try match the knowledge item
      allDsaKnowledgeWithDxagents.find(function(oneDxagent) {
        if (oneDxagent[SELF_KNOWLEDGE_ARRAY] && Array.isArray(oneDxagent[SELF_KNOWLEDGE_ARRAY])) {
          var match = findMatchingKnowledgeItem(prefixArgs, logger, oneKnowledge, oneDxagent[SELF_KNOWLEDGE_ARRAY]); 
          if (match) {
            // found
            if (match.name) {
              if (oneDxagent.name) {
                dsaPeers.push({dsa: match.name, dxagent: oneDxagent.name});
              } else {
                dsaPeers.push({dsa: match.name});
              }
            }
            return true;
          }
        }
      });
    }
  });

  // save the dsaPeers value
  dsaObject.dsaPeers = dsaPeers;
  ldapClient.updateDsaPeersAttribute(dsaObject.name, dxagentName, environmentName, dsaPeers, function(err) {
    if (err) {
      logger.warn(utils.i18nTranslate(prefixArgs) + ': calculate and save dsaPeers attribute for DSA "' + dsaObject.name + '" - failed to save with error');
    } else {
      logger.info(utils.i18nTranslate(prefixArgs) + ': successfully calculated and saved dsaPeers attribute for DSA "' + dsaObject.name + '"');
    }

    return process.nextTick(function(){callback(null, dsaObject);});
  });
}

/**
 * Determine if we need to calculate dsaPeers property for the DSA object
 *
 * @param prefixArgs
 * @param logger
 * @param dsaObject
 * @returns {Boolean}
 */
function needToCalculateDsaPeers(prefixArgs, logger, dsaObject) {

  if (dsaObject.dsaPeers || dsaObject.globalKnowledge || !(dsaObject.config) || !(dsaObject.config.knowledge) && !(Array.isArray(dsaObject.config.knowledge))) {
    // no need when there is a value or for global knowledge DSA
    return false;
  }

  if (dsaObject.config.knowledge.length === 1 || dsaObject.config.knowledge.length === 0) {
    // no need for DSA that only has self knowledge
    return false;
  }

  //we need to calculate
  logger.info(utils.i18nTranslate(prefixArgs) + ': need to calculate dsaPeers value for DSA "' + dsaObject.name + '"');
  return true;
}

/**
 * Get the named DSA on the named dxagent in the named environment. When dsaPeers property is absent and it is
 * not a global knowledge DSA, calculate the value of it and save it back to directory
 *
 * @param prefixArgs
 * @param ldapClient
 * @param dsaName
 * @param dxagentName
 * @param environmentName
 * @param callback(err, dsaRetrieved)
 */
function getDsa(prefixArgs, ldapClient, dsaName, dxagentName, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  //get the dsa object from the directory first
  ldapClient.getDsa(dsaName, dxagentName, environmentName, function(err, dsaRetrieved) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }

    if (!needToCalculateDsaPeers(prefixArgs, logger, dsaRetrieved)) {
      return process.nextTick(function(){callback(null, dsaRetrieved);});
    }

    // get complete knowledge for the environment first
    getCompleteKnowledgeList(prefixArgs, ldapClient, environmentName, function(err, allDsaKnowledgeWithDxagents) {
      if (err) {
        return process.nextTick(function(){callback(err);});
      }

      calculateAndSaveDsaPeers(prefixArgs, ldapClient, dsaRetrieved, dxagentName, environmentName, allDsaKnowledgeWithDxagents, function(err) {
        return process.nextTick(function(){callback(null, dsaRetrieved);});
      });
    });
  });
}

/**
 * Get the list of all DSAs on the named dxagent in the named environment. When dsaPeers property is absent and it is
 * not a global knowledge DSA, calculate the value of it and save it back to directory
 *
 * @param prefixArgs
 * @param ldapClient
 * @param dxagentName
 * @param environmentName
 * @param callback(err, dsaList)
 */
function listDsas(prefixArgs, ldapClient, dxagentName, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  //get the dsas from the directory first
  ldapClient.listDsas(dxagentName, environmentName, function(err, dsaList) {
    if (err) {
      return process.nextTick(function(){callback(err);});
    }

    // check to see if any of them needs to have dsaPeers value calculated
    if (!dsaList.find(function(oneDsa) {
      if (needToCalculateDsaPeers(prefixArgs, logger, oneDsa)) {
        return true;
      }
    })) {
      return process.nextTick(function(){callback(err, dsaList);});
    }

    // need to calculate, get complete knowledge for the environment first
    getCompleteKnowledgeList(prefixArgs, ldapClient, environmentName, function(err, allDsaKnowledgeWithDxagents) {
      if (err) {
        return process.nextTick(function(){callback(err);});
      }

      function calculateAndSaveDsaPeersForOneDsa(index) {
        if (index === dsaList.length) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': finished calculating dsaPeers value for DSAs on dxagent "' + dxagentName + '"');
          return process.nextTick(function(){callback(err, dsaList);});
        }

        var currentDsa = dsaList[index];
        if (needToCalculateDsaPeers(prefixArgs, logger, currentDsa)) {
          calculateAndSaveDsaPeers(prefixArgs, ldapClient, currentDsa, dxagentName, environmentName, allDsaKnowledgeWithDxagents, function(err) {
            // go to the next one
            calculateAndSaveDsaPeersForOneDsa(index + 1);
          });
        } else {
          // go to the next one
          calculateAndSaveDsaPeersForOneDsa(index + 1);
        }
      }

      calculateAndSaveDsaPeersForOneDsa(0);
    });
  });
}

/**
 * List all dxagents in a environment
 */
dxagentController.list = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.listDxagents', req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvName', 400));
  }

  var attributes;
  // required attributes
  if (req.query && req.query.attributes) {
    attributes = req.query.attributes.split(',');
    if (attributes.indexOf('name') === -1) {
      // 'name' doesn't exist in attributes
      req.query.attributes += ',name';
    }
  }

  /**
   * Define a function to retrieve installationInfo for all the dxagents
   *
   * @param dxagents
   * @param dxagentOperations
   * @param callback
   */
  function getInstallationInfoForDxagents(dxagents, dxagentOperations, callback) {

    /**
     * Define a function to retrieve installationInfo for one dxagent
     *
     * @param dxagentIndex
     * @param callback
     */
    function getInstallationInfoForDxagent(dxagentIndex, callback) {
      if (dxagentIndex === dxagents.length) {
        // no more dxagent
        logger.info(utils.i18nTranslate(prefixArgs) + ': finished retrieving installation information for all dxagents');
        return process.nextTick(function(){callback();});
      }

      // get the dxagent at the current index
      var currentDxagent = dxagents[dxagentIndex];

      // get the installation information for this dxagent
      dxagentOperations.getInstallationInfo(currentDxagent, function(err, info) {
        if (err) {
          return process.nextTick(function(){callback(err);});
        } else {
          currentDxagent.installationInfo = info;
          // go to the next dxagent
          getInstallationInfoForDxagent(dxagentIndex + 1, callback);
        }
      });
    }
    // kick off the retrieving here
    getInstallationInfoForDxagent(0, callback);
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // call into LDAP server to get the list
    ldapClient.listDxagents(req.params.environmentName, function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      }

      // check to see if installationInfo is requested
      if (!attributes || (Array.isArray(attributes) && attributes.length > 0 && attributes.indexOf('installationInfo') != -1)) {
        var dxagentOperations = dxagentOps.getDxagentOperations(logger, req.getLocale());
        getInstallationInfoForDxagents(results, dxagentOperations, function(err) {
          if (err) {
            return utils.sendErrorResponse(res, err);
          }
          // done
          for (var i = 0; i < results.length; i++) {
            utils.removeAttributesNotRequested(results[i], dxagentAttributeList, attributes);
          }
          utils.sendJsonResponse(res, 200, results);
        });
      } else {
        for (var i = 0; i < results.length; i++) {
          utils.removeAttributesNotRequested(results[i], dxagentAttributeList, attributes);
        }
        utils.sendJsonResponse(res, 200, results);
      }
    });
  });
};

/**
 * Get named dxagent in the named environment
 */
dxagentController.get = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.getDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName || !req.params.dxagentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  var attributes;
  // required attributes
  if (req.query && req.query.attributes) {
    attributes = req.query.attributes.split(',');
    if (attributes.indexOf('name') === -1) {
      // 'name' doesn't exist in attributes
      req.query.attributes += ',name';
    }
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    //call into LDAP server to get the dxagent
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, result) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      }

      // check to see if installationInfo is requested
      if (!attributes || (Array.isArray(attributes) && attributes.length > 0 && attributes.indexOf('installationInfo') != -1)) {
        var dxagentOperations = dxagentOps.getDxagentOperations(logger, req.getLocale());
        dxagentOperations.getInstallationInfo(result, function(err, info) {
          if (err) {
            return utils.sendErrorResponse(res, err);
          }
          result.installationInfo = info;
          utils.removeAttributesNotRequested(result, dxagentAttributeList, attributes);
          utils.sendJsonResponse(res, 200, result);
        });
      } else {
        utils.removeAttributesNotRequested(result, dxagentAttributeList, attributes);
        utils.sendJsonResponse(res, 200, result);
      }
    });
  });
};

/**
 * Create a new dxagent in the named environment
 */
dxagentController.create = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.createDxagent', req.body.name, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));
  // check there is a request body
  if (!req.body) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }
  // check there is an environment name
  if (!req.params || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvName', 400));
  }
  // check the required attributes
  var missingAttrs = checkRequiredAttributes(req.body, utils.managementUiLdapConfig.uiDxagentRequiredAttributes);
  if (missingAttrs.length > 0) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    /**
     * Use async library to execute the tasks sequentially
     */
    var dsasFromDxagent;
    var unmanagedDsas;
    var allDsasWithDxagents;
    var knowledgeWithoutExistingDsa;
    var dxagentCreated;

    async.series([
      // check that the environment exists
      function (callback) {
        ldapClient.getEnvironment(req.params.environmentName, function(err) {
          if (err) {
            // error means that it does not exist or some other error condition with directory, abort
            // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
            logger.info(utils.i18nTranslate(prefixArgs) + ': environment "' + req.params.environmentName + '" does not exists');
            return process.nextTick(function () {callback(err);});
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': environment "' + req.params.environmentName + '" exists');
            return process.nextTick(function () {callback();});
          }
        });
      },
      // check that we don't have a dxagent with the same name exist
      function (callback) {
        ldapClient.getDxagent(req.body.name, req.params.environmentName, function(err) {
          // no error means it does exist
          if (!err) {
            logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.dxagentNameConflict', req.body.name]));
            var localizedError = utils.createLocalizedAPIError(req.getLocale(), prefixArgs, ['errors.dxagentNameConflict', req.body.name], 409);
            return process.nextTick(function () {callback(localizedError);});
          }
          // if there is an error and statusCode is not 404, then it means something else is wrong
          if (err && err.statusCode !== 404) {
            return process.nextTick(function () {callback(err);});
          }
          // if we reach here, dxagent with the same name does not exist
          logger.info(utils.i18nTranslate(prefixArgs) + ': confirmed that a dxagent with the same name does not exist');
          return process.nextTick(function () {callback();});
        });
      },
      // check existing dxagents don't have the same host and port combination
      function (callback) {
        ldapClient.listDxagents(req.params.environmentName, function(err, existingDxagents) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // we have the list now, check the host name and port number
          if (checkHostnameAndPort(req.body, existingDxagents)) {
            logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.hostPortConflict'));
            var localizedError = utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.hostPortConflict', 400);
            return process.nextTick(function () {callback(localizedError);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': confirmed that a dxagent with the same host name and port number combination does not exist');
          return process.nextTick(function () {callback();});
        });
      },
      // get the installation information
      function (callback) {
        dxagentOps.getDxagentOperations(logger, req.getLocale()).getInstallationInfo(req.body, function(err, info) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved directory installation information');
          // we have the installation information now
          req.body.installationInfo = info;
          return process.nextTick(function () {callback();});
        });
      },
      // get the list of all existing DSAs on the dxagent
      function (callback) {
        dxagentOps.getDxagentOperations(logger, req.getLocale()).getAllDsas(req.body, function(err, dsas) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved the list of existing DSAs');
          dsasFromDxagent = dsas;
          return process.nextTick(function () {callback();});
        });
      },
      // get DSA json schema
      function (callback) {
        retrieveDsaSchemas(prefixArgs, logger, req.body, function(err, data) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // we have the DSA json schema now
          if (data) {
            req.body.dsaJsonSchema = data;
          }
          return process.nextTick(function () {callback();});
        });
      },
      // try to find the matching unmanaged DSAs already in the environment for the DSAs being imported
      function (callback) {
        findMatchingUnmanagedDsasForDsas(prefixArgs, ldapClient, req.params.environmentName, dsasFromDxagent, function(err, uDsas) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          unmanagedDsas = uDsas;
          return process.nextTick(function () {callback();});
        });
      },
      // check the knowledge settings of the DSAs being imported
      function (callback) {
        checkKnowldgeSettingsOfDsas(prefixArgs, ldapClient, req.params.environmentName, req.body, dsasFromDxagent, unmanagedDsas, function(err, dsasWithDxagents, kWithoutExistingDsa) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          allDsasWithDxagents = dsasWithDxagents;
          knowledgeWithoutExistingDsa = kWithoutExistingDsa;
          return process.nextTick(function () {callback();});
        });
      },
      // save the dxagent object and DSAs being imported to directory, create unmanaged DSAs as well
      function (callback) {
        saveDxagentAndImportedDsas(prefixArgs, ldapClient, req.params.environmentName, req.body, dsasFromDxagent, allDsasWithDxagents, function(err, dCreated) {
          if (err && !Array.isArray(err)) {
            // a single error indicates that the creation of dxagent in directory failed, so bail out
            return process.nextTick(function () {callback(err);});
          }

          var processingErrors = [];
          if (err && Array.isArray(err) && err.length > 0) {
            processingErrors = processingErrors.concat(err);
          }

          // create the unmanaged DSAs now
          createUnmanagedDsasFromKnowledgeList(prefixArgs, ldapClient, req.params.environmentName, knowledgeWithoutExistingDsa, function(err) {
            if (err) {
              processingErrors = processingErrors.concat(err);
            }
            // partial success
            if (processingErrors.length > 0) {
              return process.nextTick(function () {callback(processingErrors);});
            }
            // no error
            dxagentCreated = dCreated;
            return process.nextTick(function () {callback();});
          });
        });
      }
    ],
    // callback functin that will be called if any function returns an error, or when all functions succeeded, called with an array of results 
    function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 201, dxagentCreated);
      }
    });
  });
};

/**
 * Update a dxagent, HTTP PUT means replace the object
 */
dxagentController.update = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.updateDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));
  // check there is a request body
  if (!req.body) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }
  // check there is a dxagent name and an environment name
  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }
  req.body.name = req.params.dxagentName;
  // check the required attributes
  var missingAttrs = checkRequiredAttributes(req.body, utils.managementUiLdapConfig.uiDxagentRequiredAttributes);
  if (missingAttrs.length > 0) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    /**
     * Use async library to execute the tasks sequentially
     */
    var dxagentUpdated;

    async.series([
      // check that the environment exists
      function (callback) {
        ldapClient.getEnvironment(req.params.environmentName, function(err) {
          if (err) {
            // error means that it does not exist or some other error condition with directory, abort
            // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
            logger.info(utils.i18nTranslate(prefixArgs) + ': environment "' + req.params.environmentName + '" does not exists');
            return process.nextTick(function () {callback(err);});
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': environment "' + req.params.environmentName + '" exists');
            return process.nextTick(function () {callback();});
          }
        });
      },
      // check that we have the dxagent
      function (callback) {
        ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // dxagent exists
          logger.info(utils.i18nTranslate(prefixArgs) + ': dxagent exists');
          // set the host name and port number using existing dxagent so that they won't get changed
          req.body.host = currentDxagent.host;
          req.body.port = currentDxagent.port;
          return process.nextTick(function () {callback();});
        });
      },
      // get the installation information
      function (callback) {
        dxagentOps.getDxagentOperations(logger, req.getLocale()).getInstallationInfo(req.body, function(err, info) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved directory installation information');
          // we have the installation information now
          req.body.installationInfo = info;
          return process.nextTick(function () {callback();});
        });
      },
      // get DSA json schema
      function (callback) {
        retrieveDsaSchemas(prefixArgs, logger, req.body, function(err, data) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // we have the DSA json schema now
          if (data) {
            req.body.dsaJsonSchema = data;
          }
          return process.nextTick(function () {callback();});
        });
      },
      // update dxagent in directory
      function (callback) {
        ldapClient.updateDxagent(req.params.dxagentName, req.params.environmentName, req.body, function(err, dUpdated) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': dxagent updated');
          dxagentUpdated = dUpdated;
          return process.nextTick(function () {callback();});
        });
      }
    ],
    // callback functin that will be called if any function returns an error, or when all functions succeeded, called with an array of results 
    function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 200, dxagentUpdated);
      }
    });
  });
};

/**
 * Delete the named dxagent from the named environment
 */
dxagentController.delete = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.deleteDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName || !req.params.dxagentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    /**
     * Use async library to execute the tasks sequentially
     */
    var dsas;
    var unmanagedDsasToDelete;
    var unmanagedDsasToCreate = [];

    async.series([
      // check that we have the dxagent
      function (callback) {
        ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // dxagent exists
          logger.info(utils.i18nTranslate(prefixArgs) + ': dxagent exists');
          return process.nextTick(function () {callback();});
        });
      },
      // get the list of all DSAs on the dxagent being deleted
      function (callback) {
        ldapClient.listDsas(req.params.dxagentName, req.params.environmentName, function(err, dsaList) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          dsas = dsaList;
          return process.nextTick(function () {callback();});
        });
      },
      // get the list of unmanaged DSAs in the environment, they are the candidates for deletion
      function (callback) {
        ldapClient.listUnmanagedDsas(req.params.environmentName, function(err, udsaList) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }

          unmanagedDsasToDelete = udsaList;

          // create a list of unmanaged DSAs that need to be created
          dsas.forEach(function(oneDsa) {
            var selfKnowledge = utils.getKnowledgeAboutSelf(oneDsa);
            if (!selfKnowledge || !selfKnowledge.name) {
              logger.warn(utils.i18nTranslate(prefixArgs) + ': no knowledge or invalid knowledge about itself has been found for DSA "' + oneDsa.name + '"');
            } else {
              var oneUnmanagedDsa = {name: selfKnowledge.name, config: selfKnowledge, unmanagedDsaCreatedBy: UNMANAGED_DSA_AUTO_CREATED};
              utils.determineUnmanagedDsaType(oneUnmanagedDsa);
              if (oneDsa.globalKnowledge) {
                oneUnmanagedDsa.globalKnowledge = true;
              }
              unmanagedDsasToCreate.push(oneUnmanagedDsa);
            }
          });

          return process.nextTick(function () {callback();});
        });
      },
      // delete the alarms
      function (callback) {
        ldapClient.deleteAlarmsDxagent(req.params.dxagentName, req.params.environmentName, false, function (err) {
          if (!err) {
            // deleted
            logger.info(utils.i18nTranslate(prefixArgs) + ': alarm messages for the dxagent deleted successfully');
          }
        });
        // don't wait for the deletion to finish
        return process.nextTick(function () {callback();});
      },
      // delete the stats
      function (callback) {
        ldapClient.deleteStatsDxagent(req.params.dxagentName, req.params.environmentName, function (err) {
          if (!err) {
            // deleted
            logger.info(utils.i18nTranslate(prefixArgs) + ': stats messages for the dxagent deleted successfully');
          }
        });
        // don't wait for the deletion to finish
        return process.nextTick(function () {callback();});
      },
      function (callback) {
        if ((unmanagedDsasToCreate && unmanagedDsasToCreate.length > 0) || (unmanagedDsasToDelete && unmanagedDsasToDelete.length > 0)) {
          // get the list of all dxagent with DSAs in the environment first
          getAllDSAsInEnvironment(prefixArgs, ldapClient, req.params.environmentName, function(err, allDsasWithDxagents) {
            if (err) {
              return process.nextTick(function () {callback(err);});
            }

            logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved the list of all dxagent and their DSAs in environment "' + req.params.environmentName + '"');

            // remove from the list the dxagent that is being deleted
            var indexOfDxagentBeingDeleted = allDsasWithDxagents.findIndex(function(oneDxagent) {
              if (oneDxagent && oneDxagent.name && oneDxagent.name === req.params.dxagentName) {
                return true;
              }
              return false;
            });

            if (indexOfDxagentBeingDeleted !== -1) {
              allDsasWithDxagents.splice(indexOfDxagentBeingDeleted, 1);
            }

            logger.info(utils.i18nTranslate(prefixArgs) + ': deleting dxagent "' + req.params.dxagentName + '"');
            // we have the list of unmanaged DSAs to be created now, delete the dxagent first
            ldapClient.deleteDxagent(req.params.dxagentName, req.params.environmentName, function(err) {
              if (err) {
                return process.nextTick(function () {callback(err);});
              }

              logger.info(utils.i18nTranslate(prefixArgs) + ': deleting dxagent "' + req.params.dxagentName + '" - successfully deleted');
              var processingErrors = [];
              // try to create unmanaged DSAs and affected managed DSAs
              createUnmanagedDsasAndUpdateAffectedDsas(prefixArgs, ldapClient, req.params.dxagentName, req.params.environmentName, unmanagedDsasToCreate, allDsasWithDxagents, function(err) {
                if (err && err.length > 0) {
                  processingErrors = processingErrors.concat(err);
                }

                deleteUnmanagedDsas(prefixArgs, ldapClient, req.params.environmentName, unmanagedDsasToDelete, allDsasWithDxagents, function(err) {
                  if (err && err.length > 0) {
                    processingErrors = processingErrors.concat(err);
                  }
                  if (processingErrors.length > 0) {
                    return process.nextTick(function () {callback(processingErrors);});
                  }
                  return process.nextTick(function () {callback();});
                });
              });
            });
          });
        } else {
          logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA has been found on dxagent "' + req.params.dxagentName + '" that is being deleted');
          logger.info(utils.i18nTranslate(prefixArgs) + ': no unmanaged DSA has been found in environment "' + req.params.environmentName + '", so no unmanaged DSA to be deleted');
          logger.info(utils.i18nTranslate(prefixArgs) + ': deleting dxagent "' + req.params.dxagentName + '"');

          // now delete it
          ldapClient.deleteDxagent(req.params.dxagentName, req.params.environmentName, function(err) {
            if (err) {
              return process.nextTick(function () {callback(err);});
            }

            logger.info(utils.i18nTranslate(prefixArgs) + ': deleting dxagent "' + req.params.dxagentName + '" - successfully deleted');
            return process.nextTick(function () {callback();});
          });
        }
      }
    ],
    // callback functin that will be called if any function returns an error, or when all functions succeeded, called with an array of results 
    function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 204);
      }
    });
  });
};

/**
 * List all DSAs that belong to one dxagent, Get the list only from the directory
 */
dxagentController.listDsas = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.listDsas', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  var attributes;
  // required attributes
  if (req.query && req.query.attributes) {
    attributes = req.query.attributes.split(',');
    if (attributes.indexOf('name') === -1) {
      // 'name' doesn't exist in attributes
      req.query.attributes += ',name';
    }
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    // get the dxagent first
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        return utils.sendErrorResponse(res, err);
      }
      // get the list of DSAs from directory first
      listDsas(prefixArgs, ldapClient, req.params.dxagentName, req.params.environmentName, function(err, dsas) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return utils.sendErrorResponse(res, err);
        }
        // check to see if we need to retrieve status
        if (!attributes || (Array.isArray(attributes) && attributes.length > 0 && attributes.indexOf('status') != -1)) {
          // get all the DSAs from dxagent
          dxagentOps.getDxagentOperations(logger, req.getLocale()).getAllDsas(currentDxagent, 'name,status', function(err, dsasFromDxagent) {
            if (err) {
              return utils.sendErrorResponse(res, err);
            }
            // go through the list of DSAs and find the actual status of each of them
            var dsaName;
            var dsaIndex = -1;
            // define a callback function
            function findIndexOfDsaWithName(currentDsa) {
              if (currentDsa.name.toUpperCase() === dsaName.toUpperCase()) {
                return true;
              } else {
                return false;
              }
            }
            // get status for each DSA
            for (var i = 0; i < dsas.length; i++) {
              dsaName = dsas[i].name;
              dsaIndex = dsasFromDxagent.findIndex(findIndexOfDsaWithName);
              if (dsaIndex !== -1) {
                dsas[i].status = dsasFromDxagent[dsaIndex].status;
              } else {
                dsas[i].status = statusConfigOnly;
              }
              utils.removeAttributesNotRequested(dsas[i], utils.managementUiLdapConfig.uiDsaUpdateAttributes, attributes);
            }
            // return the results
            utils.sendJsonResponse(res, 200, dsas);
          });
        } else {
          for (var i = 0; i < dsas.length; i++) {
            utils.removeAttributesNotRequested(dsas[i], utils.managementUiLdapConfig.uiDsaUpdateAttributes, attributes);
          }
          // return the results
          utils.sendJsonResponse(res, 200, dsas);
        }
      });
    });
  });
};

/**
 * Common function to get a DSA. Retrieves DSA from Directory, and optionally DXagent when status is also requested.
 * req.params must include dsaName, dxagentName, environmentName
 */
function getDsaFromDirectoryAndDXagent(req, attributes, prefixArgs, logger, callback) {
  async.waterfall([
    function(cb1) {
      ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
        if (err)
          return cb1(err, null);
        cb1(null, ldapClient);
      });
    },
    function(ldapClient, cb2) {
      getDsa(prefixArgs, ldapClient, req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsa) {
        if (err)
          return cb2(err, ldapClient, null);
        // check to see if we need to retrieve status
        if (!attributes || (Array.isArray(attributes) && attributes.length > 0 && attributes.indexOf('status') != -1)) {
          // get dxagent
          ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
            if (err)
              return cb2(err, ldapClient, null);
            // now retrieve status from the dxagent
            dxagentOps.getDxagentOperations(logger, req.getLocale()).getDsa(currentDxagent, req.params.dsaName, 'name,status', function(err, dsaWithStatus) {
              if (err) {
                if (err.statusCode && err.statusCode === 404) {
                  // this means DSA does not exist on dxagent
                  dsa.status = statusConfigOnly;
                }
                else {
                  return cb2(err, ldapClient, null);
                }
              }
              else {
                dsa.status = dsaWithStatus.status;
              }
              cb2(null, ldapClient, dsa);
            });
          });
        }
        else
          cb2(null, ldapClient, dsa);
      });
    }
    ], function(err, ldapClient, dsa) {
    if (ldapClient)
      ldap.returnLdapClient(ldapClient);
    if (err)
      return callback(err, null);
    else if (dsa) {
      utils.removeAttributesNotRequested(dsa, utils.managementUiLdapConfig.uiDsaUpdateAttributes, attributes);
      return callback(null, dsa);
    }
    assert(false);
  });
}
    
/**
 * Get the named DSA that belong to the named dxagent from directory
 */
dxagentController.getDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.getDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  var attributes;
  // required attributes
  if (req.query && req.query.attributes) {
    attributes = req.query.attributes.split(',');
    if (attributes.indexOf('name') === -1) {
      // 'name' doesn't exist in attributes
      req.query.attributes += ',name';
    }
  }
  getDsaFromDirectoryAndDXagent(req, attributes, prefixArgs, logger, function(err, dsa) {
    if (err)
      return utils.sendErrorResponse(res, err);
    else if (dsa)
      return utils.sendJsonResponse(res, 200, dsa);
    else
      assert(false);
  });
};

/**
 * Bind to dsa and return the LDAP client object. The LDAP client object is a new connection/client, and this is
 * not pooled.   
 */
function bindToDsa(dsa, bindDn, bindPassword, locale, logger, connectCallback) {
  var prefixArgs = ['controllers.dxagents.prefix.bindToDsa', dsa ? dsa.name : 'null'];
  if (!dsa || !dsa.hasOwnProperty('config') || !dsa.config.hasOwnProperty('knowledge') || !Array.isArray(dsa.config.knowledge))
    return connectCallback(utils.createLocalizedAPIError(locale, prefixArgs, 'errors.invalidKnowledgeSetting', 400), null);
  var knowledge;
  knowledge = dsa.config.knowledge.find(function(knowledge) {
    return (knowledge.hasOwnProperty('name') && this.hasOwnProperty('name') && knowledge.name.toLowerCase() === this.name.toLowerCase());
  }, dsa);
  if (!knowledge || !knowledge.hasOwnProperty('interface') || !Array.isArray(knowledge.interface))
    return connectCallback(utils.createLocalizedAPIError(locale, prefixArgs, 'errors.dsaNeedKnowledgeAboutSelf', 400), null);
  var ldapClients = [];
  var urls = [];
  var errors = {};
  // Construct an array of ldap url's from all interfaces. Make a pair of url's for each interface,
  // one for ldaps and one for ldap. The ldaps url is always added to the head, and ldap url is
  // added to the tail. So all ldaps are always attempted first.
  knowledge.interface.forEach(function(intf) {
    urls.unshift('ldaps://' + intf.address + ':' + intf.port);
    urls.push('ldap://' + intf.address + ':' + intf.port);
  });
  if (urls.length === 0)
    return connectCallback(utils.createLocalizedAPIError(locale, prefixArgs, 'errors.invalidKnowledgeSetting', 400), null);
  // Try each url
  async.detectSeries(urls, function(url, seriesCallback) {
    logger.info(utils.i18nTranslate(prefixArgs) + ', trying ' + url);
    var ldapClient = ldapjs.createClient({
      url: url,
      tlsOptions: { 
        rejectUnauthorized: false,
        checkServerIdentity: function (host, cert) {}
      }
    });
    ldapClients.push(ldapClient);
    function handleConnectionError(err) {
      // ldapjs does not return the ldapClient object that emits the error so  async.detect.
      // cannot be used. The ldapClient reference here is the last created.
      logger.warn(utils.i18nTranslate(prefixArgs) + ': handleConnectionError url(' + ldapClient.url.href + ') err(' + err + ')');
      if (!errors[ldapClient.url.href])
        errors[ldapClient.url.href] = [];
      errors[ldapClient.url.href].push(err.message || err);
      ldapClient.destroy();
    }
    ldapClient.once('error', function(err) { handleConnectionError(err); });
    ldapClient.once('connectError', function(err) { handleConnectionError(err); });
    ldapClient.once('setupError', function(err) { handleConnectionError(err); });
    ldapClient.bind(bindDn, bindPassword, function(err) {
      if (err) {
        logger.warn(utils.i18nTranslate(prefixArgs) + ': failed to bind to ' + ldapClient.url.href + ' (' + err + ')');
        if (!errors[ldapClient.url.href])
          errors[ldapClient.url.href] = [];
        errors[ldapClient.url.href].push(err.message || err);
      }
      else
        logger.info(utils.i18nTranslate(prefixArgs) + ': succesfully bound to ' + ldapClient.url.href);
      seriesCallback(null, !err); // the first success will stop detectSeries
    });
  },
  function(err, url) { // detectSeries
    if (!url) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed to bind to any interface on DSA ' + dsa.name);
      var msg = '';
      for (var prop in errors) {
        if (errors.hasOwnProperty(prop) && Array.isArray(errors[prop]))
          msg += prop + '(' + errors[prop].join(' ') + ') ';
      }
      return connectCallback(utils.createAPIError(utils.i18nTranslate(['errors.unableToBindToDsa', dsa.name]), msg.trim(), 400), null);
    }
    ldapClient = ldapClients[ldapClients.length - 1]; // the last ldapClient is the one connected
    return connectCallback(null, ldapClient);
  });  
}

/**
 * Get DSA object classes
 */
dxagentController.getDsaObjectClasses = function(req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.getDsaObjectClasses', req.params.dsaName, req.params.dxagentName]; 
  logger.info(utils.i18nTranslate(req.getLocale(), prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(req.getLocale(), prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }
  getDsaFromDirectoryAndDXagent(req, ['name', 'config'], prefixArgs, logger, function(err, dsa) {
    if (err) {
      logger.error(utils.i18nTranslate(req.getLocale(), prefixArgs) + ': ' + err);
      return utils.sendErrorResponse(res, err);
    }
    var objectClasses = new ObjectClasses(logger, req.getLocale(), req.params.objectClass);
    bindToDsa(dsa, req.body.bindDn || '', req.body.bindPassword || '', req.getLocale(), logger, function(err, ldapClient) {
      if (err)
        return utils.sendErrorResponse(res, err);
      ldapClient.search('cn=schema', { scope: 'base', attributes: ['objectClasses', 'attributeTypes', 'ldapSyntaxes', 'nameForms'] }, function(searchErr, searchRes) {
        if (searchErr) {
          ldapClient.destroy();
          return utils.sendErrorResponse(res, searchErr);
        }
        searchRes.on('searchEntry', function(entry) {
          objectClasses.addLdapSearchEntry(entry);
        });
        searchRes.on('error', function(resErr) {
          ldapClient.destroy();
          return utils.sendErrorResponse(res, resErr);
        });
        searchRes.on('end', function(result) {
          ldapClient.unbind(function(err) {});
          objectClasses.getResult(function(err, result) {
            if (err)
              return utils.sendErrorResponse(res, err);
            if (result)
              return utils.sendJsonResponse(res, 200, result);
            assert(false);
          });
        });
      });
    });
  });
};

/**
 * Get the DSA schema that belong to the named dxagent
 */
dxagentController.getDsaSchema = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.getDsaSchema', req.params.dxagentName, req.params.environmentName];
  var locale = req.getLocale();
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  ldap.acquireLdapClient(logger, locale, function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    /**
     * Use the async library to execute tasks sequentially
     */
    async.waterfall([
      // check that we have the dxagent
      function (callback) {
        ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, dxagent) {
          if (err) {
            return callback(err);
          }
          return callback(null, dxagent);
        });
      },
      // retrieve the DSA json schema for the locale
      function (dxagent, callback) {
        retrieveDsaSchemaForLocale(prefixArgs, ldapClient, dxagent, req.params.environmentName, function(err, schemaToReturn) {
          return callback(err, schemaToReturn);
        });
      }
    ],
    // callback functin that will be called if any function returns an error, or when all functions succeeded, called with an array of results 
    function(err, schemaToReturn) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 200, schemaToReturn);
      }
    });
  });
};

/**
 * Get the DSA schema that belong to the named dxagent
 */
dxagentController.getAction = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.getAction', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    // get the dxagent first
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      }
      // we can continue now
      dxagentOps.getDxagentOperations(logger, req.getLocale()).getDsaAction(currentDxagent, function(err, data) {
        if (err) {
          // failed to retrieve DSA Json schema from dxagent
          return utils.sendErrorResponse(res, err);
        }
        logger.info('The DSA action list is retrieved successfully');
        utils.sendJsonResponse(res, 200, data);
      });

    });
  });
};

dxagentController.emptydbToDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.emptydbToDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // check that the environment exists
    ldapClient.getEnvironment(req.params.environmentName, function(err) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // error means that it does not exist or some other error condition with directory, abort
        // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
        return utils.sendErrorResponse(res, err);
      }
      // check that the dxagent exists
      ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return utils.sendErrorResponse(res, err);
        }
        // don't need to get the DSA as this function will be called immediately after the createDSA, but the DSA might not
        // be created in the embedded directory yet and so this call will fail. We just need to delegate the check to dxagent
        dxagentOps.getDxagentOperations(logger, req.getLocale()).emptydbToDsa(currentDxagent, req.params.dsaName, function(err, dsaUpdated) {
          if (err) {
            return utils.sendErrorResponse(res, err);
          }else {
            return utils.sendJsonResponse(res, 200, dsaUpdated);
          }
        });
      });
    });
  });
};

/**
 * Download the Ldif file or DB file for the named DSA that belong to the named dxagent
 */
dxagentController.downloadDsaFile = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.downloadDsaFile', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  var payload = req.body;
  if (!payload) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  // check the parameters
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // get the dxagent
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // if it does not exist
        return utils.sendErrorResponse(res, err);
      }

      ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsa) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return utils.sendErrorResponse(res, err);
        }
        dxagentOps.getDxagentOperations(logger, req.getLocale()).downloadDsaFile(currentDxagent, req.params.dsaName, payload, function(err, output) {
          if (err) {
            return utils.sendErrorResponse(res, err);
          } else {
            return utils.sendJsonResponse(res, 200, output);
          }
        });
      });
    });
  });
};

/*
* Check the status of the onlinebackups
*/
dxagentController.checkOnlineBackups = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.checkOnlineBackups', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  // check the parameters
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // get the dxagent
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // if it does not exist
        return utils.sendErrorResponse(res, err);
      }

      ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsa) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return utils.sendErrorResponse(res, err);
        }
        dxagentOps.getDxagentOperations(logger, req.getLocale()).checkOnlineBackups(currentDxagent, req.params.dsaName, function(err, output) {
          if (err) {
            return utils.sendErrorResponse(res, err);
          } else {
            return utils.sendJsonResponse(res, 200, output);
          }
        });
      });
    });
  });
};

/**
 * Load Ldif to the named DSA that belong to the named dxagent
 */
dxagentController.loadLdifToDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.loadLdifToDsa', req.body.ldifname, req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));
	
	res.setTimeout(config.loadFileToDsaTimeout * 60 * 1000, function(){
		logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.loadFileToDSATimeoutMsg'));
			return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.loadFileToDSATimeoutMsg', 500));
	});

  // the DSA body containing the verifyChecksum flag and the ldif file name which indicates to load the data to the just created DSA
  var ldifobj = req.body;
  if (!ldifobj) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  // check the parameters
  if (!req.params | !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // get the dxagent
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // if it does not exist
        return utils.sendErrorResponse(res, err);
      }

      ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsa) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return utils.sendErrorResponse(res, err);
        }
        // load the ldif
        dxagentOps.getDxagentOperations(logger, req.getLocale()).loadLdifToDsa(currentDxagent, req.params.dsaName, ldifobj, function(err, dsaCreated) {
          if (err) {
            return utils.sendErrorResponse(res, err);
          } else {
            return utils.sendJsonResponse(res, 201, dsaCreated);
          }
        });
      });
    });
  });
};

/**
 * Check to see if we are using secure protocol, i.e. HTTPS or HTTP
 */
function isSecureProtocol(req) {
  if (req.headers['x-forwarded-proto']) {
    return (req.headers['x-forwarded-proto'].toUpperCase().indexOf('HTTPS') === 0);
  }
  return req.connection.encrypted;
}

/* 
 * The function is used to decode CADIR encoded string.
 * The function uses dxpassword binary for decoding.
 * The DecodeCADIRHash function is also implemented at other places
 * to fix automation issues. 
 * Make sure if any update is done in this method it is also
 * updated in other files where we have implemented same method.
 */
function monitorDecodeCADIRHash(enc) {
  if(enc.indexOf('{CADIR}')==0)
  {
    const stdout = execSync('dxpassword -D CADIR ' + enc).toString();
    return stdout;
  }
  else
  {
    return enc;
  }
}

/**
 * Create the monitoring configuration for the DSA when "req.body.monitoringLabel" is present 
 */
function createExternalMonitoringConfig(prefixArgs, logger, dsaJsonSchema, req) {
  // check the 'monitoringLabel' and truncate it if necessary
  if (req.body.monitoringLabel && req.body.monitoringLabel.length > 0) {
    if (req.body.monitoringLabel.length > PROVIDED_MONITORING_LABEL_MAX_LENGTH) {
      logger.warn(utils.i18nTranslate(prefixArgs) + ': provided monitoring label "' + req.body.monitoringLabel + '" truncated to ' + PROVIDED_MONITORING_LABEL_MAX_LENGTH + ' characters');
      req.body.monitoringLabel = req.body.monitoringLabel.substring(0, PROVIDED_MONITORING_LABEL_MAX_LENGTH);
    }
    // append a random string to the label
    req.body.monitoringLabel += '-' + crypto.randomBytes(8).toString('hex');
    // create the external monitoring configuration block
    if (!req.body.config.settings) {
      req.body.config.settings = {};
    }
    if (!req.body.config.settings['external-monitor']) {
      req.body.config.settings['external-monitor'] = [];
    }
    // a new external monitoring configuration block
    var monitoringConfig = {name: req.body.monitoringLabel, 'push-interval': config.externalMonitor.pushInterval || 60, 'monitor-events': config.externalMonitor.monitorEvents || ['alarm-log-all', 'stats']};
    monitoringConfig.credentials = {username: config.externalMonitor.username, password: monitorDecodeCADIRHash(config.externalMonitor.password)};
    monitoringConfig.endpoint = (isSecureProtocol(req)) ? 'https://' : 'http://';
    monitoringConfig.endpoint += config.externalMonitor.hostname + ':' + config.port + config.apiPath + '/environments/' + encodeURIComponent(req.params.environmentName) + '/dxagents/' + encodeURIComponent(req.params.dxagentName) + '/dsas/' + encodeURIComponent(req.body.name);

    // add the options according to the DSA jason schema
    if (config.externalMonitor.options && Array.isArray(config.externalMonitor.options) && config.externalMonitor.options.length > 0) {
      if (!dsaJsonSchema || !getDsaMonitoringOptions(dsaJsonSchema)) {
        monitoringConfig.options = config.externalMonitor.options;
      } else {
        var allowedOptions = getDsaMonitoringOptions(dsaJsonSchema);
        var applicableOptions = config.externalMonitor.options.filter(function(oneOption) {
          return allowedOptions.indexOf(oneOption) !== -1;
        });
        if (applicableOptions && applicableOptions.length > 0) {
          monitoringConfig.options = applicableOptions;
        }
      }
    }

    logger.debug(utils.i18nTranslate(prefixArgs) + ': external monitoring configuration - "' + JSON.stringify(monitoringConfig) + '"');
    req.body.config.settings['external-monitor'].push(monitoringConfig);
    return true;
  }
}

/**
 * Get the options schema for DSA monitoring
 */
function getDsaMonitoringOptions(dsaJsonSchema) {
  var options =  dsaJsonSchema &&
                 dsaJsonSchema.dsaSchema &&
                 dsaJsonSchema.dsaSchema.properties &&
                 dsaJsonSchema.dsaSchema.properties.config &&
                 dsaJsonSchema.dsaSchema.properties.config.properties &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties['external-monitor'] &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties['external-monitor'].items &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties['external-monitor'].items.properties &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties['external-monitor'].items.properties.options &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties['external-monitor'].items.properties.options.items &&
                 dsaJsonSchema.dsaSchema.properties.config.properties.settings.properties['external-monitor'].items.properties.options.items.enum;

  if (options && Array.isArray(options) && options.length > 0) {
    return options;
  }
  return null;
}

/**
 * Create a new DSA that belongs to the named dxagent
 */
dxagentController.createDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.createDsa', req.body.name, req.params.dxagentName, req.params.environmentName];
  var initOthers = false;
  var initSelf = false;

  //check the http query string
  if (req.query && req.query.initOthers && (req.query.initOthers.toUpperCase() === 'TRUE' || req.query.initOthers === '1')) {
    initOthers = true;
    logger.info(utils.i18nTranslate(prefixArgs) + ' and init other DSAs that are started and whose configuration is affected');
  } else {
    logger.info(utils.i18nTranslate(prefixArgs));
  }

  if (req.query && req.query.initSelf && (req.query.initSelf.toUpperCase() === 'TRUE' || req.query.initSelf === '1')) {
    initSelf = true;
    logger.info(utils.i18nTranslate(prefixArgs) + ' and init DSA if it already exists on the dxagent host, is stared and configuration is changed');
  }

  // check dxagent name and environment name
  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }
  // check there is a request body
  if (!req.body) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }
  // check the required attributes
  var missingAttrs = checkRequiredAttributes(req.body, utils.managementUiLdapConfig.uiDsaRequiredAttributes);
  if (missingAttrs.length > 0) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }
  // check the dsa name
  if (!(dsaNameRegExp.test(req.body.name))) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.invalidDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.invalidDsaName', 400));
  }
  // check the dsaPeers property by validating the json object against the json schema
  if (req.body.dsaPeers) {
    var validateResults = jsonValidator.validate(req.body.dsaPeers, dsaPeersJsonSchema);
    if (validateResults.errors.length !== 0) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.getValidationErrorMessage(validateResults.errors));
      return utils.sendErrorResponse(res, utils.createAPIError(utils.i18nTranslate(req.getLocale(), prefixArgs), utils.getValidationErrorMessage(validateResults.errors, req.getLocale()), 400));
    }
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    /**
     * Use the async library to execute tasks sequentially
     */
    async.waterfall([
      // check that we have the environment and dxagent
      function (callback) {
        ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': environment and dxagent exist');
          // return with no error
          return process.nextTick(function () {callback(null, currentDxagent);});
        });
      },
      // check that we don't have a DSA with the same name already exists
      function (currentDxagent, callback) {
        checkDsaNameConflict(prefixArgs, ldapClient, req.body.name, req.params.dxagentName, req.params.environmentName, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': checked for DSA name conflict');
          // return with no error
          return process.nextTick(function () {callback(null, currentDxagent);});
        });
      },
      // validate the knowledge settings of the new DSA before saving it to directory
      function (currentDxagent, callback) {
        validateKnowledge(ldapClient, req.body, null, req.params.environmentName, function(err, knowledgeAboutSelf) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.debug(utils.i18nTranslate(prefixArgs) + ': DSA object to be created is "' + JSON.stringify(req.body) + '"');
          // return with no error
          return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf);});
        });
      },
      // add the CA certificate and set up the containers for storing monitoring messages if monitoring is enabled
      function (currentDxagent, knowledgeAboutSelf, callback) {
        if (!req.body.monitoringLabel || req.body.monitoringLabel.length === 0) {
          // we are not setting up monitoring
          return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf);});
        }

        // we are setting up monitoring
        retrieveDsaSchemaForLocale(prefixArgs, ldapClient, currentDxagent, req.params.environmentName, function(err, dsaJsonSchema) {
          if (err) {
            return callback(err);
          }

          // try parse the schema
          try {
            dsaJsonSchema = JSON.parse(dsaJsonSchema);
          } catch (error) {
            logger.warn(utils.i18nTranslate(prefixArgs) + ': failed to parse retrieve DSA json schema with error - "' + error + '"');
            dsaJsonSchema = null;
          }

          // create the monitoring configuration
          createExternalMonitoringConfig(prefixArgs, logger, dsaJsonSchema, req);

          // add the CA certificate
          addServerCaCertificatePemToDxagent(logger, currentDxagent, req.params.environmentName, function(err) {
            if (err) {
              return callback(err);
            }
            // create the message containers
            ldapClient.createMessageContainersForDsa(req.body.name, req.params.dxagentName, req.params.environmentName, function(err) {
              if (err) {
                return callback(err);
              }
              return callback(null, currentDxagent, knowledgeAboutSelf);
            });
          });
        });
      },
      // Store the DSA object in directory
      function (currentDxagent, knowledgeAboutSelf, callback) {
        ldapClient.createDsa(req.params.dxagentName, req.params.environmentName, req.body, function(err, dsaReturned) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf, dsaReturned);});
        });
      },
      // reconcile
      function (currentDxagent, knowledgeAboutSelf, dsaReturned, callback) {
        reconcileDsa(ldapClient, dsaReturned, knowledgeAboutSelf, currentDxagent, req.params.environmentName, initSelf, initOthers, function(err) {
          if (err && Array.isArray(err) && err.length > 0) {
            return process.nextTick(function () {callback(err);});
          }
          if (err && !Array.isArray(err)) {
            return process.nextTick(function () {callback(err);});
          }
          return process.nextTick(function () {callback(null, dsaReturned);});
        });
      }
    ],
    function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 201, results);
      }
    });
  });
};

/**
 * Update the named DSA that belong to the named dxagent
 */
dxagentController.updateDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.updateDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  var initOthers = false;
  var initSelf = false;
  var setupMonitoring = false;

  //check the http query string
  if (req.query && req.query.initOthers && (req.query.initOthers.toUpperCase() === 'TRUE' || req.query.initOthers === '1')) {
    initOthers = true;
    logger.info(utils.i18nTranslate(prefixArgs) + ' and init other DSAs that are started and whose configuration is affected');
  } else {
    logger.info(utils.i18nTranslate(prefixArgs));
  }

  if (req.query && req.query.initSelf && (req.query.initSelf.toUpperCase() === 'TRUE' || req.query.initSelf === '1')) {
    initSelf = true;
    logger.info(utils.i18nTranslate(prefixArgs) + ' and init DSA if started');
  }

  // check names
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }
  // check there is a request body
  if (!req.body) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }
  // we don't allow changing of DSA name
  req.body.name = req.params.dsaName;
  // check the required attributes
  var missingAttrs = checkRequiredAttributes(req.body, utils.managementUiLdapConfig.uiDsaRequiredAttributes);
  if (missingAttrs.length > 0) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }
  // check the dsaPeers property by validating the json object against the json schema
  if (req.body.dsaPeers) {
    var validateResults = jsonValidator.validate(req.body.dsaPeers, dsaPeersJsonSchema);
    if (validateResults.errors.length !== 0) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.getValidationErrorMessage(validateResults.errors));
      return utils.sendErrorResponse(res, utils.createAPIError(utils.i18nTranslate(req.getLocale(), prefixArgs), utils.getValidationErrorMessage(validateResults.errors, req.getLocale()), 400));
    }
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    /**
     * Use the async library to execute tasks sequentially
     */
    async.waterfall([
      // check that we have the environment and dxagent
      function (callback) {
        ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.info(utils.i18nTranslate(prefixArgs) + ': environment and dxagent exist');
          // return with no error
          return process.nextTick(function () {callback(null, currentDxagent);});
        });
      },
      // check that we have the DSA
      function (currentDxagent, callback) {
        ldapClient.getDsa(req.body.name, req.params.dxagentName, req.params.environmentName, function(err, existingDsa) {
          if (err) {
            logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.dsaNotExist'));
            return process.nextTick(function () {callback(utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.dsaNotExist', 404));});
          }

          logger.info(utils.i18nTranslate(prefixArgs) + ': DSA exists');

          // check the monitoringLabel
          if (existingDsa.monitoringLabel) {
            /****************************************************************************************************************************
             * existing DSA already has monitoring enabled
             */
            if (req.body.monitoringLabel && req.body.monitoringLabel.length > 0) {
              // if existing DSA already has it set, we don't want to allow this to be changed
              setupMonitoring = true;
              req.body.monitoringLabel = existingDsa.monitoringLabel;
              if (existingDsa.config &&
                  existingDsa.config.settings &&
                  existingDsa.config.settings['external-monitor'] &&
                  Array.isArray(existingDsa.config.settings['external-monitor']) &&
                  existingDsa.config.settings['external-monitor'].length > 0) {

                existingDsa.config.settings['external-monitor'].find(function(oneMonitoringConfig) {
                  if (existingDsa.monitoringLabel === oneMonitoringConfig.name) {

                    if (!req.body.config.settings) {
                      req.body.config.settings = {};
                    }
                    if (!req.body.config.settings['external-monitor']) {
                      req.body.config.settings['external-monitor'] = [oneMonitoringConfig];
                      return true;
                    }

                    var index = req.body.config.settings['external-monitor'].findIndex(function(oneNewMonitoringConfig) {
                      if (existingDsa.monitoringLabel === oneNewMonitoringConfig.name) {
                        return true;
                      }
                    });

                    if (index !== -1) {
                      req.body.config.settings['external-monitor'][index] = oneMonitoringConfig;
                    } else {
                      req.body.config.settings['external-monitor'].push(oneMonitoringConfig);
                    }

                    return true;
                  }
                });
              }
            } else {
              // this is to remove existing external monitoring configuration
              if (req.body.config.settings && req.body.config.settings['external-monitor'] && Array.isArray(req.body.config.settings['external-monitor'])) {
                var itemToRemoveindex = req.body.config.settings['external-monitor'].findIndex(function(oneNewMonitoringConfig) {
                  if (existingDsa.monitoringLabel === oneNewMonitoringConfig.name) {
                    return true;
                  }
                });

                if (itemToRemoveindex !== -1) {
                  req.body.config.settings['external-monitor'].splice(itemToRemoveindex, 1);
                }

                // if the length of req.body.config.settings['external-monitor'] is zero, remove it
                if (req.body.config.settings['external-monitor'].length === 0) {
                  delete req.body.config.settings['external-monitor'];
                }
              }
            }
            /****************************************************************************************************************************
             * existing DSA already has monitoring enabled - return with no error
             */
            return process.nextTick(function () {callback(null, currentDxagent, existingDsa);});
          } else {
            /****************************************************************************************************************************
             * existing DSA does not have monitoring enabled
             */
            if (!req.body.monitoringLabel || req.body.monitoringLabel.length === 0) {
              // we are not setting up monitoring
              return process.nextTick(function () {callback(null, currentDxagent, existingDsa);});
            }

            setupMonitoring = true;

            // we are setting up monitoring
            retrieveDsaSchemaForLocale(prefixArgs, ldapClient, currentDxagent, req.params.environmentName, function(err, dsaJsonSchema) {
              if (err) {
                return callback(err);
              }

              // try parse the schema
              try {
                dsaJsonSchema = JSON.parse(dsaJsonSchema);
              } catch (error) {
                logger.warn(utils.i18nTranslate(prefixArgs) + ': failed to parse retrieve DSA json schema with error - "' + error + '"');
                dsaJsonSchema = null;
              }

              // create the monitoring configuration
              createExternalMonitoringConfig(prefixArgs, logger, dsaJsonSchema, req);
              return callback(null, currentDxagent, existingDsa);
            });
          }
        });
      },
      // validate the knowledge settings of the new DSA before saving it to directory
      function (currentDxagent, existingDsa, callback) {
        validateKnowledge(ldapClient, req.body, existingDsa, req.params.environmentName, function(err, knowledgeAboutSelf) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // return with no error
          return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf);});
        });
      },
      // add the CA certificate and create the message containers if monitoring is enabled
      function (currentDxagent, knowledgeAboutSelf, callback) {
        if (!setupMonitoring) {
          return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf);});
        }
        // we are setting up monitoring, so add the CA certificate
        addServerCaCertificatePemToDxagent(logger, currentDxagent, req.params.environmentName, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // create the message containers
          ldapClient.createMessageContainersForDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err) {
            if (err) {
              return process.nextTick(function () {callback(err);});
            }
            return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf);});
          });
        });
      },
      // Store the DSA object in directory
      function (currentDxagent, knowledgeAboutSelf, callback) {
        ldapClient.updateDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, req.body, function(err, dsaReturned) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          return process.nextTick(function () {callback(null, currentDxagent, knowledgeAboutSelf, dsaReturned);});
        });
      },
      // reconcile
      function (currentDxagent, knowledgeAboutSelf, dsaReturned, callback) {
        reconcileDsa(ldapClient, dsaReturned, knowledgeAboutSelf, currentDxagent, req.params.environmentName, initSelf, initOthers, function(err) {
          if (err && Array.isArray(err) && err.length > 0) {
            return process.nextTick(function () {callback(err);});
          }
          if (err && !Array.isArray(err)) {
            return process.nextTick(function () {callback(err);});
          }
          return process.nextTick(function () {callback(null, dsaReturned);});
        });
      }
    ],
    function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 200, results);
      }
    });
  });
};

/**
 * Change the status of the named DSA that belong to the named dxagent
 */
dxagentController.updateDsaStatus = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.updateDsaStatus', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  // check names
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }
  // check there is a request body
  if (!req.body || !req.body.action) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // check that the environment exists
    ldapClient.getEnvironment(req.params.environmentName, function(err) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // error means that it does not exist or some other error condition with directory, abort
        // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
        return utils.sendErrorResponse(res, err);
      }
      // check that the dxagent exists
      ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
        if (err) {
          ldap.returnLdapClient(ldapClient);
          // if it does not exist
          return utils.sendErrorResponse(res, err);
        }
        // check that the DSA exists
        ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsaFromDirectory) {
          if (err) {
            ldap.returnLdapClient(ldapClient);
            // error means it does not exist
            logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.dsaNotExist'));
            return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.dsaNotExist', 404));
          }
          // now change the status
          dxagentOps.getDxagentOperations(logger, req.getLocale()).updateDsaStatus(currentDxagent, req.params.dsaName, JSON.stringify(req.body), function(err, newStatus) {
            if (err) {
              ldap.returnLdapClient(ldapClient);
              utils.sendErrorResponse(res, err);
            } else {
              // now update the status of the DSA in directory
              dsaFromDirectory.status = newStatus.status;
              ldapClient.updateDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, dsaFromDirectory, function(err) {
                ldap.returnLdapClient(ldapClient);
                if (err) {
                  logger.warn(utils.i18nTranslate(prefixArgs) + ': updated DSA status successfully, failed to store new status in directory. Error is - ' + err.message);
                }
                utils.sendJsonResponse(res, 200, newStatus);
              });
            }
          });
        });
      });
    });
  });
};

// create an online backup for DSA
dxagentController.backupToDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.backupToDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  // check names
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // check that the environment exists
    ldapClient.getEnvironment(req.params.environmentName, function(err) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // error means that it does not exist or some other error condition with directory, abort
        // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
        return utils.sendErrorResponse(res, err);
      }
      // check that the dxagent exists
      ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
        if (err) {
          ldap.returnLdapClient(ldapClient);
          // if it does not exist
          return utils.sendErrorResponse(res, err);
        }
        // check that the DSA exists
        ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsaFromDirectory) {
          ldap.returnLdapClient(ldapClient);
          if (err) {
            // error means it does not exist
            logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.dsaNotExist'));
            return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.dsaNotExist', 404));
          }

          dxagentOps.getDxagentOperations(logger, req.getLocale()).backupToDsa(currentDxagent, req.params.dsaName, function(err, result) {
            if (err) {
              utils.sendErrorResponse(res, err);
            } else {
              // Not expecting the result to contain anything
              utils.sendJsonResponse(res, 201, result);
            }
          });
        });
      });
    });
  });
};


// trigger a logroll action for DSA
dxagentController.logrollToDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.logrollToDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  // check names
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // check that the environment exists
    ldapClient.getEnvironment(req.params.environmentName, function(err) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // error means that it does not exist or some other error condition with directory, abort
        // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
        return utils.sendErrorResponse(res, err);
      }
      // check that the dxagent exists
      ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
        if (err) {
          ldap.returnLdapClient(ldapClient);
          // if it does not exist
          return utils.sendErrorResponse(res, err);
        }
        // check that the DSA exists
        ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsaFromDirectory) {
          ldap.returnLdapClient(ldapClient);
          if (err) {
            // error means it does not exist
            logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.dsaNotExist'));
            return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.dsaNotExist', 404));
          }

          dxagentOps.getDxagentOperations(logger, req.getLocale()).logrollToDsa(currentDxagent, req.params.dsaName, function(err, result) {
            if (err) {
              utils.sendErrorResponse(res, err);
            } else {
              // Not expecting the result to contain anything
              utils.sendJsonResponse(res, 201, result);
            }
          });
        });
      });
    });
  });
};

/**
 * Delete the named DSA that belong to the named dxagent
 */
dxagentController.deleteDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.deleteDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  var initOthers = false;
  var deleteDb = 0; // not delete DB

  logger.info(utils.i18nTranslate(prefixArgs));

  // check the http query string for the initOthers
  if (req.query && req.query.initOthers && (req.query.initOthers.toUpperCase() === 'TRUE' || req.query.initOthers === '1')) {
    initOthers = true;
    logger.info(utils.i18nTranslate(prefixArgs) + ': init other DSAs that are started and whose configuration is changed');
  }

  // check the http query string for the delete_db and delete_db_all
  // check delete_db_all first, if it is set, ignore delete_db
  if (req.query && req.query.delete_db_all && (req.query.delete_db_all.toUpperCase() === 'TRUE' || req.query.delete_db_all === '1')) {
    deleteDb = 2;
    logger.info(utils.i18nTranslate(prefixArgs) + ': delete database files and online backups associated with the DSA');
  }

  if (deleteDb !== 2 && req.query && req.query.delete_db && (req.query.delete_db.toUpperCase() === 'TRUE' || req.query.delete_db === '1')) {
    deleteDb = 1;
    logger.info(utils.i18nTranslate(prefixArgs) + ': delete database files associated with the DSA');
  }

  // check the parameters
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    var currentDxagent;
    var dsaToDelete;

    /**
     * Use async library to execute the tasks sequentially
     */
    async.series([
      // get the dxagent for the DSA
      function (callback) {
        ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, dxagentForDsa) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          currentDxagent = dxagentForDsa;
          logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved dxagent object for the DSA');
          return process.nextTick(function () {callback();});
        });
      },
      // check that the DSA exists
      function (callback) {
        ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err, dsaToDeleteFromDir) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          dsaToDelete = dsaToDeleteFromDir;
          logger.info(utils.i18nTranslate(prefixArgs) + ': retrieved the DSA object');
          return process.nextTick(function () {callback();});
        });
      },
      // delete the alarms
      function (callback) {
        ldapClient.deleteAlarmsDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, false, function (err) {
          if (!err) {
            // deleted
            logger.info(utils.i18nTranslate(prefixArgs) + ': alarm messages for the DSA deleted successfully');
          }
        });
        // don't wait for the deletion to finish
        return process.nextTick(function () {callback();});
      },
      // delete the stats
      function (callback) {
        ldapClient.deleteStatsDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function (err) {
          if (!err) {
            // deleted
            logger.info(utils.i18nTranslate(prefixArgs) + ': stats messages for the DSA deleted successfully');
          }
        });
        // don't wait for the deletion to finish
        return process.nextTick(function () {callback();});
      },
      // delete the DSA object
      function (callback) {
        ldapClient.deleteDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // deleted
          logger.info(utils.i18nTranslate(prefixArgs) + ': successfully deleted DSA "' + req.params.dsaName + '" from directory');
          return process.nextTick(function () {callback();});
        });
      },
      // reconcile
      function (callback) {
        reconcileDsaDeleted(ldapClient, utils.getKnowledgeAboutSelf(dsaToDelete), currentDxagent, req.params.environmentName, initOthers, deleteDb, function(err) {
          if (err && Array.isArray(err) && err.length > 0) {
            return process.nextTick(function () {callback(err);});
          }
          return process.nextTick(function () {callback();});
        });
      }
    ],
    // callback function that will be called if any function returns an error, or when all functions succeeded, called with an array of results
    function(err) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 204);
      }
    });
  });
};

/**
 * Triggers dxdisp for a DSA on the named dxagent
 */
dxagentController.dxdisp = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.dxdisp', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  // check the parameters
  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  // check the request body
  if (!req.body || !req.body.peerDsa) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    // check that the environment exists
    ldapClient.getEnvironment(req.params.environmentName, function(err) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        // error means that it does not exist or some other error condition with directory, abort
        // RETURN FROM THE ENCLOSING ANONYMOUS CALLBACK FUNCTION
        return utils.sendErrorResponse(res, err);
      }
      // check that the dxagent exists
      ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          return utils.sendErrorResponse(res, err);
        }

        dxagentOps.getDxagentOperations(logger, req.getLocale()).dxdisp(currentDxagent, JSON.stringify(req.body), function(err) {
          if (err) {
            utils.sendErrorResponse(res, err);
          } else {
            utils.sendJsonResponse(res, 204);
          }
        });
      });
    });
  });
};

/**
 * Validate the knowledge settings of a DSA.
 *
 * @param ldapClient
 * @param dsa - dsa to be checked
 * @param existingDsa - dsa that exists in directory. this is for the case of update. Pass in null for all other cases
 * @param environmentName
 * @param callback(err, knowledgeAboutSelf)
 */
function validateKnowledge(ldapClient, dsa, existingDsa, environmentName, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;
  var prefixArgs = ['controllers.dxagents.prefix.validateKnowledge', dsa.name, environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  var knowledgeAboutSelf;

  /**
   * Go through the list of dsaPeers, check the existence of each DSA, get the knowledge
   * about each one and insert into the DSA configuration
   *
   * @param dsaToCheck
   * @param callback
   */
  function checkDsaPeers(dsaToCheck, callback) {

    function checkDsaPeerAtIndex(peerIndex, callback) {
      if (peerIndex === dsaToCheck.dsaPeers.length) {
        // no more DSA peers to check
        logger.info(utils.i18nTranslate(prefixArgs) + ': finished checking all the DSA peers');
        return process.nextTick(function(){callback();});
      }

      // get the DSA peer at the current index
      var currentDsaPeer = dsaToCheck.dsaPeers[peerIndex];
      if (currentDsaPeer.dxagent) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': checking DSA peer "' + currentDsaPeer.dsa + '" managed by dxagent "' + currentDsaPeer.dxagent + '"');

        ldapClient.getDsa(currentDsaPeer.dsa, currentDsaPeer.dxagent, environmentName, function(err, retrievedPeerDsa) {
          if (err) {
            if (err.statusCode && err.statusCode === 404) {
              logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.dsaPeerNotExist', currentDsaPeer.dsa]));
              return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.dsaPeerNotExist', currentDsaPeer.dsa], 400));});
            } else {
              return process.nextTick(function(){callback(err);});
            }
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': DSA peer "' + currentDsaPeer.dsa + '" managed by dxagent "' + currentDsaPeer.dxagent + '" has been retrieved');

            // get the knowledge of the retrieved DSA itself and append to the dsa configuration
            var retrievedPeerDsaSelfKnowledge = utils.getKnowledgeAboutSelf(retrievedPeerDsa);
            if (retrievedPeerDsaSelfKnowledge) {
              dsaToCheck.config.knowledge.push(retrievedPeerDsaSelfKnowledge);
              // go to the next one
              checkDsaPeerAtIndex(peerIndex + 1, callback);
            } else {
              logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.noSelfKnowledge', currentDsaPeer.dsa, currentDsaPeer.dxagent]));
              return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.noSelfKnowledge', currentDsaPeer.dsa, currentDsaPeer.dxagent]));});
            }
          }
        });
      } else {
        logger.info(utils.i18nTranslate(prefixArgs) + ': checking umanaged DSA peer "' + currentDsaPeer.dsa + '"');

        ldapClient.getUnmanagedDsa(currentDsaPeer.dsa, environmentName, function(err, retrievedUnmanagedDsa) {
          if (err) {
            if (err.statusCode && err.statusCode === 404) {
              logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.dsaPeerNotExist', currentDsaPeer.dsa]));
              return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.dsaPeerNotExist', currentDsaPeer.dsa], 400));});
            } else {
              return process.nextTick(function(){callback(err);});
            }
          } else {
            logger.info(utils.i18nTranslate(prefixArgs) + ': unmanaged DSA peer "' + currentDsaPeer.dsa + '" has been retrieved');
            dsaToCheck.config.knowledge.push(retrievedUnmanagedDsa.config);
            // go to the next one
            checkDsaPeerAtIndex(peerIndex + 1, callback);
          }
        });
      }
    }

    // kick off the checking here
    checkDsaPeerAtIndex(0, callback);
  }

  // All DSAs have to have knowledge about itself, so minimum length of knowledge is 1
  if (!(dsa.config.knowledge) || !(Array.isArray(dsa.config.knowledge)) || dsa.config.knowledge.length < 1) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.dsaNeedKnowledgeAboutSelf'));
    return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, 'errors.dsaNeedKnowledgeAboutSelf', 400));});
  }

  // check knowledge about self
  knowledgeAboutSelf = utils.getKnowledgeAboutSelf(dsa);

  if (!knowledgeAboutSelf) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.dsaNeedKnowledgeAboutSelf'));
    return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, 'errors.dsaNeedKnowledgeAboutSelf', 400));});
  }

  // check the global knowledge flag
  if (dsa.globalKnowledge) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': DSA has global knowledge setting');
    // build the global knowledge list and add it to the DSA's knowledge list
    utils.buildGlobalKnowledgeList(ldapClient, environmentName, function(err, globalKnowledgeList) {
      if (err) {
        return process.nextTick(function(){callback(err);});
      }

      // if no other global knowledge DSA has been found, nothing else needs to be done.
      if (!globalKnowledgeList || globalKnowledgeList.length === 0) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': no other global knowledge DSA has been found');
        return process.nextTick(function(){callback(null, knowledgeAboutSelf);});
      }

      // find DSA name in self knowledge in the global knowledge list, returns true when found.
      function findIndexOfSelf(currentKnowledge) {
        if (currentKnowledge.name.toUpperCase() === knowledgeAboutSelf.name.toUpperCase()) {
          return true;
        }
      }

      // for the cases where there is an existing DSA in directory
      if (existingDsa) {
        var selfKnowledgeOfExistingDsa = utils.getKnowledgeAboutSelf(existingDsa);
        if (!selfKnowledgeOfExistingDsa) {
          logger.warn(utils.i18nTranslate(prefixArgs) + ': existing DSA does not have knowledge about itself');
          globalKnowledgeList = globalKnowledgeList.concat(knowledgeAboutSelf);
        } else {
          // find out if existing DSA is in the globalKnowledge list
          var matchingKnowledgeIndexInGlobalKnowledgeList = findMatchingKnowledgeIndex(prefixArgs, logger, selfKnowledgeOfExistingDsa, globalKnowledgeList);
          if (matchingKnowledgeIndexInGlobalKnowledgeList !== -1) {
            // existing dsa is in the globalKnowledge list, replace it with the new self knowledge
            globalKnowledgeList[matchingKnowledgeIndexInGlobalKnowledgeList] = knowledgeAboutSelf;
          } else {
            // existing dsa is not in the global knowledge list, make sure there is no name conflict
            if (globalKnowledgeList.findIndex(findIndexOfSelf) !== -1) {
              // name conflict
              logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.dsaNameConflictInGlobalKnowledgeList', knowledgeAboutSelf.name]));
              return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.dsaNameConflictInGlobalKnowledgeList', knowledgeAboutSelf.name], 400));});
            } else {
              globalKnowledgeList = globalKnowledgeList.concat(knowledgeAboutSelf);
            }
          }
        }
      } else {
        // this is the case for adding a new dsa, make sure there is no name conflict
        if (globalKnowledgeList.findIndex(findIndexOfSelf) !== -1) {
          // name conflict
          logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.dsaNameConflictInGlobalKnowledgeList', knowledgeAboutSelf.name]));
          return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.dsaNameConflictInGlobalKnowledgeList', knowledgeAboutSelf.name], 400));});
        } else {
          globalKnowledgeList = globalKnowledgeList.concat(knowledgeAboutSelf);
        }
      }

      dsa.config.knowledge = globalKnowledgeList;
      return process.nextTick(function(){callback(null, knowledgeAboutSelf);});
    });
  } else {
    logger.info(utils.i18nTranslate(prefixArgs) + ': DSA has explicit knowledge');
    dsa.config.knowledge = [knowledgeAboutSelf];

    if (!dsa.dsaPeers) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': DSA only has knowledge about self');
      return process.nextTick(function(){callback(null, knowledgeAboutSelf);});
    }

    // add self knowledge to the list before checking DSA name duplicates. Note Array.concat() method does not change existing array, it creates a new one
    var completeKnowledgeList = dsa.dsaPeers.concat({dsa: knowledgeAboutSelf.name});
    // make sure there is no two DSAs with the same name (case-insensitive) in the list
    var duplicateIndex = completeKnowledgeList.findIndex(function(oneEntry, oneEntryIndex, completeKnowledgeListArray) {
      for (var i = oneEntryIndex + 1; i < completeKnowledgeListArray.length; i++) {
        if (oneEntry.dsa.toUpperCase() === completeKnowledgeListArray[i].dsa.toUpperCase()) {
          return true;
        }
      }
    });
    // if duplicates are found
    if (duplicateIndex !== -1) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.dsaNameConflictInKnowledgeList', completeKnowledgeList[duplicateIndex].dsa]));
      return process.nextTick(function(){callback(utils.createLocalizedAPIError(locale, prefixArgs, ['errors.dsaNameConflictInKnowledgeList', completeKnowledgeList[duplicateIndex].dsa], 400));});
    }

    // make sure all dsas referred to in the dsaPeers attribute exist and construct the knowledge list for the DSA
    checkDsaPeers(dsa, function(err){
      if (err) {
        return process.nextTick(function(){callback(err);});
      } else {
        return process.nextTick(function(){callback(null, knowledgeAboutSelf);});
      }
    });
  }
}

/**
 * Update DSA in directory as well as with dxagent
 *
 * @param ldapClient
 * @param dsa
 * @param dxagent
 * @param environmentName
 * @param init
 * @param callback
 */
function updateDsaInDirectoryAndDxagent(ldapClient, dsa, dxagent, environmentName, init, callback) {
  var logger = ldapClient.logger;
  var prefix = 'Update DSA "' + dsa.name + '" in directory and with dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  if (init) {
    logger.info(prefix + ' and init DSA if it is started');
  } else {
    logger.info(prefix);
  }
  
  var dxagentOperations = dxagentOps.getDxagentOperations(logger, ldapClient.locale);

  // update DSA with dxagent first
  dxagentOperations.updateDsa(dxagent, dsa.name, JSON.stringify(dsa), function(err, updatedDsaDxagent) {
    if (err) {
      logger.error(prefix + ': failed to update DSA with dxagent, error is - ' + err.message);
      // set the error on directory
      ldapClient.setDsaError(dsa.name, dxagent.name, environmentName, err, function(setError) {
        if (setError) {
          logger.error(prefix + ': failed to store error on DSA in directory, failed with error - ' + setError.message);
        } else {
          logger.info(prefix + ': update DSA error message had been successfully stored');
        }
        return process.nextTick(function(){callback(err);});
      });
    } else {
      if (dsa.globalKnowledge) {
        updatedDsaDxagent.globalKnowledge = dsa.globalKnowledge;
      }
      if (dsa.dsaPeers) {
        updatedDsaDxagent.dsaPeers = dsa.dsaPeers;
      }
      if (dsa.monitoringLabel) {
        updatedDsaDxagent.monitoringLabel = dsa.monitoringLabel;
      }

      // now update DSA on directory
      ldapClient.updateDsa(dsa.name, dxagent.name, environmentName, updatedDsaDxagent, function(err) {
        if (err) {
          logger.error(prefix + ': failed to update DSA in directory, error is - ' + err.message);
          return process.nextTick(function(){callback(err);});
        } else {
          logger.info(prefix + ': successfully stored new DSA configuration in directory');
        }

        // init the started DSA
        if (init && updatedDsaDxagent && updatedDsaDxagent.status && updatedDsaDxagent.status === 'started') {
          dxagentOperations.updateDsaStatus(dxagent, dsa.name, '{"action":"init"}', function(err, newStatus) {
            if (err) {
              logger.error(prefix + ': failed to init DSA, error is - ' + err.message);
              return process.nextTick(function(){callback(err);});
            } else {
              logger.warn(prefix + ': successfully inited DSA after configuration updated');
              return process.nextTick(function(){callback();});
            }
          });
        } else {
          return process.nextTick(function(){callback();});
        }
      });
    }
  });
}

/**
 * Reconcile a DSA stored in directory
 */
function reconcileDsa(ldapClient, dsa, knowledgeAboutSelf, dxagent, environmentName, initSelf, initOthers, callback) {
  var logger = ldapClient.logger;
  var dxagentOperations = dxagentOps.getDxagentOperations(logger, ldapClient.locale);
  var prefix = 'Reconcile DSA "' + dsa.name + '" in environment "' + environmentName + '"';
  logger.info(prefix);

  var processingErrors = [];

  // find out if the DSA exists on dxagent host already
  dxagentOperations.getDsa(dxagent, dsa.name, function(err, existedDsa) {
    // no statusCode means communication error with dxagent
    if ((err && !err.statusCode) || (err && err.statusCode && err.statusCode !== 404)) {
      logger.error(prefix + ': dxagent failed to check the existence of the DSA, error is - ' + err.message);
      return process.nextTick(function(){callback(err);});
    }

    // if DSA already exists
    if (!err && existedDsa) {
      logger.info(prefix + ': DSA already exists');
      // now compare the configuration of the DSA retrieved from dxagent with the
      // configuration stored in directory, if they are different, tell the dxagent to
      // update the DSA
      if (!utils.compareDsaConfiguration(dsa, existedDsa, logger)) {
        logger.info(prefix + ': DSA has different configuration from that stored in directory');
        dxagentOperations.updateDsa(dxagent, dsa.name, JSON.stringify(dsa), function(err, updatedDsa) {
          if (err) {
            logger.error(prefix + ': failed to update DSA with configuration stored in directory, error is - ' + err.message);
            // set the error on directory
            ldapClient.setDsaError(dsa.name, dxagent.name, environmentName, err, function(setError) {
              if (setError) {
                logger.error(prefix + ': failed to store error on DSA in directory, failed with error - ' + setError.message);
              } else {
                logger.info(prefix + ': update DSA error message had been successfully stored');
              }
              return process.nextTick(function(){callback(err);});
            });
          } else {
            if (dsa.globalKnowledge) {
              updatedDsa.globalKnowledge = dsa.globalKnowledge;
            }
            if (dsa.dsaPeers) {
              updatedDsa.dsaPeers = dsa.dsaPeers;
            }
            if (dsa.monitoringLabel) {
              updatedDsa.monitoringLabel = dsa.monitoringLabel;
            }

            logger.info(prefix + ': successfully updated DSA with configuration stored in directory');

            // update the configuration stored in directory with the updated one from dxagent
            //ldap.updateDsa(ldapClient, dsa.name, dxagent.name, environmentName, dsa, function(err) {
            ldapClient.updateDsa(dsa.name, dxagent.name, environmentName, updatedDsa, function(err) {
              if (err) {
                logger.error(prefix + ': failed to update DSA in directory with configuration from dxagent after update, error is - ' + err.message);
                processingErrors = processingErrors.concat(err);
              }

              // if we want to init self after DSA updated
              if (initSelf && existedDsa && existedDsa.status && existedDsa.status === 'started') {
                // init the started DSA
                dxagentOperations.updateDsaStatus(dxagent, dsa.name, '{"action":"init"}', function(err, newStatus) {
                  if (err) {
                    processingErrors = processingErrors.concat(err);
                    logger.error(prefix + ': failed to init DSA, error is - ' + err.message);
                  } else {
                    logger.warn(prefix + ': successfully inited DSA after configuration updated');
                  }
                  // reconcile knowledge settings
                  updateKnowledgeForDsasInEnv(ldapClient, knowledgeAboutSelf, utils.getKnowledgeAboutSelf(existedDsa), (dsa.globalKnowledge ? true : false), environmentName, initOthers, function(err) {
                    if (err) {
                      processingErrors = processingErrors.concat(err);
                    }
                    return process.nextTick(function(){callback(processingErrors);});
                  });
                });
              } else {
                // don't need to init DSA, reconcile knowledge settings
                updateKnowledgeForDsasInEnv(ldapClient, knowledgeAboutSelf, utils.getKnowledgeAboutSelf(existedDsa), (dsa.globalKnowledge ? true : false), environmentName, initOthers, function(err) {
                  if (err) {
                    processingErrors = processingErrors.concat(err);
                  }
                  return process.nextTick(function(){callback(processingErrors);});
                });
              }
            });
          }
        });
      } else {
        logger.info(prefix + ': DSA already has the same configuration as stored in directory');

        // reconcile knowledge settings
        updateKnowledgeForDsasInEnv(ldapClient, knowledgeAboutSelf, utils.getKnowledgeAboutSelf(existedDsa), (dsa.globalKnowledge ? true : false), environmentName, initOthers, function(err) {
          if (err) {
            processingErrors = processingErrors.concat(err);
          }
          return process.nextTick(function(){callback(processingErrors);});
        });
      }
    } else {
      // DSA does not exit, create the DSA first, don't need to init newly created DSA
      dxagentOperations.createDsa(dxagent, JSON.stringify(dsa), function(err, createdDsa) {
        if (err) {
          logger.error(prefix + ': dxagent failed to create the DSA, error is - ' + err.message);
          // set the error on directory
          ldapClient.setDsaError(dsa.name, dxagent.name, environmentName, err, function(setError) {
            if (setError) {
              logger.error(prefix + ': failed to store error on DSA in directory, failed with error - ' + setError.message);
            } else {
              logger.info(prefix + ': create DSA error message had been successfully stored');
            }
            return process.nextTick(function(){callback(err);});
          });
        } else {
          if (dsa.globalKnowledge) {
            createdDsa.globalKnowledge = dsa.globalKnowledge;
          }
          if (dsa.dsaPeers) {
            createdDsa.dsaPeers = dsa.dsaPeers;
          }
          if (dsa.monitoringLabel) {
            createdDsa.monitoringLabel = dsa.monitoringLabel;
          }

          logger.info(prefix + ': dxagent has created the DSA successfully');

          // update the configuration stored in directory with the one from dxagent after creation
          //ldap.updateDsa(ldapClient, dsa.name, dxagent.name, environmentName, dsa, function(err) {
          ldapClient.updateDsa(dsa.name, dxagent.name, environmentName, createdDsa, function(err) {
            if (err) {
              logger.error(prefix + ': failed to update DSA in directory with configuration from dxagent after creation, error is - ' + err.message);
              processingErrors = processingErrors.concat(err);
            }
            // reconcile knowledge settings
            updateKnowledgeForDsasInEnv(ldapClient, knowledgeAboutSelf, knowledgeAboutSelf, (dsa.globalKnowledge ? true : false), environmentName, initOthers, function(err) {
              if (err) {
                processingErrors = processingErrors.concat(err);
              }
              return process.nextTick(function(){callback(processingErrors);});
            });
          });
        }
      });
    }
  });
}

/**
 * Reconcile a DSA exists on the dxagent host but does not exist in directory, e.g. DSA being deleted
 */
function reconcileDsaDeleted(ldapClient, dsaKnowledge, dxagent, environmentName, init, deleteDB, callback) {
  var logger = ldapClient.logger;
  var prefix = 'Reconcile DSA "' + dsaKnowledge.name + '" which has been deleted';
  logger.info(prefix);

  if (init) {
    logger.info(prefix + ': init DSAs that are started and whose configuration is changed');
  }

  if (deleteDB === 2) {
    logger.info(prefix + ': delete database files and online backups associated with the DSA');
  } else if (deleteDB === 1) {
    logger.info(prefix + ': delete database files associated with the DSA');
  }

  var processingErrors = [];

  // tell dxagent to delete the DSA first
  dxagentOps.getDxagentOperations(logger, ldapClient.locale).deleteDsa(dxagent, dsaKnowledge.name, deleteDB, function(err) {
    if (err && err.statusCode && err.statusCode !== 404) {
      // ignore DSA not found error
      processingErrors = processingErrors.concat(err);
      return process.nextTick(function(){callback(processingErrors);});
    }

    logger.info(prefix + ': successfully deleted DSA on dxagent host');

    // remove the knowledge about the deleted DSA from all other DSAs in the same environment
    removeKnowledgeFromDsasInEnv(ldapClient, dsaKnowledge, environmentName, false, init, function(err) {
      if (!err) {
        logger.info(prefix + ': successfully removed knowledge from all other DSAs in environment "' + environmentName + '"');
        return process.nextTick(function(){callback();});
      } else {
        processingErrors = processingErrors.concat(err);
        return process.nextTick(function(){callback(processingErrors);});
      }
    });
  });
}

/**
 * Remove knowledge about DSA from all other DSAs in the environment
 * @param ldapClient
 * @param dsaKnowledge - the DSA knowledge to be removed from all other DSAs in the same environment
 * @param environmentName
 * @param globalKnowledgeDsa - true or false, whether to remove from global knowledge DSAs
 * @param initOthers - true or false, whether to init DSAs whose configuration is changed and whose status is "started"
 * @param callback
 */
function removeKnowledgeFromDsasInEnv(ldapClient, dsaKnowledge, environmentName, globalKnowledgeDsa, initOthers, callback) {
  var logger = ldapClient.logger;
  var prefix;
  if (globalKnowledgeDsa) {
    prefix = 'Remove knowledge about DSA "' + dsaKnowledge.name + '" from all other global knowledge DSAs in environment "' + environmentName + '"';
  } else {
    prefix = 'Remove knowledge about DSA "' + dsaKnowledge.name + '" from all other DSAs in environment "' + environmentName + '"';
  }

  if (initOthers) {
    logger.info(prefix + " and init DSAs that are started and whose configuration is changed");
  } else {
    logger.info(prefix);
  }

  var processingErrors = [];

  // list all dxagents in the environment
  ldapClient.listDxagents(environmentName, function(err, dxagents) {
    if (err) {
      logger.error(prefix + ': failed to get the dxagents in the environment, error is - ' + err.message);
      processingErrors = processingErrors.concat(err);
      return process.nextTick(function(){callback(processingErrors);});
    }

    if (dxagents.length === 0) {
      logger.info(prefix + ': no dxagent was found in the environment, nothing to be done');
      return process.nextTick(function(){callback();});
    }

    // go through the dxagents and process all the DSAs
    function iterateAllDxagents(index) {
      if (index === dxagents.length) {
        logger.info(prefix + ': processed all other DSAs, check log messages for possible issues');
        return process.nextTick(function(){callback(processingErrors);});
      }

      var currentDxagent = dxagents[index];
      // remove knowledge from all other DSAs for the current dxagent
      removeKnowledgeFromDsasInDxagent(ldapClient, dsaKnowledge, currentDxagent, environmentName, globalKnowledgeDsa, initOthers, function(err) {
        if (!err) {
          logger.info(prefix + ': successfully removed knowledge from DSAs for dxagent "' + currentDxagent.name + '"');
        } else {
          processingErrors = processingErrors.concat(err);
        }

        // process next dxagent
        iterateAllDxagents(index + 1);
      });
    }

    // start from the first dxagent
    iterateAllDxagents(0);
  });
}

/**
 * Remove knowledge from DSAs for the dxagent
 * @param ldapClient
 * @param dsaKnowledge - DSA knowledge to be removed from all other DSAs
 * @param dxagent
 * @param environmentName
 * @param globalKnowledgeDsa - true or false, whether to remove from global knowledge DSAs
 * @param initOthers - true or false, whether to init DSAs whose configuration is changed and whose status is "started"
 * @param callback
 */
function removeKnowledgeFromDsasInDxagent(ldapClient, dsaKnowledge, dxagent, environmentName, globalKnowledgeDsa, initOthers, callback) {
  var logger = ldapClient.logger;

  var prefixArgs;
  if (globalKnowledgeDsa) {
    prefixArgs = ['controllers.dxagents.prefix.removeKnowledgeFromAllGlobalKnowledgeDsasInDxagent', dsaKnowledge.name, dxagent.name, environmentName];
  } else {
    prefixArgs = ['controllers.dxagents.prefix.removeKnowledgeFromAllDsasInDxagent', dsaKnowledge.name, dxagent.name, environmentName];
  }

  if (initOthers) {
    logger.info(utils.i18nTranslate(prefixArgs) + " and init DSAs that are started and whose configuration is changed");
  } else {
    logger.info(utils.i18nTranslate(prefixArgs));
  }

  var processingErrors = [];
  var listDsasFunction;
  if (globalKnowledgeDsa) {
    listDsasFunction = ldapClient.listGlobalKnowledgeDsas;
  } else {
    listDsasFunction = ldapClient.listDsas;
  }

  // list all DSAs for the dxagent
  listDsasFunction.call(ldapClient, dxagent.name, environmentName, function(err, dsas) {
    if (err) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed to get DSAs for dxagent "' + dxagent.name + '" error is - ' + err.message);
      processingErrors = processingErrors.concat(err);
      return process.nextTick(function(){callback(processingErrors);});
    }

    if (dsas.length === 0) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA for dxagent "' + dxagent.name + '" was found');
      return process.nextTick(function(){callback();});
    }

    // iterate through all DSAs found
    function iterateAllDsas(dsaIndex) {
      if (dsaIndex === dsas.length) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': processed all DSAs for dxagent "' + dxagent.name + '", check log messages for possible issues');
        return process.nextTick(function(){callback(processingErrors);});
      }

      var dsa = dsas[dsaIndex];

      // check the DSA to see if it has the knowledge
      var index = findMatchingKnowledgeIndex(prefixArgs, logger, dsaKnowledge, dsa.config.knowledge);
      if (index !== -1) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': removing knowledge about DSA "' + dsaKnowledge.name + '" from DSA "' + dsa.name + '"');

        // remove knowledge
        dsa.config.knowledge.splice(index, 1);
        delete dsa.dsaPeers;

        // update the DSA both in directory and on dxagent host
        updateDsaInDirectoryAndDxagent(ldapClient, dsa, dxagent, environmentName, initOthers, function(err) {
          // when error happens, it is logged in updateDsaInDirectoryAndDxagent() function already
          if (!err) {
            logger.info(utils.i18nTranslate(prefixArgs) + ': successfully removed knowledge and updated DSA in directory and with dxagent');
          } else {
            processingErrors = processingErrors.concat(err);
          }

          // go to the next one
          iterateAllDsas(dsaIndex + 1);
        });
      } else {
        // go to the next one
        iterateAllDsas(dsaIndex + 1);
      }
    }

    // start from the first DSA
    iterateAllDsas(0);
  });
}

/**
 * reconcile every DSA in the environment:
 *
 * 1) check every DSA defined in directory. Create the DSA if it does not exist on dxagent host or update the DSA if the DSA
 *    on dxagent host has different configuration as that stored in directory.Also make sure all DSAs with global knowledge
 *    has knowledge about all DSAs with global knowledge.
 *
 * 2) delete DSAs on dxagent hosts when they are not defined in directory. Remove knowledge about the DSA deleted from all other
 *    DSAs in the same environment.
 */
dxagentController.reconcile = function() {
  var thisMoment = new Date();
  var logger = utilsLogger.createMetaLogger({id: 'Reconciliation started at - "' + thisMoment.toString() + '"'});
  var prefix = 'Reconciling every DSA with configuration defined in directory';
  if (config.reconciliationInitDsa) {
    logger.info(prefix + ' and init DSAs that are started and whose configuration is changed');
  } else {
    logger.info(prefix);
  }

  var processingErrors = [];

  // reconcile every DSA defined in directory, get the connection to the directory first
  ldap.acquireLdapClient(logger, function(err, ldapClient) {
    if (err) {
      logger.error(prefix + ': failed to connect to LDAP server, error is: ' + err.message);
      return dxagentController.emit('error');
    }
    // list all environments
    ldapClient.listEnvironments(function(err, envs) {
      if (err) {
        ldap.returnLdapClient(ldapClient);
        logger.error(prefix + ': failed to list environments, error is: ' + err.message);
        return dxagentController.emit('error');
      }
      // no environment exists yet
      if (!envs || envs.length === 0) {
        ldap.returnLdapClient(ldapClient);
        logger.info(prefix + ': no environment has been found, nothing to do');
        dxagentController.emit('finished');
        return;
      }
      // iterate through all environments
      function iterateAllEnvs(envIndex) {
        if (envs.length === envIndex) {
          ldap.returnLdapClient(ldapClient);
          if (processingErrors.length > 0) {
            logger.error(prefix + ': processed all DSAs in all environments with errors - ' + JSON.stringify(processingErrors));
            dxagentController.emit('error');
          } else {
            logger.info(prefix + ': processed all DSAs in all environments');
            dxagentController.emit('finished');
          }
          return;
        }
        // reconcile the environment
        var env = envs[envIndex];
        reconcileEnv(ldapClient, env.name, config.reconciliationInitDsa, function(err) {
          if (err) {
            processingErrors = processingErrors.concat(err);
          }
          // process the next one
          iterateAllEnvs(envIndex + 1);
        });
      }
      // start with the first environment
      iterateAllEnvs(0);
    });
  });
};

/**
 * Reconcile all DSAs in the named environment
 *
 * @param ldapClient
 * @param environmentName
 * @param init
 */
function reconcileEnv(ldapClient, environmentName, init, callback) {
  var logger = ldapClient.logger;
  var prefix = 'Reconciling every DSA with configuration defined in directory in environment "' + environmentName + '"';
  if (init) {
    logger.info(prefix + ' and init DSAs that are started and whose configuration is changed');
  } else {
    logger.info(prefix);
  }

  var processingErrors = [];

  // list all dxagents in the environment
  ldapClient.listDxagents(environmentName, function(err, dxagents) {
    if (err) {
      processingErrors.push(err);
      logger.error(prefix + ': failed to list dxagents, error is: ' + err.message);
      return process.nextTick(function(){callback(processingErrors);});
    }
    // no dxagent exists in the environment yet
    if (!dxagents || dxagents.length === 0) {
      logger.info(prefix + ': no dxagent has been found, abort');
      return process.nextTick(function(){callback();});
    }
    // iterate through all dxagents
    function iterateAllDxagents(dxagentIndex) {
      if (dxagents.length === dxagentIndex) {
        logger.info(prefix + ': processed all DSAs for all dxagents');
        return process.nextTick(function(){callback(processingErrors);});
      }
      // reconcile DSAs for the current dxagent
      var dxagent = dxagents[dxagentIndex];
      reconcileDxagent(ldapClient, dxagent, environmentName, init, function(err) {
        if (err) {
          processingErrors = processingErrors.concat(err);
        }
        reconcileDeletedDsasDxagent(ldapClient, dxagent, environmentName, init, function(err) {
          if (err) {
            processingErrors = processingErrors.concat(err);
          }
          // process the next dxagent
          iterateAllDxagents(dxagentIndex + 1);
        });
      });
    }
    // start with the first dxagent
    iterateAllDxagents(0);
  });
}

/**
 * Reconcile all DSAs for the named dxagent in the named environment
 *
 * @param ldapClient
 * @param dxagent
 * @param environmentName
 * @param init
 */
function reconcileDxagent(ldapClient, dxagent, environmentName, init, callback) {
  var logger = ldapClient.logger;
  var prefixArgs = ['controllers.dxagents.prefix.reconcileDxagent', dxagent.name, environmentName];
  if (init) {
    logger.info(utils.i18nTranslate(prefixArgs) + ' and init DSAs that are started and whose configuration is changed');
  } else {
    logger.info(utils.i18nTranslate(prefixArgs));
  }

  var processingErrors = [];

  // list all DSAs for the dxagent
  listDsas(prefixArgs, ldapClient, dxagent.name, environmentName, function(err, dsas) {
    if (err) {
      processingErrors.push(err);
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed to list DSAs, error is: ' + err.message);
      return process.nextTick(function(){callback(processingErrors);});
    }
    // no DSA exists for the dxagent yet
    if (!dsas || dsas.length === 0) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA has been found, abort');
      return process.nextTick(function(){callback();});
    }
    // iterate through all DSAs
    function iterateAllDsas(dsaIndex) {
      if (dsas.length === dsaIndex) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': processed all DSAs for the dxagent');
        return process.nextTick(function(){callback(processingErrors);});
      }
      var dsa = dsas[dsaIndex];
      // validate the knowledge setting of the DSA first
      validateKnowledge(ldapClient, dsa, dsa, environmentName, function(err, knowledgeAboutSelf) {
        if (err) {
          processingErrors = processingErrors.concat(err);
          logger.error(utils.i18nTranslate(prefixArgs) + ': failed to validate knowledge settings of DSA "' + dsa.name + '", error is: ' + err.message);
          // process the next DSA
          iterateAllDsas(dsaIndex + 1);
        } else {
          // reconcile the DSA
          reconcileDsa(ldapClient, dsa, knowledgeAboutSelf, dxagent, environmentName, init, init, function(err) {
            if (err) {
              processingErrors = processingErrors.concat(err);
            }
            // process the next DSA
            iterateAllDsas(dsaIndex + 1);
          });
        }
      });
    }
    // start with the first DSA
    iterateAllDsas(0);
  });
}

/**
 * Reconcile all DSAs deleted from directory but still exist on dxagent host for the named dxagent in the named environment
 *
 * @param ldapClient
 * @param dxagent
 * @param environmentName
 * @param init
 */
function reconcileDeletedDsasDxagent(ldapClient, dxagent, environmentName, init, callback) {
  var logger = ldapClient.logger;
  var prefix = 'Reconciling every DSA deleted from directory for dxagent "' + dxagent.name + '" in environment "' + environmentName + '"';
  if (init) {
    logger.info(prefix + ' and init DSAs that are started and whose configuration is changed');
  } else {
    logger.info(prefix);
  }

  var processingErrors = [];

  // list all DSAs that are on the dxagent host
  dxagentOps.getDxagentOperations(logger, ldapClient.locale).getAllDsas(dxagent, function(err, dsasFromDxagent) {
    if (err) {
      processingErrors.push(err);
      logger.error(prefix + ': failed to list DSAs on dxagent host, error is: ' + err.message);
      return process.nextTick(function(){callback(processingErrors);});
    }
    // no DSA exists for the dxagent yet
    if (!dsasFromDxagent || dsasFromDxagent.length === 0) {
      logger.info(prefix + ': no DSA has been found on dxagent host, abort');
      return process.nextTick(function(){callback();});
    }
    // iterate through all DSAs
    function iterateAllDsasFromDxagent(dsaIndex) {
      if (dsasFromDxagent.length === dsaIndex) {
        logger.info(prefix + ': processed all DSAs found on dxagent host');
        return process.nextTick(function(){callback(processingErrors);});
      }
      var dsa = dsasFromDxagent[dsaIndex];
      // check if the DSA exists in directory
      ldapClient.getDsa(dsa.name, dxagent.name, environmentName, function(err, dsaInDirectory) {
        if (err && err.statusCode && err.statusCode === 404) {
          // does not exist in directory, need reconciliation
          reconcileDsaDeleted(ldapClient, utils.getKnowledgeAboutSelf(dsa), dxagent, environmentName, init, 0, function(err) {
            if (err) {
              processingErrors = processingErrors.concat(err);
            }
            // process the next DSA
            iterateAllDsasFromDxagent(dsaIndex + 1);
          });
        } else if (err) {
          processingErrors = processingErrors.concat(err);
          logger.error(prefix + ': failed to check DSA "' + dsa.name + '" in directory, error is: ' + err.message);
          // process the next DSA
          iterateAllDsasFromDxagent(dsaIndex + 1);
        } else {
          // exist in directory, do nothing, process the next DSA
          iterateAllDsasFromDxagent(dsaIndex + 1);
        }
      });
    }
    // start with the first DSA
    iterateAllDsasFromDxagent(0);
  });
}

/**
 * Update the knowledge for ALL DSAs in the environment
 *
 * @param ldapClient
 * @param newKnowledge
 * @param existingKnowledge
 * @param globalKnowledge - if new knowledge is global
 * @param environmentName
 * @param initOthers
 * @param callback(processingErrors)
 */
function updateKnowledgeForDsasInEnv(ldapClient, newKnowledge, existingKnowledge, globalKnowledge, environmentName, initOthers, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;
  var prefixArgs = ['controllers.dxagents.prefix.updateKnowledgeForDsasInEnv', newKnowledge.name, environmentName];

  if (initOthers) {
    logger.info(utils.i18nTranslate(prefixArgs) + ': init DSAs that are started and whose configuration is changed');
  } else {
    logger.info(utils.i18nTranslate(prefixArgs));
  }

  var processingErrors = [];

  // list all dxagents in the environment
  ldapClient.listDxagents(environmentName, function(err, dxagents) {
    if (err) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed to get the dxagents in the environment, error is - ' + err.message);
      processingErrors.push(err);
      return process.nextTick(function(){callback(processingErrors);});
    }

    if (!dxagents || dxagents.length === 0) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': no dxagent has been found in the environment, nothing else to be done');
      return process.nextTick(function(){callback();});
    }

    // go through the dxagents and process the DSAs
    function iterateAllDxagents(index) {
      if (index === dxagents.length) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': processed all DSAs, check log messages for possible issues');
        return process.nextTick(function(){callback(processingErrors);});
      }

      var currentDxagent = dxagents[index];

      updateKnowledgeForDsasInDxagent(prefixArgs, ldapClient, newKnowledge, existingKnowledge, globalKnowledge, currentDxagent, environmentName, initOthers, function(err) {
        if (!err || err.length === 0) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': successfully processed all DSAs on dxagent "' + currentDxagent.name + '"');
        } else {
          processingErrors = processingErrors.concat(err);
        }

        // process next dxagent
        iterateAllDxagents(index + 1);
      });
    }

    // start from the first dxagent
    iterateAllDxagents(0);
  });
}

/**
 * Update the knowledge for all DSAs on the dxagent host
 *
 * @param prefixArgs
 * @param ldapClient
 * @param newKnowledge
 * @param existingKnowledge
 * @param globalKnowledge - if new knowledege is global
 * @param dxagent
 * @param environmentName
 * @param initOthers
 * @param callback
 */
function updateKnowledgeForDsasInDxagent(prefixArgs, ldapClient, newKnowledge, existingKnowledge, globalKnowledge, dxagent, environmentName, initOthers, callback) {
  var logger = ldapClient.logger;
  var locale = ldapClient.locale;

  logger.info(utils.i18nTranslate(prefixArgs) + ': processing DSAs on dxagent "' + dxagent.name + '"');

  var processingErrors = [];

  // list all DSAs for the dxagent
  ldapClient.listDsas(dxagent.name, environmentName, function(err, dsas) {
    if (err) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed to list DSAs for dxagent "' + dxagent.name + '" error is - ' + err.message);
      processingErrors.push(err);
      return process.nextTick(function(){callback(processingErrors);});
    }

    if (!dsas || dsas.length === 0) {
      logger.info(utils.i18nTranslate(prefixArgs) + ': no DSA for dxagent "' + dxagent.name + '" has been found');
      return process.nextTick(function(){callback();});
    }

    // iterate through all DSAs found
    function iterateAllDsas(dsaIndex) {
      if (dsaIndex === dsas.length) {
        logger.info(utils.i18nTranslate(prefixArgs) + ': processed all DSAs for dxagent "' + dxagent.name + '", check log messages for possible issues');
        return process.nextTick(function(){callback(processingErrors);});
      }

      var dsa = dsas[dsaIndex];
      var needUpdate = false;
      var existingKnowledgeIndex = -1; // assume not in the knowledge list by default, if existingKnowledge is null, it means not in the list
      if (existingKnowledge) {
        existingKnowledgeIndex = findMatchingKnowledgeIndex(prefixArgs, logger, existingKnowledge, dsa.config.knowledge);
      }

      // we found the existing knowledge in the DSA's knowledge list
      if (existingKnowledgeIndex !== -1) {
        // if DSA is having global knowledge
        if (dsa.globalKnowledge) {
          // new knowledge is global as well
          if (globalKnowledge) {
            // update the knowledge if they are different
            if (!(utils.compareDsaKnowledge(newKnowledge, dsa.config.knowledge[existingKnowledgeIndex], logger))) {
              dsa.config.knowledge[existingKnowledgeIndex] = newKnowledge;
              needUpdate = true;
            }
          } else {
            // new knowledge is not global, remove it from the DSA
            dsa.config.knowledge.splice(existingKnowledgeIndex, 1);
            needUpdate = true;
          }
        } else {
          // DSA is not global knowledge DSA, update if they are different
          if (!(utils.compareDsaKnowledge(newKnowledge, dsa.config.knowledge[existingKnowledgeIndex], logger))) {
            dsa.config.knowledge[existingKnowledgeIndex] = newKnowledge;
            needUpdate = true;
          }
        }
      } else {
        // existing knowledge is not included in the knowledge list of the DSA
        // add the new knowledge if it is global and the DSA is having global knowledge
        if (globalKnowledge && dsa.globalKnowledge) {
          dsa.config.knowledge.push(newKnowledge);
          needUpdate = true;
        }
      }

      if (needUpdate) {
        // update the DSA both in directory and on dxagent host
        updateDsaInDirectoryAndDxagent(ldapClient, dsa, dxagent, environmentName, initOthers, function(err) {
          // when error happens, it is logged in updateDsaInDirectoryAndDxagent() function already
          if (!err) {
            logger.info(utils.i18nTranslate(prefixArgs) + ': successfully updated knowledge for DSA. DSA updated in directory and on dxagent host');
          } else {
            processingErrors = processingErrors.concat(err);
          }
          // go to the next one
          iterateAllDsas(dsaIndex + 1);
        });
      } else {
        // go to the next one
        iterateAllDsas(dsaIndex + 1);
      }
    }

    // start from the first DSA
    iterateAllDsas(0);
  });
}

/**
 * Makeing an direct API call to the named dxagent
 */
dxagentController.callDxagent = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.dxagents.prefix.callDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  logger.debug(utils.i18nTranslate(prefixArgs) + ': HTTP request method is "' + req.method + '"');
  logger.debug(utils.i18nTranslate(prefixArgs) + ': HTTP request url is "' + req.url + '"');

  ldap.acquireLdapClient(logger, req.getLocale(), function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    // get the dxagent first
    ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, function(err, currentDxagent) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      }

      // formulate the dxagent path, we should find the following string in the URL
      var dxagentNameString = '/dxagents/' + encodeURIComponent(req.params.dxagentName);
      var dxagentNameIndex = req.url.indexOf(dxagentNameString);

      if (dxagentNameIndex === -1 || dxagentNameIndex + dxagentNameString.length >= req.url.length) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': invalid request URL "' + req.url + '"');
        return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.serverOperationFailed'));
      }

      var path = dxagentOps.dxagentApiPath + req.url.substr(dxagentNameIndex + dxagentNameString.length);

      var requestBody;
      if (req.method.toUpperCase() !== 'DELETE' && req.body) {
        try {
          requestBody = JSON.stringify(req.body);
          logger.debug(utils.i18nTranslate(prefixArgs) + ': stringified HTTP request body is "' + requestBody + '"');
        }
        catch (error) {
          logger.error(utils.i18nTranslate(prefixArgs) + ': failed to convert request body into string, error is - ' + error.message + '"');
          return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.invalidRequestBody', 400));
        }
      }

      var headers;
      if (req.headers) {
        headers = req.headers;
        delete headers.host;
        delete headers['user-agent'];
      } else {
        headers = {
          "Accept": "application/json",
          "Content-Type": "application/json",
          'Accept-Language': req.getLocale()
        };
      }

      try {
        logger.debug(utils.i18nTranslate(prefixArgs) + ': HTTP request headers to be sent are "' + JSON.stringify(headers) + '"');
      } catch (error) {}

      dxagentOps.getDxagentOperations(logger).httpToDxagent(prefixArgs, logger, req.getLocale(), currentDxagent, req.method, (requestBody ? requestBody : null), path, headers, (req.method.toUpperCase() !== 'DELETE'), function(err, data, statusCode) {
        if (err) {
          return utils.sendErrorResponse(res, err);
        }
        utils.sendJsonResponse(res, statusCode, data);
      });
    });
  });
};

dxagentController.removeKnowledgeFromDsasInEnv = removeKnowledgeFromDsasInEnv;
dxagentController.reconcileEnv = reconcileEnv;
dxagentController.dsaNameRegExp = dsaNameRegExp;
dxagentController.updateKnowledgeForDsasInEnv = updateKnowledgeForDsasInEnv;

module.exports = dxagentController;

/**
 * List of DSA maintenance tasks in the format of a function with the following function signature
 * function dsaTaskFunction(logger, dsa, dxagent, environmentName, ldapClient, callback)
 */
var dsaMaintenanceTasks = [];
dsaMaintenanceTasks.push(getNewAlarmMessagesDsa);

/**
 * List of maintenance tasks for the dxagent in the format of a function with the following function signature
 * function dxagentTaskFunction(logger, dxagent, environmentName, ldapClient, callback)
 */
var dxagentMaintenanceTasks = [];
dxagentMaintenanceTasks.push(addServerCaCertificatePemToDxagent);
dxagentMaintenanceTasks.push(performMaintenanceTasksForAllMonitoredDsasOnDxagent);

if (config.maintenanceTaskInterval && Number.isInteger(config.maintenanceTaskInterval) && config.maintenanceTaskInterval >= 1) {
  utilsLogger.info('Schedule running maintanence tasks every ' + config.maintenanceTaskInterval + ' minute(s)');
  // schedule an immediate run of maintanence tasks
  setImmediate(function() {
    performMaintenanceTasks(function(){});
  });
} else {
  utilsLogger.warn('Not scheduling the running of maintanence tasks');
}

