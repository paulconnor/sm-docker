/**
 * Contains customized configuration options.
 * This file is preserved on upgrade.
 * See config-scim-default.js for default configuration options.
 */
const winston = require('winston');
const path = require('path');

module.exports = {};
