const config = require('../utils/config-index');
const scimInstance = require('../utils/scim-instance-schema.json');
const scimResourceType = require('../utils/scim-resource-type-schema.json');
const scimSchema = require('../utils/scim-schema-schema.json');
const alarmSchema = require('../controllers/alarm-schema.json');
const statSchema = require('../controllers/stats-schema.json');
const emailRecipientsSchema = require('../controllers/email-recipients-schema.json');
const emailSmtpSchema = require('../controllers/email-smtp-schema.json');
const objectClassSchema = require('../utils/object-class-schema.json');
const path = require('path');
const swaggerJSDoc = require('swagger-jsdoc');
var swaggerSpec = null;

/**
 * Return swagger doc specification
 *
 * @param req
 * @param res
 * @returns
 */
function getApiDoc(req, res) {
  if (swaggerSpec) {
    return res.json(swaggerSpec);
  }

  //swagger definition
  var swaggerDefinition = {
    info: {
      title: 'Management UI REST API',
      version: '0.1',
      description: 'Directory Management UI REST API Specifications',
    },
    security: [
      { basicAuth: [] }
    ],
    produces: ['application/json'],
    host: req.hostname + ':' + config.port,
    basePath: config.apiPath,
    schemes: [req.protocol]
  };

  // options for the swagger docs
  var options = {
    // import swaggerDefinitions
    swaggerDefinition: swaggerDefinition,
    // path to the API docs
    apis: [path.join(__dirname, '..', 'routes', 'api-index.js')]
  };

  // initialize swagger-jsdoc
  swaggerSpec = swaggerJSDoc(options);
  swaggerSpec.definitions.ScimInstance = scimInstance;
  swaggerSpec.definitions.ScimResourceType = scimResourceType;
  swaggerSpec.definitions.ScimSchema = scimSchema;
  swaggerSpec.definitions.AlarmSchema = alarmSchema;
  swaggerSpec.definitions.StatsSchema = statSchema;
  swaggerSpec.definitions.ObjectClass = objectClassSchema;
  swaggerSpec.definitions.emailRecipientsSchema = emailRecipientsSchema;
  swaggerSpec.definitions.emailSmtpSchema = emailSmtpSchema;
  res.json(swaggerSpec);
}

module.exports.getApiDoc = getApiDoc;