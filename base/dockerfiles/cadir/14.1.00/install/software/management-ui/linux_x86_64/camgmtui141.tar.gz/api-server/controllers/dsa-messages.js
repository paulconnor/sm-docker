const ldap = require('../models/ldap-operations');
const utilsLogger = require('../utils/logger');
const utils = require('../utils/utils');
const fs = require('fs');
const EventEmitter = require('events').EventEmitter;
const Validator = require('jsonschema').Validator;
const jsonValidator = new Validator();
const async = require('async');
const ldap2date = require('ldap2date');
const emailNotification = require('./email-notification');

var dsaMessageController = {};

utilsLogger.info('Alarm schema file is - "' + __dirname + '/alarm-schema.json"');
// if this fails, it will throw and will terminate the program
const alarmJsonSchema = JSON.parse(fs.readFileSync(__dirname + '/alarm-schema.json'));

utilsLogger.info('Stats schema file is - "' + __dirname + '/stats-schema.json"');
// if this fails, it will throw and will terminate the program
const statsJsonSchema = JSON.parse(fs.readFileSync(__dirname + '/stats-schema.json'));

function createDsaAlarmObject(alarmMessage) {
  var alarmObject = {};
  alarmObject.time = utils.dsaTimestampToLdap(alarmMessage['dxserver-monitor'].time);
  alarmObject.messageId = alarmMessage['dxserver-monitor']['message-id'];
  alarmObject.name = alarmObject.messageId + ':' + alarmObject.time;
  alarmObject.host =  alarmMessage['dxserver-monitor']['host-name'];
  alarmObject.id = alarmMessage['dxserver-monitor'].alarm.id;
  alarmObject.type = alarmMessage['dxserver-monitor'].alarm.type;
  alarmObject.message = alarmMessage['dxserver-monitor'].alarm.message;
  return alarmObject;
}

function createDsaStatsObject(statsMessage) {
  var statsObject = {};
  try {
    statsObject.stats = JSON.stringify(statsMessage['dxserver-monitor'].stats);
  } catch (error) {
    // this should never happen after the json message has been validated with the schema
  }
  statsObject.time = utils.dsaTimestampToLdap(statsMessage['dxserver-monitor'].time);
  statsObject.messageId = statsMessage['dxserver-monitor']['message-id'];
  statsObject.name = statsObject.messageId + ':' + statsObject.time;
  statsObject.host =  statsMessage['dxserver-monitor']['host-name'];
  return statsObject;
}

const dsaMessageTypes = {};

dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName] = {
  jsonSchema: alarmJsonSchema,
  createFunction: createDsaAlarmObject,
  storeFunctionName: 'storeDsaAlarm',
  listFunction: listAlarmsInEnvDxagentDsa,
  deleteFunction: deleteAlarmInEnvDxagentDsa,
  validateQueryParamsFunction: validateAlarmsQueryParams,
  emitter: new EventEmitter(),
  messageType: utils.managementUiLdapConfig.uiAlarmContainerName
};

dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName] = {
  jsonSchema: statsJsonSchema,
  createFunction: createDsaStatsObject,
  storeFunctionName: 'storeDsaStats',
  listFunction: listStatsInEnvDxagentDsa,
  deleteFunction: deleteStatsInEnvDxagentDsa,
  validateQueryParamsFunction: validateStatsQueryParams,
  emitter: new EventEmitter(),
  messageType: utils.managementUiLdapConfig.uiStatsContainerName
};

const alarmTypes = ['critical', 'caution', 'information'];

/**
 * Receives a DSA message and stores it in directory
 */
function putDsaMessage(prefixArgs, dsaMessageType, req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  logger.info(utils.i18nTranslate(prefixArgs));

  // check the parameters
  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  // check the existence of request body
  if (!req.body) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  // check DSA message format by validating the json object against the json schema
  var validateResults = jsonValidator.validate(req.body, dsaMessageType.jsonSchema);
  if (validateResults.errors.length !== 0) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.getValidationErrorMessage(validateResults.errors));
    return utils.sendErrorResponse(res, utils.createAPIError(utils.i18nTranslate(locale, prefixArgs), utils.getValidationErrorMessage(validateResults.errors, locale), 400));
  }

  logger.info(utils.i18nTranslate(prefixArgs + ': validated DSA message successfully against schema'));

  // check the DSA name in the DSA message to make sure it is the correct DSA
  if (req.params.dsaName.toUpperCase() !== req.body['dxserver-monitor']['dsa-name'].toUpperCase()) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.invalidRequestFormat'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.invalidRequestFormat', 400));
  }

  // get the LDAP client first
  ldap.acquireLdapClient(logger, locale, function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    var dsaMessageObject = {};
    /**
     * Use async library to execute the tasks sequentially
     */
    async.series([
      // check that we have the dsa
      function (callback) {
        ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }

          // dsa exists, this means the dxagent and environment exist as well
          logger.info(utils.i18nTranslate(prefixArgs) + ': dsa exists');

          // now process the DSA message received
          dsaMessageObject = dsaMessageType.createFunction(req.body);

          // emit the event for SSE
          dsaMessageType.emitter.emit('message', {dsaName: req.params.dsaName, dxagentName: req.params.dxagentName, environmentName: req.params.environmentName, 'messageType': dsaMessageType.messageType}, dsaMessageObject);

          // if it is an alarm message, we may need to send email notifications.
          if (dsaMessageType.messageType === utils.managementUiLdapConfig.uiAlarmContainerName) {
            var alarm = {};
            Object.assign(alarm, dsaMessageObject, {host: req.params.dxagentName, dsa: req.params.dsaName});
            // schedule the sending of email to run after I/O events' callbacks are cleared
            setImmediate(emailNotification.sendEmail, req.params.environmentName, alarm);
          }

          logger.debug(utils.i18nTranslate(prefixArgs) + ': DSA message object to be stored - "' + JSON.stringify(dsaMessageObject) + '"');
          return process.nextTick(function () {callback();});
        });
      },
      // store the DSA message object in directory
      function (callback) {
        ldapClient[dsaMessageType.storeFunctionName](req.params.dsaName, req.params.dxagentName, req.params.environmentName, dsaMessageObject, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          } else {
            return process.nextTick(function () {callback();});
          }
        });
      }
    ],
    // callback function that will be called if any function returns an error, or when all functions succeeded, called with an array of results
    function(err, results) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 200);
      }
    });
  });
}

/**
 * Validate the query params for retrieving alarms messages
 * Returns an error for failure
 */
function validateAlarmsQueryParams(logger, prefixArgs, locale, req, filterParams) {
  if (req.query) {
    // from timestamp
    if (req.query.from) {
      if (!(ldap2date.parse(req.query.from))) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.from]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.from], 400);
      }
      filterParams.from = req.query.from;
    }
    // to timestamp
    if (req.query.to) {
      if (!(ldap2date.parse(req.query.to))) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.to]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.to], 400);
      }
      filterParams.to = req.query.to;
    }
    // alarm type
    if (req.query.type) {
      if (alarmTypes.find(function(oneType) {
        return oneType === req.query.type;
      })) {
        filterParams.type = req.query.type;
      } else {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.type]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.type], 400);
      }
    }
    // size of each paged results
    if (req.query.size) {
      var parsedSize = parseInt(req.query.size);
      if (!isNaN(parsedSize) && parsedSize > 0) {
        filterParams.size = parsedSize;
      } else {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.size]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.size], 400);
      }
    }
    // pagedResultsCookie needs to be base64 encoded
    if (req.query.pagedResultsCookie) {
      // try decode it
      try {
        filterParams.pagedResultsCookie = new Buffer(req.query.pagedResultsCookie, 'base64');
      } catch (error) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.pagedResultsCookie]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.pagedResultsCookie], 400);
      }
    }
  }
}

/**
 * Validate the query params for retrieving stats messages
 * Returns an error for failure
 */
function validateStatsQueryParams(logger, prefixArgs, locale, req, filterParams) {
  if (req.query) {
    // from timestamp
    if (req.query.from) {
      if (!(ldap2date.parse(req.query.from))) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.from]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.from], 400);
      }
      filterParams.from = req.query.from;
    }
    // to timestamp
    if (req.query.to) {
      if (!(ldap2date.parse(req.query.to))) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.to]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.to], 400);
      }
      filterParams.to = req.query.to;
    }
    // size of each paged results
    if (req.query.size) {
      var parsedSize = parseInt(req.query.size);
      if (!isNaN(parsedSize) && parsedSize > 0) {
        filterParams.size = parsedSize;
      } else {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.size]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.size], 400);
      }
    }
    // pagedResultsCookie needs to be base64 encoded
    if (req.query.pagedResultsCookie) {
      // try decode it
      try {
        filterParams.pagedResultsCookie = new Buffer(req.query.pagedResultsCookie, 'base64');
      } catch (error) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate(['errors.invalidQueryValue', req.query.pagedResultsCookie]));
        return utils.createLocalizedAPIError(locale, prefixArgs, ['errors.invalidQueryValue', req.query.pagedResultsCookie], 400);
      }
    }
  }
}

/**
 * Receives an alarm message and stores it in directory
 */
dsaMessageController.putAlarm = function (req, res) {
  var prefixArgs = ['controllers.dsaMessages.prefix.putAlarm', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  putDsaMessage(prefixArgs, dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Receives an stats message and stores it in directory
 */
dsaMessageController.putStats = function (req, res) {
  var prefixArgs = ['controllers.dsaMessages.prefix.putStats', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  putDsaMessage(prefixArgs, dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Set up the SSE channel
 */
function setUpServerSentEvents(req, res) {
  var logger = this.logger;
  var prefixArgs = this.prefixArgs;
  var emitter = this.emitter;

  logger.info(utils.i18nTranslate(prefixArgs) + ': setting up the SSE channel ...');

  // message id starts from 0
  var id = 0;
  // set socket idle timeout to be one day
  req.socket.setTimeout(24*3600*1000);

  // send headers for event-stream connection
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });
  res.write('\n');
  res.flush();

  // register event listener
  emitter.on('message', messageListener);

  // event listener callback
  function messageListener(metadata, message) {
    if (metadata && message) {
      if (req.params.environmentName && req.params.environmentName !== metadata.environmentName) {
        return;
      }
      if (req.params.dxagentName && req.params.dxagentName !== metadata.dxagentName) {
        return;
      }
      if (req.params.dsaName && req.params.dsaName.toUpperCase() !== metadata.dsaName.toUpperCase()) {
        return;
      }

      // construct the event object to send
      var eventObject = {};
      eventObject['dxagent-name'] = metadata.dxagentName;
      eventObject.dsas = [];
      var oneDsaMessage = {};
      oneDsaMessage['dsa-name'] = metadata.dsaName;
      oneDsaMessage[metadata.messageType] = [];
      oneDsaMessage[metadata.messageType].push(message);
      eventObject.dsas.push(oneDsaMessage);

      // send the event
      id++;
      res.write('id: ' + id + '\n');
      res.write("data: " + JSON.stringify(eventObject) + '\n\n'); // Note the extra newline
      res.flush();
    }
  }

  // The 'close' event - remove the event listener
  req.on("close", function() {
    logger.info(utils.i18nTranslate(prefixArgs) + ': SSE channel closed');
    emitter.removeListener('message', messageListener);
  });
}

/**
 * Check the existence of environment, dxagent or dsa depending on the params in req
 */
function checkExistenceOfEnvDxagentDsa(ldapClient, req, callback) {
  if (req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.getDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, callback);
  }
  if (req.params.dxagentName && req.params.environmentName) {
    return ldapClient.getDxagent(req.params.dxagentName, req.params.environmentName, callback);
  }
  if (req.params.environmentName) {
    return ldapClient.getEnvironment(req.params.environmentName, callback);
  }
}

/**
 * List the alarms object in environment, dxagent or dsa depending on the params in req
 */
function listAlarmsInEnvDxagentDsa(ldapClient, req, filterParams, callback) {
  if (req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.listAlarmsDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, filterParams, callback);
  }
  if (req.params.dxagentName && req.params.environmentName) {
    return ldapClient.listAlarmsDxagent(req.params.dxagentName, req.params.environmentName, filterParams, callback);
  }
  if (req.params.environmentName) {
    return ldapClient.listAlarmsEnvironment(req.params.environmentName, filterParams, callback);
  }
}

/**
 * List the stats object in environment, dxagent or dsa depending on the params in req
 */
function listStatsInEnvDxagentDsa(ldapClient, req, filterParams, callback) {
  if (req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.listStatsDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, filterParams, callback);
  }
  if (req.params.dxagentName && req.params.environmentName) {
    return ldapClient.listStatsDxagent(req.params.dxagentName, req.params.environmentName, filterParams, callback);
  }
  if (req.params.environmentName) {
    return ldapClient.listStatsEnvironment(req.params.environmentName, filterParams, callback);
  }
}

/**
 * Retrieves dsa messages
 */
function getDsaMessages(dsaMessageType, req, res) {
  var logger = this.logger;
  var prefixArgs = this.prefixArgs;
  var locale = this.locale;

  var sse = false;
  var filterParams = {};

  // check to see if we are doing SSE
  if (req.query && req.query.notification && (req.query.notification.toUpperCase() === 'TRUE' || req.query.notification === '1')) {
    sse = true;
    logger.info(utils.i18nTranslate(prefixArgs) + ': openning an SSE channel ...');
  } else {
    // validate the query parameters
    var validateError = dsaMessageType.validateQueryParamsFunction(logger, prefixArgs, locale, req, filterParams);
    if (validateError) {
      return utils.sendErrorResponse(res, validateError);
    }
  }

  // get the LDAP client first
  ldap.acquireLdapClient(logger, locale, function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    var searchResults;
    /**
     * Use async library to execute the tasks sequentially
     */
    async.series([
      // check that we have the environment / dxagent / dsa
      function (callback) {
        checkExistenceOfEnvDxagentDsa(ldapClient, req, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // environment/dxagent/dsa exists
          logger.info(utils.i18nTranslate(prefixArgs) + ': environment/daxagent/dsa exists');
          return process.nextTick(function () {callback();});
        });
      },
      // search for dsa message in directory or do the SSE
      function (callback) {
        if (sse) {
          // nothing to do here
          return process.nextTick(function () {callback();});
        } else {
          dsaMessageType.listFunction(ldapClient, req, filterParams, function(err, results) {
            if (err) {
              return process.nextTick(function () {callback(err);});
            } else {
              searchResults = results;
              return process.nextTick(function () {callback();});
            }
          });
        }
      }
    ],
    // callback function that will be called if any function returns an error, or when all functions succeeded, called with an array of results
    function(err) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        if (sse) {
          var setUpSseFunction = setUpServerSentEvents.bind({'logger': logger, 'prefixArgs': prefixArgs, 'emitter': dsaMessageType.emitter});
          return setUpSseFunction(req, res);
        } else {
          return utils.sendJsonResponse(res, 200, searchResults);
        }
      }
    });
  });
}

/**
 * Retrieves alarm messages for the UI environment
 */
dsaMessageController.getAlarmsEnvironment = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.getAlarmsEnvironment', req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingEnvName', 400));
  }

  getDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Retrieves alarm messages for the dxagent in the environment
 */
dsaMessageController.getAlarmsDxagent = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.getAlarmsDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName || !req.params.dxagentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  getDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Retrieves alarm messages for the DSA on the dxagent in the environment
 */
dsaMessageController.getAlarmsDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.getAlarmsDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  getDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Retrieves stats messages for the UI environment
 */
dsaMessageController.getStatsEnvironment = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.getStatsEnvironment', req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingEnvName', 400));
  }

  getDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Retrieves stats messages for the dxagent in the environment
 */
dsaMessageController.getStatsDxagent = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.getStatsDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName || !req.params.dxagentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  getDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Retrieves stats messages for the DSA on the dxagent in the environment
 */
dsaMessageController.getStatsDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.getStatsDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  getDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Delete alarm(s) in environment, dxagent or dsa depending on the params in req
 */
function deleteAlarmInEnvDxagentDsa(ldapClient, req, callback) {
  if (req.params.alarmName && req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.deleteOneAlarm(req.params.alarmName, req.params.dsaName, req.params.dxagentName, req.params.environmentName, callback);
  }
  if (req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.deleteAlarmsDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, true, callback);
  }
  if (req.params.dxagentName && req.params.environmentName) {
    return ldapClient.deleteAlarmsDxagent(req.params.dxagentName, req.params.environmentName, true, callback);
  }
  if (req.params.environmentName) {
    return ldapClient.deleteAlarmsEnvironment(req.params.environmentName, true, callback);
  }
}

/**
 * Delete stats in environment, dxagent or dsa depending on the params in req
 */
function deleteStatsInEnvDxagentDsa(ldapClient, req, callback) {
  if (req.params.statsName && req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.deleteOneStats(req.params.statsName, req.params.dsaName, req.params.dxagentName, req.params.environmentName, callback);
  }
  if (req.params.dsaName && req.params.dxagentName && req.params.environmentName) {
    return ldapClient.deleteStatsDsa(req.params.dsaName, req.params.dxagentName, req.params.environmentName, callback);
  }
  if (req.params.dxagentName && req.params.environmentName) {
    return ldapClient.deleteStatsDxagent(req.params.dxagentName, req.params.environmentName, callback);
  }
  if (req.params.environmentName) {
    return ldapClient.deleteStatsEnvironment(req.params.environmentName, callback);
  }
}

/**
 * Delete all dsa messages (message containers) at different levels
 */
function deleteDsaMessages(dsaMessageType, req, res) {
  var logger = this.logger;
  var prefixArgs = this.prefixArgs;
  var locale = this.locale;

  // get the LDAP client first
  ldap.acquireLdapClient(logger, locale, function(err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }
    /**
     * Use async library to execute the tasks sequentially
     */
    async.series([
      // check that we have the environment / dxagent / dsa
      function (callback) {
        checkExistenceOfEnvDxagentDsa(ldapClient, req, function(err) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          // environment/dxagent/dsa exists
          logger.info(utils.i18nTranslate(prefixArgs) + ': environment/daxagent/dsa exists');
          return process.nextTick(function () {callback();});
        });
      },
      // delete the containers
      function (callback) {
        dsaMessageType.deleteFunction(ldapClient, req, function(err) {
          return process.nextTick(function () {callback(err);});
        });
      }
    ],
    // callback function that will be called if any function returns an error, or when all functions succeeded, called with an array of results
    function(err) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return utils.sendErrorResponse(res, err);
      } else {
        return utils.sendJsonResponse(res, 204);
      }
    });
  });
}

/**
 * Delete all alarm messages for the UI environment
 */
dsaMessageController.deleteAlarmsEnvironment = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteAlarmsEnvironment', req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingEnvName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Delete all alarm messages for the dxagent in the environment
 */
dsaMessageController.deleteAlarmsDxagent = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteAlarmsDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName || !req.params.dxagentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Delete all alarm messages for the DSA on the dxagent in the environment
 */
dsaMessageController.deleteAlarmsDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteAlarmsDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Delete all stats messages for the UI environment
 */
dsaMessageController.deleteStatsEnvironment = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteStatsEnvironment', req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingEnvName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Delete all stats messages for the dxagent in the environment
 */
dsaMessageController.deleteStatsDxagent = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteStatsDxagent', req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.environmentName || !req.params.dxagentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Delete all stats messages for the DSA on the dxagent in the environment
 */
dsaMessageController.deleteStatsDsa = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteStatsDsa', req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

/**
 * Delete one alarm message for the DSA on the dxagent in the environment
 */
dsaMessageController.deleteOneAlarm = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteOneAlarm', req.params.alarmName, req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.alarmName || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], req, res);
};

/**
 * Delete one stats message for the DSA on the dxagent in the environment
 */
dsaMessageController.deleteOneStats = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var locale = req.getLocale();
  var prefixArgs = ['controllers.dsaMessages.prefix.deleteOneStats', req.params.statsName, req.params.dsaName, req.params.dxagentName, req.params.environmentName];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.statsName || !req.params.dsaName || !req.params.dxagentName || !req.params.environmentName) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingEnvNameOrDxagentNameOrDsaName'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingEnvNameOrDxagentNameOrDsaName', 400));
  }

  deleteDsaMessages.bind({'logger': logger, 'locale': locale, 'prefixArgs': prefixArgs})(dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], req, res);
};

dsaMessageController.alarmMessageType = dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName];
dsaMessageController.statsMessageType = dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName];

module.exports = dsaMessageController;