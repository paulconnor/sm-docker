/**
 * Default configuration options
 * Please do not modify this file. Add any custom values to config.js instead.
 */
const winston = require('winston');
const path = require('path');

/**
 * REST API path
 */
module.exports.apiPath = '/ca/api/dxmanagement/v0.1';

/**
 * Reconciliation failure code
 */
module.exports.reconciliationFailure = 560;

/**
 * Init DSAs during reconciliation
 */
module.exports.reconciliationInitDsa = true;

/**
 * Configuration for running node.js web server on HTTPS
 */
module.exports.sslConfig = {
  key: path.join(__dirname, 'api-server', 'certs', 'webservercert.key'),
  cert: path.join(__dirname, 'api-server', 'certs', 'webservercert.pem'),
  secureProtocol: 'TLSv1_2_method',
  ciphers: 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256'
};

/**
 * The certificate file of the Certificate Authority that has issued the server certificate for this node js server
 */
module.exports.caCertificateFile = path.join(__dirname, 'CA', 'certs', 'ca.pem');

/**
 * Port number to run HTTP/HTTPS server on
 */
module.exports.port = 3000;

/**
 * Configuration for auto cleaning up of files
 */
module.exports.fileCleanupConfig = {
  fileAgeInMinutes: 60, // the age of the file in minutes when it is eligible for cleaning up
  cleanupIntervalInMinutes: 60, // the interval in minutes between each clean up run
  folders: [path.join(__dirname, 'upload'), path.join(__dirname, 'public', 'download')] // list of folders from where files need to be cleaned up
};

/**
 * Other cookie options
 */
module.exports.cookieConfig = {
  path: '/',
  httpOnly: false
};

/**
 * name of the cookie for the logged in user
 */
module.exports.loggedInUserName = 'loggedInUsername';

/**
 * cookie-session configuration
 */
module.exports.cookieSessionConfig = {
  name: 'session', // don't change this
  keys: ['A78DC5C7FC9982B7E951B8DE074967B51185CA0BCB0F90B50403F5068A278606', '3E9EB9FCBE14E3B71F02CB8BAB1BE8A200AF65257C3BED3FC8A7E74801A67102', '1A675D57923AA2993F532CCFCD735CCC6AF9B9817B5289261BFA3ECDA8657036'],

  // no maxAge makes the cookie a session cookie
  //maxAge: 3600000,
  path: '/',
  //secure: true, //false by default for HTTP, true by default for HTTPS
  signed: true,
  httpOnly: true
};

/**
 * winston logger configuration
 */
module.exports.winstonLoggerConfig = {
  emitError: true,
  config: {
    transports: [
      new winston.transports.File({
        level: 'info',
        filename: path.join(__dirname, 'logs', 'apps.log'),
        handleExceptions: true,
        humanReadableUnhandledException: true,
        json: true,
        maxsize: 100000000,
        maxFiles: 100,
        colorize: false
      }),

      new winston.transports.Console({
        level: 'info',
        handleExceptions: true,
        humanReadableUnhandledException: true,
        json: false,
        colorize: true
      })
    ],

    exitOnError: true
  }
};

/**
 * Split every certificate into separate array item
 */
var bundle = [];
try {
  var trusted = require('fs').readFileSync(path.join(__dirname, '..', 'dxserver', 'config', 'ssld', 'trusted.pem'), 'utf8');
  trusted = trusted ? trusted.split('\n') : [];
  var cert = [];
  trusted.forEach(function(line) {
    cert.push(line);
    if (line.match(/-----END CERTIFICATE-----/)) {
      bundle.push(cert.join('\n'));
      cert = [];
    }
  });
} catch (error) {}

/**
 * LDAP client connection TLS options
 */
module.exports.ldapTlsOptions = {
  ca: bundle,
  rejectUnauthorized: true,
  checkServerIdentity: function (host, cert) {}
};

/**
 * LDAP client connection configuration
 */
module.exports.ldapClientConfig = [
  {reconnect: true, url: 'ldaps://' + require("os").hostname() + ':10389', timeout: 100000, connectTimeout: 10000, bindDN: 'cn=superuser,ou=users,o=management-ui', bindCredentials: 'superuser'}
];

/**
 * LDAP connection pool configuration
 */
module.exports.ldapConnectionPoolConfig = {
  max: 5,                    // max number of connections
  idleTimeoutMillis: 300000, // specifies how long a resource can stay idle in pool before being removed
  log: false                 // if true, logs via console.log - can also be a function
};

/**
 * Session store configuration
 */
module.exports.sessionStoreConfig = {
  maxNumberOfStoredSessions: 1000, // the maximum number of sessions that will be stored
  maxIdleTime: 3600 * 1000         // maximum number of milliseconds that a session can be idle before it is removed
};

/**
 * DSA monitoring by management UI configuration
 */
module.exports.externalMonitor = {
  username: 'admin',
  password: 'admin',                         // user credentials. Used in HTTP Basic authentication when pushing monitoring information to this server.
  hostname: require("os").hostname(),        // host name to use in the endpoint configuration in DSA external monitoring.
  pushInterval: 60,                          // number of seconds between each monitoting information. At lease 5 seconds.
  monitorEvents: ['alarm-log-all', 'stats'], // events to monitor.
  options: ['message-dates-gmt']             // we want all timestamp in UTC/GMT format
};

/**
 * How often we execute maintanence tasks, such as updating CA certificates on the hosts that have DSA with monitoring turned on,
 * and retrieving critical messages, etc.
 */
module.exports.maintenanceTaskInterval = 5;  // execute maintenance tasks every 5 minutes

/**
 * Starts deleting DSA messages when the DB file usable space is lower than this.
 * Enter a number that is between 0 and 1.
 * Any other value will disable this feature.
 */
module.exports.dbFileMinimumUsablePercentage = 0.1;

/**
 * How many days we want to keep the DSA external monitoring information stored.
 * If it is set to anything other than a positive integer number, all messages will be retained forever.
 */
module.exports.dsaMessageRetentionPeriod = 14;   // days we want to keep the DSA messages

/**
 * This is the timeout value for loading LDIF or DB file to a DSA, ajust this value accordingly based on the size of the uploading file.
 */
module.exports.loadFileToDsaTimeout = 10;  // default timeout 10 minutes