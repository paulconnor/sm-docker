const express = require('express');
const path = require('path');
const morganLogger = require('morgan');
const logger = require('./scim-server/utils/logger');
const utils = require('./scim-server/utils/utils');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const config = require('./scim-server/utils/config-index');
const crypto = require('crypto');
const i18n = require('./scim-server/utils/i18n').i18n;

const app = express();

// prevent this header from being sent from the server
app.set('x-powered-by', false);

// a new morgan logger token for the rest api request id
morganLogger.token('id', function getRestAPIRequestId(req) {
  return req.restapi_request_id;
});

// a new morgan logger format string for logging rest api call
morganLogger.format('restapi', '[:id] :remote-addr - :remote-user [:date[clf]] ":method :url HTTP/:http-version" :status :res[content-length]');

var morganCommonLogger = morganLogger('common', {stream: logger.stream});
var morganRestAPILogger = morganLogger('restapi', {stream: logger.stream});

// assigne a unique id to each REST API request
app.use(config.apiPath, assignRestAPIRequestId);
app.use(logHttpRequest);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

//i18n init parses req for language headers, cookies, etc.
app.use(i18n.init);
app.use(config.apiPath, require('./scim-server/routes/authentication'));
app.use(config.apiPath, require('./scim-server/routes/api-index'));

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers
// development error handler, will print stacktrace
if (app.get('env') === 'development') {
  logger.warn('Development error handler is used');
  app.use(function(err, req, res, next) {
    if (res.headersSent) {
      // pass to default error handler
      return next(err);
    }

    if (err.code !== 'EBADCSRFTOKEN') {
      res.status(err.status || 500).send({message: err.message, error: err});
    } else {
      logger.error('CSRF validation failed with error - ' + err, {id: req.restapi_request_id});
      res.status(403).send({message: 'CSRF validation failed'});
    }
  });
}

// production error handler, no stacktraces leaked to user
app.use(function(err, req, res, next) {
  if (res.headersSent) {
    // pass to default error handler
    return next(err);
  }

  if (err.code !== 'EBADCSRFTOKEN') {
    res.status(err.status || 500).send({message: err.message});
  } else {
    logger.error('CSRF validation failed with error - ' + err, {id: req.restapi_request_id});
    res.status(403).send({message: 'CSRF validation failed'});
  }
});

/**
 * Give the HTTP request to REST API a unique id for tracking purpose
 */
function assignRestAPIRequestId(req, res, next) {
  req.restapi_request_id = crypto.randomBytes(8).toString('hex');
  next();
}

/**
 * Log the HTTP request
 */
function logHttpRequest(req, res, next) {
  if (req.path.startsWith(config.apiPath)) {
    morganRestAPILogger(req, res, next);
  } else {
    morganCommonLogger(req, res, next);
  }
}

module.exports = app;

