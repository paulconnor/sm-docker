# management-ui-restapi
REST API for Directory Management UI using the **MEAN** stack

##### [MongoDB (M)](https://docs.mongodb.org/manual/tutorial/install-mongodb-on-windows)
- MongoDB is an open source, document-oriented database designed with both scalability and developer agility in mind. Instead of storing your data in tables and rows as you would with a relational database, in MongoDB you store JSON-like documents with dynamic schemas.

##### [Express (E)](http://expressjs.com/)
- Express is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.

##### [AngularJS (A)](https://angularjs.org/)
- AngularJS is a structural framework for dynamic web apps. It lets you use HTML as your template language and lets you extend HTML's syntax to express your application's components clearly and succinctly. Angular's data binding and dependency injection eliminate much of the code you would otherwise have to write.
- The AngularJS UI is located in ***/public***
- The NodeJS server serves *static* files from ***/public*** to the browser.
- The directory ***/public/app/*** contains all the views and controllers, grouped by feature.
- The files in ***/public/app/_services*** are **singletons** that can be imported and accessed from Controllers.
- Uses [Angular UI](https://angular-ui.github.io/)
- [Anguljar Bootstrap](https://angular-ui.github.io/bootstrap)
- [ngDialog for modals](https://github.com/likeastore/ngDialog)
- [VisJS](http://visjs.org/doc) is used to render the topology
- [CA Bootstrap](https://github-isl-01.ca.com/CentralUX/EDL-Bootstrap-Theme) theme

##### [NodeJS (N)](https://nodejs.org/en/download/)
- Node.js is an open-source, cross-platform runtime environment for developing server-side Web applications. Although Node.js is not a JavaScript framework, many of its basic modules are written in JavaScript, and developers can write new modules in JavaScript.


## Setting Up The Development Environment

##### Installation Requirements:
- NodeJS + NPM
- MongoDB

##### How to start the server:
1. Open cmd line at root folder (management-ui-restapi/)
2. Run 'npm install' to install required node_modules
3. Run 'npm start' to start the server
4. Navigate to **http://127.0.0.1:port. Running npm start will tell you which port the server is running on.

##### To start server without CSRF:
set NO_CSRF=1, then npm start

##### To start server without AUTH:
set NO_AUTH=1, then npm start

#### TO enable the extra logging related to LDAP connection pool
set LDAP_POOL_LOG=1, then npm start
