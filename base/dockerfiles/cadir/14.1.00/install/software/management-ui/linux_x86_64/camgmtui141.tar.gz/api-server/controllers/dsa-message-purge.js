const assert = require('assert');
const ldap = require('../models/ldap-operations');
const utilsLogger = require('../utils/logger');
const utils = require('../utils/utils');
const fs = require('fs');
const crypto = require('crypto');
const Validator = require('jsonschema').Validator;
const jsonValidator = new Validator();
const async = require('async');
const config = require('../utils/config-index');
const ldap2date = require('ldap2date');

var dbFileMinimumUsablePercentage = 0;
if (typeof config.dbFileMinimumUsablePercentage === 'number' &&
    config.dbFileMinimumUsablePercentage > 0 && 
    config.dbFileMinimumUsablePercentage < 1) {
  dbFileMinimumUsablePercentage = config.dbFileMinimumUsablePercentage;
}

// message types
const dsaMessageTypes = {};

dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName] = {
  listFunctionName: 'listAlarms',
  messageType: utils.managementUiLdapConfig.uiAlarmContainerName
};

dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName] = {
  listFunctionName: 'listStats',
  messageType: utils.managementUiLdapConfig.uiStatsContainerName
};

// delete functions
var deleteDsaMessagesToDaysBeforeFunctions = [deleteStatsMessagesToDaysBefore, deleteAlarmMessagesToDaysBefore];

var dsaMessagePurgeController = {};

utilsLogger.info('Cache message schema file is - "' + __dirname + '/cache-schema.json"');
//if this fails, it will throw and will terminate the program
const cacheJsonSchema = JSON.parse(fs.readFileSync(__dirname + '/cache-schema.json'));

/**
 * Receives a DSA cache message
 */
dsaMessagePurgeController.putCacheMessage = function(req, res) {
  var dsaName = (req.body && req.body['dxserver-monitor'] && req.body['dxserver-monitor']['dsa-name']) || 'embeded DSA for storing DSA messages'; 
  var prefixArgs = 'Received a cache message from "' + dsaName + '"';
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});
  var locale = req.getLocale();

  logger.info(utils.i18nTranslate(prefixArgs));

  // check the existence of request body
  if (!req.body) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  // check DSA message format by validating the json object against the json schema
  var validateResults = jsonValidator.validate(req.body, cacheJsonSchema);
  if (validateResults.errors.length !== 0) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.getValidationErrorMessage(validateResults.errors));
    return utils.sendErrorResponse(res, utils.createAPIError(utils.i18nTranslate(locale, prefixArgs), utils.getValidationErrorMessage(validateResults.errors, locale), 400));
  }

  logger.debug(utils.i18nTranslate(prefixArgs) + ': received cache message is - "' + JSON.stringify(req.body) + '"');
  
  var usedBytes = req.body['dxserver-monitor'].cache['used-bytes'];
  var fileSize = req.body['dxserver-monitor'].cache['file-size'];
  var reclaimableBytes = req.body['dxserver-monitor'].cache['reclaimable-bytes'];
  
  var usablePercentage = ( (fileSize - (usedBytes - reclaimableBytes)) / fileSize ) * 100;
  logger.info(utils.i18nTranslate(prefixArgs) + ': DB file usable space percentage is  - "' + usablePercentage + '%"');
  
  if (dbFileMinimumUsablePercentage && usablePercentage < dbFileMinimumUsablePercentage) {
    setImmediate(deleteOldestStatsMessages, 1000);
  }

  return utils.sendJsonResponse(res, 200);
};

/**
 * Delete the oldest stats messages among all the environments
 *
 * The total number of stats messages to be deleted will be:
 *
 *    numberOfMessagesToDelete * ((number of DSAs with monitoring enabled) || 1)
 *
 */
function deleteOldestStatsMessages(numberOfMessagesToDelete) {
  assert(Number.isInteger(numberOfMessagesToDelete) && numberOfMessagesToDelete > 1);
  var prefixArgs = 'Delete the oldest ' + numberOfMessagesToDelete + ' stats messages from storage';
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});
  logger.info(utils.i18nTranslate(prefixArgs));

  // get the LDAP client first
  ldap.acquireLdapClient(logger, 'en', function(err, ldapClient) {
    if (err) {
      return;
    }

    // define a function to delete the oldest 100
    function delete100(callback) {
      /**
       * Use async library to execute the tasks sequentially
       */
      async.waterfall([
        // retrieve the oldest stats message
        function (callback) {
          ldapClient.listOldestStats(100, function(err, result) {
            if (err) {
              return process.nextTick(function () {callback(err);});
            }
            //logger.debug(utils.i18nTranslate(prefixArgs) + ': retrieved stats messages - "' + JSON.stringify(entries) + '"');
            return process.nextTick(function () {callback(null, result);});
          });
        },
        // delete them now
        function (result, callback) {
          if (!result || !result.entries || result.entries.length === 0) {
            logger.warn(utils.i18nTranslate(prefixArgs) + ': no stats messages was retrieved, nothing to do');
            return process.nextTick(function () {callback();});
          }
          ldapClient.deleteEntries(result.entries, function(err) {
            return process.nextTick(function () {callback(err);});
          });
        }
      ],
      function(err) {
        return process.nextTick(function () {callback(err);});
      });
    }

    /**
     * Use async library to execute the tasks sequentially
     */
    async.waterfall([
      // get the number of DSAs with monitoring by management UI enabled
      function (callback) {
        ldapClient.listAllDsasBeingMonitored(function(err, dsas) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.debug(utils.i18nTranslate(prefixArgs) + ': retrieved all DSAs with monitoring enabled - "' + JSON.stringify(dsas) + '"');
          return process.nextTick(function () {callback(null, dsas);});
        });
      },
      // check the number of them and come up with how many messages need to be deleted
      function (dsas, callback) {

        var numberOfDsas;
        var numberOfDeleteIterations = 1;

        if (!dsas || dsas.length === 0) {
          logger.warn(utils.i18nTranslate(prefixArgs) + ': no DSA with monitoring is enabled at the moment, we still need to delete some stats messages');
          numberOfDsas = 1;
        } else {
          numberOfDsas = dsas.length;
        }

        numberOfDeleteIterations = Math.floor((numberOfMessagesToDelete * numberOfDsas) / 100);

        // use async whilst to repeatedly delete entries, 100 at a time
        async.whilst(
          function() {
            var moreToDelete = numberOfDeleteIterations;
            numberOfDeleteIterations = numberOfDeleteIterations - 1;
            return (moreToDelete > 0);
          },
          delete100,
          function (err) {
            return process.nextTick(function () {callback(err);});
          }
        );

      }
    ],
    function(err) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': failed with error - "' + err + '"');
      } else {
        logger.info(utils.i18nTranslate(prefixArgs) + ': successful');
      }
    });
  });
}

/**
 * Delete DSA messages among all the environments upto days before
 */
function deleteAllDsaMessagesToDaysBefore(numberOfDaysBefore, callback) {
  assert(Number.isInteger(numberOfDaysBefore) && numberOfDaysBefore > 1);

  var prefixArgs = 'Delete all DSA messages from storage that are older than ' + numberOfDaysBefore + ' days';
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});

  logger.info(utils.i18nTranslate(prefixArgs) + ': started');

  var tasks = [];
  deleteDsaMessagesToDaysBeforeFunctions.forEach(function(oneTask) {
    tasks.push(function(callback){
      oneTask(logger, numberOfDaysBefore, function(err) {
        // ignore error and continue to delete the next message type
        return process.nextTick(function(){callback();});
      });
    });
  });

  /**
   * Use the async library to execute tasks sequentially
   */
  async.series(tasks,
  function(err) {
    // nothing to do
    logger.info(utils.i18nTranslate(prefixArgs) + ': finished');
    return process.nextTick(function(){callback();});
  });
}

/**
 * Delete stats messages among all the environments upto days before
 */
function deleteStatsMessagesToDaysBefore(logger, numberOfDaysBefore, callback) {
  deleteDsaMessagesToDaysBefore(logger, dsaMessageTypes[utils.managementUiLdapConfig.uiStatsContainerName], numberOfDaysBefore, callback);
}

/**
 * Delete alarm messages among all the environments upto days before
 */
function deleteAlarmMessagesToDaysBefore(logger, numberOfDaysBefore, callback) {
  deleteDsaMessagesToDaysBefore(logger, dsaMessageTypes[utils.managementUiLdapConfig.uiAlarmContainerName], numberOfDaysBefore, callback);
}

/**
 * Delete DSA messages among all the environments upto days before
 */
function deleteDsaMessagesToDaysBefore(logger, dsaMessageType, numberOfDaysBefore, callback) {
  var prefixArgs = 'Deleting ' + dsaMessageType.messageType + ' messages that are older than ' + numberOfDaysBefore + ' days';
  logger.info(utils.i18nTranslate(prefixArgs) + ': started');

  var toDate = new Date();
  // set back time to 5 minutes before midnight
  toDate.setHours(0, 5, 0, 0);
  toDate.setDate(toDate.getDate() - numberOfDaysBefore);
  var toTime = ldap2date.toGeneralizedTime(toDate);

  logger.info(utils.i18nTranslate(prefixArgs) + ': deleting DSA messages older than "' + toDate.toString() + '"');

  // filter to use when listing DSA messages, delete 100 entries at a time
  var filterParams = {to: toTime, attributes: ['dn'], size: 100};

  // get the LDAP client first
  ldap.acquireLdapClient(logger, 'en', function(err, ldapClient) {
    if (err) {
      return process.nextTick(function () {callback(err);});
    }

    var moreToDelete = true;

    // define a function to delete 100 entries at a time
    function delete100(callback) {
      /**
       * Use async library to execute the tasks sequentially
       */
      async.waterfall([
        function (callback) {
          ldapClient[dsaMessageType.listFunctionName](filterParams, function(err, result) {
            if (err) {
              return process.nextTick(function () {callback(err);});
            }
            return process.nextTick(function () {callback(null, result);});
          });
        },
        // delete them now
        function (result, callback) {
          logger.debug(utils.i18nTranslate(prefixArgs) + ': retrieved DSA messages - "' + JSON.stringify(result) + '"');

          if (!result || !result.entries || result.entries.length === 0) {
            moreToDelete = false; // no more to be deleted
            logger.warn(utils.i18nTranslate(prefixArgs) + ': no DSA messages was retrieved, nothing to do');
            return process.nextTick(function () {callback();});
          }

          ldapClient.deleteEntries(result.entries, function(err) {
            return process.nextTick(function () {callback(err);});
          });
        }
      ],
      function(err) {
        return process.nextTick(function () {callback(err);});
      });
    }

    // use async whilst to repeatedly delete entries, 100 at a time
    async.whilst(
      function() {
        return moreToDelete;
      },
      delete100,
      function (err) {
        ldap.returnLdapClient(ldapClient);
        if (err) {
          logger.error(utils.i18nTranslate(prefixArgs) + ': failed with error - "' + err + '"');
        } else {
          logger.info(utils.i18nTranslate(prefixArgs) + ': successful');
        }
        return process.nextTick(function () {callback(err);});
      }
    );
  });
}

function deleteAndSchedule() {
  deleteAllDsaMessagesToDaysBefore(config.dsaMessageRetentionPeriod, function(err) {
    // when it is done, schedule another run of the deleteAndSchedule function in one day, 5 minutes after midnight
    var dateNow = new Date();
    var dateInOneDay = new Date();
    dateInOneDay.setDate(dateInOneDay.getDate() + 1);
    dateInOneDay.setHours(0, 5, 0, 0);
    utilsLogger.debug('Scheduling delete DSA messages task: current time is "' + dateNow.toString() + '"');
    utilsLogger.info('Scheduling delete DSA messages task to run at "' + dateInOneDay.toString() + '"');
    setTimeout(deleteAndSchedule, dateInOneDay.getTime() - dateNow.getTime());
  });
}

if (config.dsaMessageRetentionPeriod && Number.isInteger(config.dsaMessageRetentionPeriod) && config.dsaMessageRetentionPeriod >= 1) {
  // schedule a task to delete DSA messages that are older than the configured days to run in 1 minute
  setTimeout(deleteAndSchedule, 60 * 1000);
}

module.exports = dsaMessagePurgeController;
