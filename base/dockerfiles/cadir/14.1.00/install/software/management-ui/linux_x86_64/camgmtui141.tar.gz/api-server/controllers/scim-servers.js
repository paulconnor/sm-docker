const assert = require('assert');
const utilsLogger = require('../utils/logger');
const utils = require('../utils/utils');
const ldap = require('../models/ldap-operations');
const async = require('async');
const config = require('../utils/config-index');
const crypto = require('crypto');
const url = require('url');
const request = require('request');

var scimServerController = {};

var scheduledTimeout = null;
var scheduledImmediate = null;
var scimConfig = {"scimServerPort" :"0"};


/**
 * Register a SCIM server.
 * If the SCIM server already exists, just update it.
 */
scimServerController.register = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.scimServers.prefix.register', req.body.scimServerUrl];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.body || !req.body.scimServerUrl || !req.body.scimServerSecret) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  try {
    if (!url.parse(req.body.scimServerUrl)) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.invalidRequestFormat'));
      return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.invalidRequestFormat', 400));
    }
  } catch (error) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.invalidRequestFormat'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(locale, prefixArgs, 'errors.invalidRequestFormat', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function (err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    //List the scimservers
    ldapClient.listScimServers(function (err, scimServerList) {
      if (err) {
        logger.debug(prefixArgs + ': failed to list scim servers, error is - "' + err + '"');
      }
      async.series([
        function (callback) {
          if (scimServerList && scimServerList.length > 0) {
            for (var i = 0; i < scimServerList.length; i++) {
              //Check if the current scimserver url exists in the list, if exists then update the port with the new port data   
              if (url.parse(scimServerList[i].scimServerUrl).hostname == url.parse(req.body.scimServerUrl).hostname) {
                if (url.parse(scimServerList[i].scimServerUrl).port != url.parse(req.body.scimServerUrl).port) {
                  ldapClient.updateScimserverUrl((scimServerList[i].scimServerUrl), req.body.scimServerUrl, function (err, res) {
                    if (err) {
                      logger.debug(utils.i18nTranslate(prefixArgs) + ': LDAP modify error is ' + JSON.stringify(err));
                      return callback();
                    } //If the ScimServerUrl exists and the port was updated successfull, proceed to invoke createScimServer
                    else {
                      return callback();
                    }
                  });
                }//If the ScimServerUrl exists and there is no port change, proceed to invoke createScimServer
                else {
                  return callback();
                }
              }
              //In future if an external scim server needs to be configured, then invoke the callback()
            }
          }//If ScimServerList is zero, then create ScimServer
          else {
            return callback();
          }
        }],
        function (callback) {
          ldapClient.createScimServer(req.body, function (err) {
            ldap.returnLdapClient(ldapClient);
            if (err) {
              utils.sendErrorResponse(res, err);
            } else {
              //Whenever the scimURL is modified, the getScimPort() should pick up the latest port from the ldapServer list
              scimConfig.scimServerPort = 0; 
              utils.sendJsonResponse(res, 204);
            }
          });
        }
      );
    });
  });
};

//Function to Fetch the SCIM Port from the ScimServerURL
 scimServerController.getScimPort = function(req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  if(scimConfig.scimServerPort == 0) {
  // get the list of all SCIM servers
  ldap.acquireLdapClient(logger, 'en', function (err, ldapClient) {
  if (err) {
    return utils.sendErrorResponse(res, err);
  }
  ldapClient.listScimServers(function (err, scimServerList) {
    ldap.returnLdapClient(ldapClient);
    if (err) {
      return logger.error(prefixArgs + ': failed to list scim servers, error is - "' + err + '"');
    }
  if (scimServerList && scimServerList.length > 0) {
   var port = url.parse(scimServerList[scimServerList.length-1].scimServerUrl).port;
   scimConfig.scimServerPort = port;
   utils.sendJsonResponse(res, 200, scimConfig ); 
  }
  });
  });
  }
  else {
  utils.sendJsonResponse(res, 200, scimConfig ); 
  }
}


/**
 * Unregister a SCIM server.
 */
scimServerController.unregister = function (req, res) {
  var logger = utilsLogger.createMetaLogger({id: req.restapi_request_id});
  var prefixArgs = ['controllers.scimServers.prefix.unregister', req.params.scimServerUrl];
  logger.info(utils.i18nTranslate(prefixArgs));

  if (!req.params || !req.params.scimServerUrl) {
    logger.error(utils.i18nTranslate(prefixArgs) + ': ' + utils.i18nTranslate('errors.missingRequestBodyOrAttribute'));
    return utils.sendErrorResponse(res, utils.createLocalizedAPIError(req.getLocale(), prefixArgs, 'errors.missingRequestBodyOrAttribute', 400));
  }

  ldap.acquireLdapClient(logger, req.getLocale(), function (err, ldapClient) {
    if (err) {
      return utils.sendErrorResponse(res, err);
    }

    ldapClient.deleteScimServer(req.params.scimServerUrl, function (err) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        utils.sendErrorResponse(res, err);
      } else {
        utils.sendJsonResponse(res, 204);
      }
    });
  });
};

/**
 * Notify all SCIM servers about the SCIM instance configuration changes
 */
function notify(environmentName) {

  var prefixArgs = 'Notifying SCIM servers about the SCIM configuration changes in environment "' + environmentName + '"';
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});
  logger.info(prefixArgs + ': started');

  // get the list of all SCIM servers
  ldap.acquireLdapClient(logger, 'en', function (err, ldapClient) {
    if (err) {
      return;
    }

    ldapClient.listScimServers(function (err, scimServerList) {
      ldap.returnLdapClient(ldapClient);
      if (err) {
        return logger.error(prefixArgs + ': failed to list scim servers, error is - "' + err + '"');
      }

      if (scimServerList && scimServerList.length > 0) {
        // notify eash SCIM server, if fails to notify any one of them, schedule another run with the failed ones
        return notifyScimServers(prefixArgs, logger, environmentName, scimServerList);
      } else {
        return logger.info(prefixArgs + ': no SCIM server has been found, no need to send the notification');
      }
    });
  });
}

/**
 * Notify all SCIM servers about the SCIM instance configuration changes
 */
function notifyScimServers(prefixArgs, logger, environmentName, scimServerList) {
  assert (scimServerList && Array.isArray(scimServerList));
  
  var failedList = [];

  // go through the SCIM server list
  async.each(scimServerList,
    function(oneScimServer, callback) {
      scimNotify(prefixArgs, logger, environmentName, oneScimServer, function(err) {
        if (err) {
          failedList.push(oneScimServer);
        }
        return callback();
      });
    },
    function()
    {
      if (failedList.length > 0) {
        // schedule another run of notification when we failed to notify any of the SCIM servers
        logger.info(prefixArgs + ': failed to send notification to some SCIM servers, scheduling another notification');
        scheduleNotification(prefixArgs, logger, environmentName, failedList);
      }
    }
  );
}

/**
 * Call the SCIM API to send the notification
 *
 * @returns true when successful and false otherwise
 */
function scimNotify(prefixArgs, logger, environmentName, scimServer, callback) {
  assert (scimServer && typeof scimServer === 'object');

  var apiPath = config.apiPath + '/environments/' + encodeURIComponent(environmentName) + '/notifications';
  var options = {
    url: (scimServer.scimServerUrl.endsWith('/') ? scimServer.scimServerUrl.substring(0, scimServer.scimServerUrl.length - 1) : scimServer.scimServerUrl) + apiPath,
    method: 'POST',
    auth: {username: 'notify',  password: scimServer.scimServerSecret},
    headers: {'Accept': 'application/json', 'Content-Length': 0}
  };

  if (config.serverCaCertificatePem) {
    options.ca = config.serverCaCertificatePem;
  }

  request(options, function(error, response) {
    if (error) {
      logger.error(prefixArgs + ': failed to send notification to SCIM server "%s", error is - "' + error + '"', scimServer.scimServerUrl);
      return callback(error);
    }

    if (response.statusCode === 204) {
      logger.info(prefixArgs + ': notification sent to SCIM server "%s" successfully', scimServer.scimServerUrl);
      return callback();
    } else {
      logger.error(prefixArgs + ': failed to send notification to SCIM server "%s", HTTP status code is "%d"', scimServer.scimServerUrl, response.statusCode);
      return callback(new Error('Failed with status code ' + response.statusCode));
    }
  });
}

/**
 * Cancel the currently scheduled run
 */
function cancelScheduledNotification() {
  if (scheduledTimeout) {
    // cancel it, if the scheduled task has been fired. This will not have any effect
    clearTimeout(scheduledTimeout);
    scheduledTimeout = null;
  }

  if (scheduledImmediate) {
    clearImmediate(scheduledImmediate);
    scheduledImmediate = null;
  }
}

/**
 * Schedule a notification in 5 minutes
 */
function scheduleNotification(prefixArgs, logger, environmentName, scimServerList) {
  cancelScheduledNotification();
  // set a timer to do this again in 5 minutes
  scheduledTimeout = setTimeout(function() {
    notifyScimServers(prefixArgs, logger, environmentName, scimServerList);
  }, 2 * 60 * 1000);
}

/**
 * Notify SCIM servers immediately
 */
scimServerController.notifyImmediately =  function(environmentName) {
  cancelScheduledNotification();
  utilsLogger.info('Scheduling an immediate notification of SCIM configuration changes in environment %s', environmentName);
  scheduledImmediate = setImmediate(function() {
    notify(environmentName);
  });
};

module.exports = scimServerController;