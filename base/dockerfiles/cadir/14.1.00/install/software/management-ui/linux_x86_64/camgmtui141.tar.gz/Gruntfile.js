module.exports = function (grunt) {

  grunt.initConfig({
    jshint: {
      server: ['./api-server/**/*.js', './scim-server/**/*.js', './*.js'],
      frontEnd: ['./public/app/**/*.js', './public/lib/js/edl/*.js'],
      options: {
        ignores: ['./public/app/UNUSED/**', './scim-server/api-docs/**'],
        undef: false,
        esversion: 6
      }
    }
  });

  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.registerTask('default', ['jshint']); // register a default task alias
  grunt.registerTask('dev', ['jshint']);
};