const assert = require('assert');
const ldap = require('../models/ldap-operations');
const utilsLogger = require('../utils/logger');
const utils = require('../utils/utils');
const fs = require('fs');
const crypto = require('crypto');
const Validator = require('jsonschema').Validator;
const jsonValidator = new Validator();
const async = require('async');
const ldap2date = require('ldap2date');
const emailjs = require('../../node_modules/emailjs/email');
const execSync = require('child_process').execSync;

const NOTHING_TO_DO = 'Nothing to be done';
const EMAIL_SUBJECT = 'Alarm Notification received from DSA - ';

// email notification template file
const emailTemplate = fs.readFileSync(__dirname + '/email-notification.html', 'utf8');

// email SMTP json schema
utilsLogger.info('Email SMTP configuration schema file is - "' + __dirname + '/email-smtp-schema.json"');
const emailSmtpJsonSchema = JSON.parse(fs.readFileSync(__dirname + '/email-smtp-schema.json'));

// email recipients json schema
utilsLogger.info('Email recipients configuration schema file is - "' + __dirname + '/email-recipients-schema.json"');
const emailRecipientsJsonSchema = JSON.parse(fs.readFileSync(__dirname + '/email-recipients-schema.json'));

var environmentsWithEmailNotificationEnabled;
var scheduledTimeout = null;

/**
 * Get the email configurations of environments with email notification enabled.
 */
function buildEmailNotificationConfigs(prefixArgs, logger, callback) {

  // get the LDAP client first
  ldap.acquireLdapClient(logger, 'en', function(err, ldapClient) {
    if (err) {
      return process.nextTick(function () {callback(err);});
    }

    async.waterfall([
      function (callback) {
        ldapClient.listEmailEnabledEnvironments(function(err, envs) {
          if (err) {
            return process.nextTick(function () {callback(err);});
          }
          logger.debug(utils.i18nTranslate(prefixArgs) + ': retrieved environments - "' + JSON.stringify(envs) + '"');
          return process.nextTick(function () {callback(null, envs);});
        });
      },
      function (envs, callback) {

        // no environment exists yet
        if (!envs || envs.length === 0) {
          logger.info(utils.i18nTranslate(prefixArgs) + ': no environment with email notification by management UI enabled has been found');
          // clear the cached settings
          environmentsWithEmailNotificationEnabled = null;
          // this will end the whole callback sequence
          return process.nextTick(function () {callback(NOTHING_TO_DO);});
        }

        environmentsWithEmailNotificationEnabled = buildEmailNotification(prefixArgs, logger, envs);
        return process.nextTick(function(){callback();});
      }
    ],
    function(err) {
      ldap.returnLdapClient(ldapClient);
      if (NOTHING_TO_DO === err) {
        return process.nextTick(function(){callback();});
      } else {
        return process.nextTick(function(){callback(err);});
      }
    });

  });
}

/**
 * Check the email configurations for environments, add filter functions and create email server.
 */
function buildEmailNotification (prefixArgs, logger, envs) {
  var tempEnvironmentsWithEmailNotificationEnabled = {};
  var passwordAsterisks = "********";
  var tempUsername = "";

  // go throgh the list of environments
  envs.forEach(function(oneEnv) {
    if (oneEnv.emailNotificationEnabled && oneEnv.emailSmtpConfig && oneEnv.emailGroups) {
      // validate the SMTP configuration and email recipients configuration
      var validateResults = jsonValidator.validate(oneEnv.emailSmtpConfig, emailSmtpJsonSchema);
      if (validateResults.errors.length !== 0) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': invalid email SMTP configuration found on environment "' + oneEnv.name + '"');
        return;
      }

      validateResults = jsonValidator.validate(oneEnv.emailGroups, emailRecipientsJsonSchema);
      if (validateResults.errors.length !== 0) {
        logger.error(utils.i18nTranslate(prefixArgs) + ': invalid email recipients configuration found on environment "' + oneEnv.name + '"');
        return;
      }

      oneEnv.emailGroups.forEach(function(oneRecipientConfig) {
        if (oneRecipientConfig.filters) {
          oneRecipientConfig.filters.forEach(function(andFilters) {
            andFilters.forEach(function(oneFilter) {
              oneFilter.filterFunction = filterFunctions[oneFilter.operator];
              oneFilter.value = oneFilter.value.toUpperCase();
            });
          });
        }
      });

      // Get the SSL/TLS settings
      if (oneEnv.emailSmtpConfig.sslTls === 1) {
        oneEnv.emailSmtpConfig.ssl = true;
      } else if (oneEnv.emailSmtpConfig.sslTls === 2) {
        oneEnv.emailSmtpConfig.tls = true;
      }
      delete oneEnv.emailSmtpConfig.sslTls;

      if(oneEnv.emailSmtpConfig.user != "" ) {
      tempUsername = oneEnv.emailSmtpConfig.user;
      }

      //In case of Anonymous, the user is not required 
      if(oneEnv.emailSmtpConfig.password == passwordAsterisks || oneEnv.emailSmtpConfig.password == "" )
      {
        oneEnv.emailSmtpConfig.user = "";
      }

      if (oneEnv.emailSmtpConfig.password && oneEnv.emailSmtpConfig.password.indexOf('{CADIR}') == 0) {
        oneEnv.emailSmtpConfig.password = execSync('dxpassword -D CADIR ' + oneEnv.emailSmtpConfig.password).toString();
      }
 
      // passed validation
      tempEnvironmentsWithEmailNotificationEnabled[oneEnv.name] = {emailGroups: oneEnv.emailGroups,
                                                                   emailSmtpConfig: oneEnv.emailSmtpConfig,
                                                                   emailServer: emailjs.server.connect(oneEnv.emailSmtpConfig)};
       // Assigning the user(from address) which is required in order to send the email                                                         
       oneEnv.emailSmtpConfig.user  = tempUsername;  
                                                                                                      
    } else {
      logger.warn(utils.i18nTranslate(prefixArgs) + ': email notification configuration is not complete for environment "' + oneEnv.name + '"');
    }
  });

  return tempEnvironmentsWithEmailNotificationEnabled;
}


/**
 * The equal filter
 */
function eqFilter(actualValue) {
  return this.value === actualValue.toUpperCase();
}

/**
 * The not equal filter
 */
function neFilter(actualValue) {
  return this.value !== actualValue.toUpperCase();
}

/**
 * The contain filter
 */
function coFilter(actualValue) {
  return actualValue.toUpperCase().indexOf(this.value) !== -1;
}

/**
 * The not contain filter
 */
function ncFilter(actualValue) {
  return actualValue.toUpperCase().indexOf(this.value) === -1;
}

/**
 * All the filter functions
 */
const filterFunctions = {eq: eqFilter, ne: neFilter, co: coFilter, nc: ncFilter};

/**
 * Get the list of email recipient adresses based on the passed in alarm object.
 * Apply the filters defined.
 */
function getRecipientEmailAddresses(environmentName, alarm) {
  var emailAddresses = [];

  if (!environmentsWithEmailNotificationEnabled ||
      !environmentsWithEmailNotificationEnabled[environmentName] ||
      !environmentsWithEmailNotificationEnabled[environmentName].emailGroups) {
    return emailAddresses;
  }

  // get the list of email addresses, apply the filters at the same time
  environmentsWithEmailNotificationEnabled[environmentName].emailGroups.forEach(function(oneRecipientConfig) {
    if (oneRecipientConfig.filters && oneRecipientConfig.filters.length > 0) {
      // some() executes the callback function once for each element present in the array until it finds
      // one where callback returns a truthy value (a value that becomes true when converted to a Boolean).
      // If such an element is found, some() immediately returns true. Otherwise, some() returns false.
      var match = oneRecipientConfig.filters.some(function(andFilters) {
        // every method returns true if the callback for all elements returns true
        return andFilters.every(function(oneFilter) {
          return oneFilter.filterFunction(alarm[oneFilter.field]);
        });
      });

      if (match) {
        emailAddresses = emailAddresses.concat(oneRecipientConfig.emailRecipients);
      }
    } else {
      // no filter defined for these recipients, so send to them all
      emailAddresses = emailAddresses.concat(oneRecipientConfig.emailRecipients);
    }
  });

  return emailAddresses;
}

/**
 * Get the list of email recipient addresses and send the email notification
 */
function sendEmail(environmentName, alarm) {
  assert (alarm.host && alarm.dsa);
  if (!environmentsWithEmailNotificationEnabled ||
      !environmentsWithEmailNotificationEnabled[environmentName] ||
      !environmentsWithEmailNotificationEnabled[environmentName].emailGroups ||
      !environmentsWithEmailNotificationEnabled[environmentName].emailSmtpConfig ||
      !environmentsWithEmailNotificationEnabled[environmentName].emailServer) {
    return;
  }

  var emailFilter = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
  var prefixArgs = 'Send email notification about DSA "' + alarm.dsa + '" on dxagent "' + alarm.host + '" in environment "' + environmentName + '"';
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});
  var emailServer = environmentsWithEmailNotificationEnabled[environmentName].emailServer;
  var emailSmtpConfig = environmentsWithEmailNotificationEnabled[environmentName].emailSmtpConfig;
  var emailAddresses = getRecipientEmailAddresses(environmentName, alarm);
  
  if (!emailAddresses || emailAddresses.length === 0) {
    return;
  }

  emailAddresses = emailAddresses.join(); 

  logger.info(utils.i18nTranslate(prefixArgs) + ': started sending email to "' + emailAddresses + '"');

  var emailContent = emailTemplate.replace('{{ dsa-name }}', alarm.dsa);
  emailContent = emailContent.replace('{{ host-name }}', alarm.host);
  emailContent = emailContent.replace('{{ time }}', ldap2date.parse(alarm.time).toString());
  emailContent = emailContent.replace('{{ message-id }}', alarm.messageId);
  emailContent = emailContent.replace('{{ alarm-id }}', alarm.id);
  emailContent = emailContent.replace('{{ alarm-type }}', alarm.type);
  emailContent = emailContent.replace('{{ message }}', alarm.message);


     
   if (!emailFilter.test(emailSmtpConfig.user)) {
        emailSmtpConfig.user = emailSmtpConfig.user +"@" +environmentName + ".com";
      }

  emailServer.send({text: '', from: emailSmtpConfig.user, to: emailAddresses, subject: EMAIL_SUBJECT + alarm.dsa, attachment: [{data: emailContent, alternative: true}]}, function(err, sendResult) {
    if (err) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': failed with error - ' + err);
    } else {
      logger.info(utils.i18nTranslate(prefixArgs) + ': successful');
    }
  });
}

/**
 * Cancel the currently scheduled run
 */
function cancelScheduledLoading() {
  if (scheduledTimeout) {
    // cancel it, if the scheduled task has been fired. This will not have any effect
    clearTimeout(scheduledTimeout);
    scheduledTimeout = null;
  }
}

/**
 * Schedule another run
 */
function scheduleLoading() {
  // before we schedule another run, cancel the existing scheduled task to prevent scheduling
  // it for more than once.
  cancelScheduledLoading();
  // set a timer to do this again in 2 minutes
  scheduledTimeout = setTimeout(loadEmailConfig, 2 * 60 * 1000);
}

/**
 * Load email configuration
 */
function loadEmailConfig() {
  var prefixArgs = 'Load email configurations for all environments with email notification enabled';
  var logger = utilsLogger.createMetaLogger({id: crypto.randomBytes(8).toString('hex')});
  logger.info(utils.i18nTranslate(prefixArgs) + ': started');
  buildEmailNotificationConfigs(prefixArgs, logger, function(err) {
    if (err) {
      logger.error(utils.i18nTranslate(prefixArgs) + ': error - ' + err);
    } else {
      logger.info(utils.i18nTranslate(prefixArgs) + ': successful');
    }
    // schedule another run
    scheduleLoading();
  });
}

/**
 * Load the email configuration immediately
 */
function loadEmailConfigImmediately() {
  cancelScheduledLoading();
  setImmediate(loadEmailConfig);
}

/**
 * Schedule a task to load email notification immediately
 */
loadEmailConfigImmediately();

/**
 * export the functions
 */
module.exports.sendEmail = sendEmail;
module.exports.loadEmailConfigImmediately = loadEmailConfigImmediately;
